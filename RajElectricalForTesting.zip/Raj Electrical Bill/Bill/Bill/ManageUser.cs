﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Constants;
using Bill.Delegate;
using Bill.Model;
using Bill.Utilities;

namespace Bill
{
    public partial class ManageUser : Form
    {
        public ManageUser()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                grpBoxUserEdit.Enabled = true;
                grpBoxSave.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpBoxSave.Visible = true;
                grpBoxOperations.Visible = false;
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageUsers_btnEdit_Click error: " + exception.Message + " " + DateTime.Now);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            grpBoxOperations.Visible = true;
            grpBoxSave.Visible = false;
            grpBoxUserEdit.Enabled = false;
        }

        private void ManageUser_Load(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            try
            {
                PopulateUsers();
            }
            catch (Exception ex)
            {
                objUtility.WriteLog(ex.Message);
            }
        }

        private void PopulateUsers()
        {
            try
            {
                UsersDelegate usersDelegate = new UsersDelegate();
                DataTable dtUsers = usersDelegate.GetUsers(ApplicationConstants.ActiveIndicator);
                if (dtUsers != null && dtUsers.Rows.Count > 0)
                {
                    dgvUsers.DataSource = dtUsers;
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("form Manage Users method PopulateUsers" + exception.Message + DateTime.Now);

            }
            
        }

        private void ManageUser_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void dgvUsers_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvUsers.Rows.Count > 0)
                {
                    txtUserName.Text = dgvUsers.Rows[e.RowIndex].Cells["Username"].Value.ToString();
                    txtPassword.Text = dgvUsers.Rows[e.RowIndex].Cells["Password"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog(ex.StackTrace);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUserName.Text.Trim().Length > 1 && txtPassword.Text.Trim().Length > 1)
                {
                    UsersModel usersModel = new UsersModel();
                    usersModel.Id = Convert.ToInt32(dgvUsers.CurrentRow.Cells["UserId"].Value);
                    usersModel.Username = txtUserName.Text.Trim();
                    if (txtPassword.Text==txtConfirmPassword.Text)
                    {
                        usersModel.Password = txtPassword.Text.Trim();
                        UsersDelegate usersDelegate = new UsersDelegate();
                        bool result = usersDelegate.SaveUser(usersModel);
                        if (result)
                        {
                            MessageBox.Show("User updation successfull.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            PopulateUsers();
                            grpBoxOperations.Visible = true;
                            grpBoxSave.Visible = false;
                            grpBoxUserEdit.Enabled = false;
                        }
                        else
                        {
                            MessageBox.Show("User updation unsuccessfull.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password Does Not Match with Confirm Password. Please Retype Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
                else
                {
                    MessageBox.Show("Please fill all the details.", "Error", MessageBoxButtons.OK);
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageUser form btnSave : " + exception.Message + DateTime.Now);
            }
        }
    }
}
