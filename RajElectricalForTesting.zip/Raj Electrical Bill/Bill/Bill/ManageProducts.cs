﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Constants;
using Bill.Utilities;
using Bill.Delegate;
using Bill.Model;
using System.Threading;

namespace Bill
{
    public partial class ManageProducts : Form
    {
        DataTable datatable = new DataTable();
        bool IsFormLoaded = false;
        InvoiceTypeDelegate invoiceTypeDelegate = new InvoiceTypeDelegate();
        int ProductID = 0;
      
        public ManageProducts()
        {
            InitializeComponent();
           
        }

        private void ManageProducts_Shown(object sender, EventArgs e)
        {
            IsFormLoaded = true;
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnExit_Click(object sender, EventArgs e)//this is Cancel button code
        {
          this.Close();
         
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                btnSave.Tag = ApplicationConstants.OperationUpdate;
                grpBoxProductEdit.Enabled = true;
                btnAddProduct.Visible = false;
                dgvAddProduct.Visible = false;
                grpBoxOperations.Visible = false;
                grpBoxSave.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpBoxSave.Visible = true;
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("ManageProducts_btnEdit_Click error: " + exception.Message + " " + DateTime.Now);
            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                txtProductName.Enabled = true;
                txtProductCode.Enabled = true;
                dgvAddProduct.Visible = true;
                dgvProducts.Visible = true;
                btnSave.Tag = ApplicationConstants.OperationInsert;
                dgvProducts.Enabled = false;
                txtProductName.Text = string.Empty;
                txtProductPrice.Text = string.Empty;
                txtProductCode.Text = string.Empty;
                grpBoxProductEdit.Enabled = true;
                btnAddProduct.Visible = true;
                grpBoxOperations.Visible = false;
                grpBoxSave.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpBoxSave.Visible = true;
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("ManageProducts_btnAddNew_Click error: " + exception.Message + " " + DateTime.Now);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                grpBoxOperations.Visible = true;
                grpBoxProductEdit.Enabled = false;
                grpBoxSave.Visible = false;
                dgvProducts.Enabled = true;
                if (dgvProducts.Rows.Count > 0)
                {
                    txtProductName.Text = dgvProducts.CurrentRow.Cells["Product"].Value.ToString();
                    txtProductPrice.Text = dgvProducts.CurrentRow.Cells["Price"].Value.ToString();
                    bool currentStatus = Convert.ToBoolean(dgvProducts.CurrentRow.Cells["IsActive"].Value);
                    if (currentStatus == ApplicationConstants.ActiveIndicator)
                    {
                        rdbtnActive.Checked = true;
                        rdbtnInActive.Checked = false;
                    }
                    else if (currentStatus == ApplicationConstants.InActiveIndicator)
                    {
                        rdbtnActive.Checked = false;
                        rdbtnInActive.Checked = true;
                    }
                }
                else
                {
                    txtProductName.Text = string.Empty;
                    txtProductPrice.Text = string.Empty;
                }
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("ManageProducts_btnCancel_Click error: " + exception.Message + " " + DateTime.Now);
            }
        }

        private void ManageProducts_Load(object sender, EventArgs e)
        {
           
            Utility utility = new Utility();
            dgvAddProduct.Visible = false;
            try
            {
                
                btnAddProduct.Visible = false;
                PopulateProducts();
                PopulateInvoiceType();
                SetWidthOfCellInGridView();
             
            }
            catch (Exception exception)
            {
                utility.WriteLog("ManageProducts_Load error: " + exception.Message + " " + DateTime.Now);
            }

        }

        private void SetWidthOfCellInGridView()
        {
            foreach (DataGridViewColumn col in dgvProducts.Columns)
            {
                   
               
                    if (col.Name!="dgvColCode"&&col.Name!="Product")
                    {
                        col.Width = 60;
                    }
              
            }
        }
        private void PopulateProducts()
        {
            try
            {
                ProductsDelegate productsDelegate = new ProductsDelegate();
                DataTable dtProducts = productsDelegate.GetAllProducts();
                dgvProducts.DataSource = dtProducts;
            }
            catch (Exception exception)
            {

                Utility objUtility = new Utility();
                objUtility.WriteLog("form ManageProducts mehtod PopulateProducts" + exception.Message + DateTime.Now);
            }

        }

        private void dgvProducts_RowEnter(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            try
            {
                bool result = false;
                if (ckbChangeName.Checked==true)
                {
                    ProductsDelegate productsDelegate = new ProductsDelegate();
                    ProductsModel productsModel = new ProductsModel();
                    productsModel.Name = txtProductName.Text.Trim();
                    productsModel.Code = txtProductCode.Text.Trim();
                    result = productsDelegate.UpdateProductNameByCode(productsModel);
                    if (result)
                    {
                        MessageBox.Show("Product operation successfull.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Product operation unsuccessfull.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                   
                    if (txtProductPrice.Text.Trim().Length > 0 && txtProductPrice.Text.Trim().Length > 0)
                    {
                        ProductsModel productsModel = new ProductsModel();

                        if (btnSave.Tag == ApplicationConstants.OperationInsert)
                        {

                            for (int row = 0; row < dgvAddProduct.Rows.Count; row++)
                            {

                                productsModel.Name = dgvAddProduct.Rows[row].Cells["ProductName"].Value.ToString();
                                productsModel.Code = dgvAddProduct.Rows[row].Cells["ProductCode"].Value.ToString();
                                productsModel.InvoicesType = Convert.ToInt32(dgvAddProduct.Rows[row].Cells["InvoiceTypeID"].Value);
                                productsModel.Price = Convert.ToDecimal(dgvAddProduct.Rows[row].Cells["ProductPrice"].Value);
                                string status = dgvAddProduct.Rows[row].Cells["ProductStatus"].Value.ToString();
                                if (status == ApplicationConstants.ActiveIndicatorText)
                                {
                                    productsModel.IsActive = ApplicationConstants.ActiveIndicator;

                                }
                                else
                                {
                                    productsModel.IsActive = ApplicationConstants.InActiveIndicator;
                                }
                             
                                productsModel.CreatedDate = Convert.ToDateTime(DateTime.Now);
                                ProductsDelegate productsDelegate = new ProductsDelegate();
                                result = productsDelegate.SaveProduct(productsModel);

                            }//for
                            if (result)
                            {
                                MessageBox.Show("Product operation successfull.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                PopulateProducts();
                                dgvProducts.CurrentCell.Selected = false;
                                grpBoxProductEdit.Enabled = false;
                                grpBoxOperations.Visible = true;
                                grpBoxSave.Visible = false;
                                dgvProducts.Enabled = true;
                            }
                            else
                            {
                                MessageBox.Show("Product operation unsuccessfull.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                        }//if
                        else if (btnSave.Tag == ApplicationConstants.OperationUpdate)
                        {

                            if (cmbInvoiceType.Text == "--Select--")
                            {
                                MessageBox.Show("Please Select the Invoice type");
                            }
                            else
                            {
                                productsModel.ID = Convert.ToInt32(lblProductID.Text);
                                productsModel.Name = txtProductName.Text.Trim();
                                productsModel.Code = txtProductCode.Text.Trim();
                                productsModel.InvoicesType = Convert.ToInt32(cmbInvoiceType.SelectedValue);
                                productsModel.Price = Convert.ToDecimal(txtProductPrice.Text);
                                if (rdbtnActive.Checked == true)
                                {
                                    productsModel.IsActive = ApplicationConstants.ActiveIndicator;
                                }
                                else
                                {
                                    productsModel.IsActive = ApplicationConstants.InActiveIndicator;
                                }
                                ProductsDelegate productsDelegate = new ProductsDelegate();
                                result = productsDelegate.UpdateProduct(productsModel);
                                if (result)
                                {
                                    MessageBox.Show("Product operation successfull.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Product operation unsuccessfull.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }

                            }

                        }
                        else
                        {
                            MessageBox.Show("Please fill all the details.", "Error", MessageBoxButtons.OK);
                        }
                   }
               
                    //PopulateProducts();
                    //grpBoxOperations.Enabled = false;
                    //btnSaveProduct.Enabled = false;

                }
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("ManageProduct_btnSave_Click error: " + exception.Message + " " + DateTime.Now);
            }
            PopulateProducts();
            grpBoxOperations.Enabled = false;
            btnSaveProduct.Enabled = false;
            PopulateInvoiceType();
            dgvAddProduct.DataSource = null;
            dgvAddProduct.Rows.Clear();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            try
            {

                if (cmbInvoiceType.SelectedValue != null)
                {
                    ProductsDelegate productsDelegate = new ProductsDelegate();
                    DataTable dtProducts = new DataTable();
                    DataTable dtProductNames = new DataTable();
                    string productName = txtProductName.Text;
                    if (txtProductName.Text != "")
                    {
                        dtProductNames = productsDelegate.GetProductByName(productName);//check whether the same product name exits.
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Product Name");
                        txtProductName.Focus();
                    }
                    if (dtProductNames.Rows.Count > 0)
                    {

                        MessageBox.Show("Same Product Name Exits.Please Insert New Product Name");
                    }
                    if (txtProductCode.Text == "")
                    {
                        MessageBox.Show("Please Enter the Product Code");
                        txtProductCode.Focus();
                    }
                    string Code = txtProductCode.Text;
                    dtProducts = productsDelegate.GetAllProductsByCode(Code);  //check whether the same product code exits.
                    if (dtProducts.Rows.Count > 0)
                    {
                        MessageBox.Show("Product Code Exits.Plaese Insert New Product Code");
                        txtProductCode.Focus();
                    }
                   
                    if (txtProductPrice.Text == "")
                    {
                        MessageBox.Show("Please Enter the Price");
                        txtProductPrice.Focus();
                    }
                   
                    else
                    {
                        txtProductName.Enabled = false;
                        txtProductCode.Enabled = false;
                        var ProductName = txtProductName.Text.Trim();
                        var productCode = txtProductCode.Text.Trim();
                        var invoiceType = cmbInvoiceType.Text.Trim();
                        int invoiceTypeID = Convert.ToInt32(cmbInvoiceType.SelectedValue);
                        var productPrice = txtProductPrice.Text.Trim();
                        var isActive = "";
                        if (rdbtnActive.Checked == true)
                        {
                            isActive = ApplicationConstants.ActiveIndicatorText;
                        }
                        else
                        {
                            isActive = ApplicationConstants.InActiveIndicatorText;
                        }
                        dgvAddProduct.Rows.Add(ProductName, productCode, invoiceType, invoiceTypeID, productPrice, isActive);
                    }


                    for (int row = 0; row < dgvAddProduct.Rows.Count; row++)
                    {
                        int index = Convert.ToInt32(cmbInvoiceType.SelectedIndex);
                        if (dgvAddProduct.Rows[row].Cells["ProductInvoice"].Value == (cmbInvoiceType.Text).ToString())
                        {
                            cmbInvoiceType.DisplayMember = "Name";
                            cmbInvoiceType.ValueMember = "Id";
                            datatable.Rows.Remove(datatable.Rows[index]);

                        }

                    }

                }
                else
                {
                    btnAddProduct.Enabled = false;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        private void PopulateInvoiceType()
        {
            try
            {
                datatable = invoiceTypeDelegate.GetAllInvoiceTypes();
                cmbInvoiceType.DataSource = datatable;
                cmbInvoiceType.DisplayMember = "Name";
                cmbInvoiceType.ValueMember = "Id";

            }
            catch (Exception exception)
            {

                Utility objUtility = new Utility();
                objUtility.WriteLog("form Manage Products method populateInvoiceType" + exception.Message + DateTime.Now);
            }

        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            try
            {
                ///int cellCount = dgvProducts.ColumnCount;
                foreach (DataGridViewColumn column in dgvProducts.Columns)
                {
                    Visible = true;  
                }
                ProductsDelegate productsDelegate = new ProductsDelegate();
                var productName = txtSearchProduct.Text;
                DataTable dtProduct = new DataTable();
                dgvProducts.Visible = true;
                dtProduct = productsDelegate.GetProductByName(productName);
                dgvProducts.DataSource = dtProduct;
            }
            catch (Exception exception)
            {

                Utility objUtility = new Utility();
                objUtility.WriteLog("form Manage Products method btnSearchProduct_Click" + exception.Message + DateTime.Now);
            }


        }


        private void dgvProducts_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (IsFormLoaded)
            {
              
                  if (dgvProducts.Rows.Count > 0)
                    {
                        ckbChangeName.Visible = true;
                        int cell = dgvProducts.CurrentCell.ColumnIndex;
                        string columnName = dgvProducts.Columns[cell].Name.ToString();
                          if (columnName != "dgvColCode" && columnName != "Product")
                        {
                                int code = Convert.ToInt32(dgvProducts.Rows[e.RowIndex].Cells["dgvColCode"].Value);

                                if (dgvProducts.Rows[e.RowIndex].Cells[cell].Value.ToString()==string.Empty)
                                {
                                    grpBoxProductEdit.Enabled = true;
                                    txtProductName.Enabled = true;
                                    txtProductCode.Enabled = true;
                                    cmbInvoiceType.Enabled = true;
                                    txtProductPrice.Enabled = true;         
                                    rdbtnActive.Enabled = true;
                                    rdbtnInActive.Enabled = true;
                                    txtProductCode.Text = dgvProducts.Rows[e.RowIndex].Cells["dgvColCode"].Value.ToString();
                                    txtProductName.Text = dgvProducts.Rows[e.RowIndex].Cells["Product"].Value.ToString();
                                    txtProductPrice.Text = "";
                                    cmbInvoiceType.Text = columnName;
                                    rdbtnInActive.Checked = true;
                                    grpBoxOperations.Visible = false;
                                    grpBoxSave.Visible = true;
                                   
                                }
                                else
                                {
                                    GetProductDataByCodeAndInvoiceType(code, columnName);  
                                }

                              
                               
                        }
                          else
                          {
                              txtProductCode.Text = dgvProducts.Rows[e.RowIndex].Cells["dgvColCode"].Value.ToString();
                              txtProductName.Text = dgvProducts.Rows[e.RowIndex].Cells["Product"].Value.ToString();
                              cmbInvoiceType.Text = "--Select--";
                              txtProductPrice.Text = "";
                              rdbtnInActive.Checked = true;
                          }
                       
                    } 
              
            }

        }

  
        private void GetProductDataByCodeAndInvoiceType(int code, string columnName)
        {
           
                ProductsDelegate productsDelegate = new ProductsDelegate();
                DataTable dataTable = new DataTable();
                dataTable = productsDelegate.GetProductInfoByCodeAndInvoiceType(code, columnName);
              
                        if (dataTable.Rows.Count > 0)
                        {

                            ProductID = Convert.ToInt32(dataTable.Rows[0]["ID"]);
                            lblProductID.Text = dataTable.Rows[0]["ID"].ToString();
                            txtProductName.Text = dataTable.Rows[0]["ProductName"].ToString();
                            txtProductCode.Text = dataTable.Rows[0]["Code"].ToString();
                            cmbInvoiceType.SelectedValue = dataTable.Rows[0]["InvoiceTypeID"].ToString();
                            txtProductPrice.Text = dataTable.Rows[0]["Price"].ToString();
                            int active = Convert.ToInt32(dataTable.Rows[0]["IsActive"]);
                            if (active == 1)
                            {
                                rdbtnActive.Checked = true;
                            }
                            else
                            {
                                rdbtnInActive.Checked = true;

                            }

                        }

          }

        private void btnSaveInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                ProductsDelegate productsDelegate = new ProductsDelegate();
                ProductsModel productsModel = new ProductsModel();
                DataTable dataTable = new DataTable();

                productsModel.Name = txtProductName.Text.Trim();
                productsModel.Code = txtProductCode.Text.Trim();
              
                bool flag = false;
                flag = productsDelegate.UpdateProductNameByCode(productsModel);
                if (flag)
                {
                    MessageBox.Show("Product Operation Successfull");
                    PopulateProducts();
                }
                else
                {
                    MessageBox.Show("Product Operation UnSuccessfull");
                }
            }
            catch (Exception exception)
            {

                Utility utility = new Utility();
                utility.WriteLog("form Manage product Method btnSaveInvoice_Click"+exception.Message+DateTime.Now);
            }
            
        }

        private void btnExitProduct_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ckbChangeName_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbChangeName.Checked==true)
            {
                grpBoxSave.Visible = false;
                grpSaveInvoice.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpSaveInvoice.Visible = true;
                txtProductCode.Enabled = false;
                txtProductPrice.Enabled = false;
                cmbInvoiceType.Enabled = false;
                rdbtnActive.Enabled = false;
                rdbtnInActive.Enabled = false;
            }
            else if (ckbChangeName.Checked == false)
            {
                grpBoxSave.Visible = true;
                grpSaveInvoice.Visible = false;
                txtProductCode.Enabled = true;
                txtProductPrice.Enabled = true;
                cmbInvoiceType.Enabled = true;
                rdbtnActive.Enabled = true;
                rdbtnInActive.Enabled = true;   
            }
           
        }

        
        private void txtProductPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 8 || (e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 46)
            {
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
