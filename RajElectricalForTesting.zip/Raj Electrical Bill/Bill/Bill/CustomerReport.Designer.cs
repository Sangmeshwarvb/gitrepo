﻿namespace Bill
{
    partial class CustomerReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFilterHolder = new System.Windows.Forms.Panel();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbCustomerName = new System.Windows.Forms.ComboBox();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.btnGenerateReport = new System.Windows.Forms.Button();
            this.dgvCustomerReport = new System.Windows.Forms.DataGridView();
            this.dtColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtColInvoiceDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtColTotalRs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtColTotalPs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTotalText = new System.Windows.Forms.Label();
            this.lblTotalSaleValue = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.pnlFilterHolder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerReport)).BeginInit();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFilterHolder
            // 
            this.pnlFilterHolder.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlFilterHolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFilterHolder.Controls.Add(this.dtpEndDate);
            this.pnlFilterHolder.Controls.Add(this.dtpStartDate);
            this.pnlFilterHolder.Controls.Add(this.cmbCustomerName);
            this.pnlFilterHolder.Controls.Add(this.lblEndDate);
            this.pnlFilterHolder.Controls.Add(this.lblStartDate);
            this.pnlFilterHolder.Controls.Add(this.lblCustomerName);
            this.pnlFilterHolder.Controls.Add(this.btnGenerateReport);
            this.pnlFilterHolder.Location = new System.Drawing.Point(69, 47);
            this.pnlFilterHolder.Name = "pnlFilterHolder";
            this.pnlFilterHolder.Size = new System.Drawing.Size(662, 100);
            this.pnlFilterHolder.TabIndex = 1;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(381, 40);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(136, 20);
            this.dtpEndDate.TabIndex = 5;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(204, 40);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(136, 20);
            this.dtpStartDate.TabIndex = 5;
            // 
            // cmbCustomerName
            // 
            this.cmbCustomerName.FormattingEnabled = true;
            this.cmbCustomerName.Location = new System.Drawing.Point(20, 39);
            this.cmbCustomerName.Name = "cmbCustomerName";
            this.cmbCustomerName.Size = new System.Drawing.Size(157, 21);
            this.cmbCustomerName.TabIndex = 4;
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDate.Location = new System.Drawing.Point(378, 12);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(73, 18);
            this.lblEndDate.TabIndex = 3;
            this.lblEndDate.Text = "End Date:";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(201, 12);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(78, 18);
            this.lblStartDate.TabIndex = 2;
            this.lblStartDate.Text = "Start Date:";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.Location = new System.Drawing.Point(17, 12);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(122, 18);
            this.lblCustomerName.TabIndex = 1;
            this.lblCustomerName.Text = "Customer Name:";
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnGenerateReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateReport.ForeColor = System.Drawing.Color.White;
            this.btnGenerateReport.Location = new System.Drawing.Point(567, 37);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(80, 30);
            this.btnGenerateReport.TabIndex = 0;
            this.btnGenerateReport.Text = "Generate";
            this.btnGenerateReport.UseVisualStyleBackColor = false;
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // dgvCustomerReport
            // 
            this.dgvCustomerReport.AllowUserToAddRows = false;
            this.dgvCustomerReport.AllowUserToDeleteRows = false;
            this.dgvCustomerReport.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvCustomerReport.BackgroundColor = System.Drawing.Color.White;
            this.dgvCustomerReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dtColName,
            this.dtColInvoiceDate,
            this.dtColTotalRs,
            this.dtColTotalPs});
            this.dgvCustomerReport.Location = new System.Drawing.Point(69, 154);
            this.dgvCustomerReport.Name = "dgvCustomerReport";
            this.dgvCustomerReport.ReadOnly = true;
            this.dgvCustomerReport.RowHeadersVisible = false;
            this.dgvCustomerReport.Size = new System.Drawing.Size(662, 300);
            this.dgvCustomerReport.TabIndex = 2;
            this.dgvCustomerReport.DataSourceChanged += new System.EventHandler(this.dgvCustomerReport_DataSourceChanged);
            // 
            // dtColName
            // 
            this.dtColName.DataPropertyName = "Name";
            this.dtColName.HeaderText = "Name";
            this.dtColName.Name = "dtColName";
            this.dtColName.ReadOnly = true;
            this.dtColName.Width = 200;
            // 
            // dtColInvoiceDate
            // 
            this.dtColInvoiceDate.DataPropertyName = "InvoiceDate";
            this.dtColInvoiceDate.HeaderText = "Date";
            this.dtColInvoiceDate.Name = "dtColInvoiceDate";
            this.dtColInvoiceDate.ReadOnly = true;
            // 
            // dtColTotalRs
            // 
            this.dtColTotalRs.DataPropertyName = "TotalRs";
            this.dtColTotalRs.HeaderText = "Rupees";
            this.dtColTotalRs.Name = "dtColTotalRs";
            this.dtColTotalRs.ReadOnly = true;
            // 
            // dtColTotalPs
            // 
            this.dtColTotalPs.DataPropertyName = "TotalPs";
            this.dtColTotalPs.HeaderText = "Paise";
            this.dtColTotalPs.Name = "dtColTotalPs";
            this.dtColTotalPs.ReadOnly = true;
            // 
            // lblTotalText
            // 
            this.lblTotalText.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTotalText.AutoSize = true;
            this.lblTotalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalText.Location = new System.Drawing.Point(66, 472);
            this.lblTotalText.Name = "lblTotalText";
            this.lblTotalText.Size = new System.Drawing.Size(83, 16);
            this.lblTotalText.TabIndex = 3;
            this.lblTotalText.Text = "Total Sales :";
            // 
            // lblTotalSaleValue
            // 
            this.lblTotalSaleValue.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTotalSaleValue.AutoSize = true;
            this.lblTotalSaleValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSaleValue.Location = new System.Drawing.Point(160, 472);
            this.lblTotalSaleValue.Name = "lblTotalSaleValue";
            this.lblTotalSaleValue.Size = new System.Drawing.Size(28, 16);
            this.lblTotalSaleValue.TabIndex = 3;
            this.lblTotalSaleValue.Text = "0.0";
            // 
            // btnExit
            // 
            this.btnExit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(360, 465);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoSize = true;
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(800, 23);
            this.pnlHeader.TabIndex = 11;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(328, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(145, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Customer Reports";
            // 
            // CustomerReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 507);
            this.ControlBox = false;
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblTotalSaleValue);
            this.Controls.Add(this.lblTotalText);
            this.Controls.Add(this.dgvCustomerReport);
            this.Controls.Add(this.pnlFilterHolder);
            this.Name = "CustomerReport";
            this.Text = "CustomerReport";
            this.Load += new System.EventHandler(this.CustomerReport_Load);
            this.Shown += new System.EventHandler(this.CustomerReport_Shown);
            this.pnlFilterHolder.ResumeLayout(false);
            this.pnlFilterHolder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerReport)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlFilterHolder;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.ComboBox cmbCustomerName;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Button btnGenerateReport;
        private System.Windows.Forms.DataGridView dgvCustomerReport;
        private System.Windows.Forms.Label lblTotalText;
        private System.Windows.Forms.Label lblTotalSaleValue;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtColName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtColInvoiceDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtColTotalRs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtColTotalPs;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
    }
}