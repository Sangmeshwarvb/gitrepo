﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Constants;
using Bill.Delegate;
using Bill.Model;
using Bill.Utilities;

namespace Bill
{
    public partial class ManageInvoiceType : Form
    {
        public ManageInvoiceType()
        {
            InitializeComponent();
        }
       

        private void btnExit_Click(object sender, EventArgs e)//this is Cancel Button Code which is with Add,Edit
        {
            this.Close();
        }

        private void ManageInvoiceType_Load(object sender, EventArgs e)
        {
            Utility utility = new Utility();
            try
            {
                PopulateInvoiceTypes();
            }
            catch (Exception exception)
            {
                utility.WriteLog("ManageInvoiceType_Load error:" + exception.Message + " " + DateTime.Now);
            }

        }

        private void PopulateInvoiceTypes()
        {
            try
            {
                InvoiceTypeDelegate invoiceTypeDelegate = new InvoiceTypeDelegate();
                DataTable dtInvoiceTypes = invoiceTypeDelegate.GetAllInvoiceTypes();
                dgvInvoiceTypes.DataSource = dtInvoiceTypes;
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageInvoiceType_PopulateInvoiceType " + exception + " " + DateTime.Now);
            }

        }

        private void ManageInvoiceType_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                grpBoxInvoiceEdit.Enabled = false;
                grpBoxOperations.Visible = true;
                grpBoxSave.Visible = false;
                if (dgvInvoiceTypes.Rows.Count > 0)
                {
                    txtInvoiceName.Text = dgvInvoiceTypes.Rows[0].Cells["InvoiceType"].Value.ToString();
                    bool activeStatus = Convert.ToBoolean(dgvInvoiceTypes.Rows[0].Cells["IsActive"].Value);
                    if (activeStatus == ApplicationConstants.ActiveIndicator)
                    {
                        rdbtnActive.Checked = true;
                        rdbtnInActive.Checked = false;
                    }
                    else
                    {
                        rdbtnActive.Checked = false;
                        rdbtnInActive.Checked = true;
                    }

                    dgvInvoiceTypes.CurrentCell = dgvInvoiceTypes.Rows[0].Cells["InvoiceType"];
                    dgvInvoiceTypes.BeginEdit(true);
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageInvoiceType_btnCancel_Click " + exception + " " + DateTime.Now);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                btnSave.Tag = ApplicationConstants.OperationUpdate;
                grpBoxInvoiceEdit.Enabled = true;
                grpBoxOperations.Visible = false;
                grpBoxSave.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpBoxSave.Visible = true;
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageInvoiceType_btnEdit_Click " + exception + " " + DateTime.Now);
            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                btnSave.Tag = ApplicationConstants.OperationInsert;
                grpBoxOperations.Visible = false;
                grpBoxSave.Location = new Point(grpBoxOperations.Location.X, grpBoxOperations.Location.Y);
                grpBoxSave.Visible = true;
                grpBoxInvoiceEdit.Enabled = true;
                txtInvoiceName.Text = string.Empty;
                rdbtnActive.Checked = true;
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ManageInvoiceType_btnAddNew_Click " + exception + " " + DateTime.Now);
            }
        }

        private void dgvInvoiceTypes_RowEnter(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                if (dgvInvoiceTypes.Rows.Count > 0)
                {
                    txtInvoiceName.Text = dgvInvoiceTypes.Rows[e.RowIndex].Cells["InvoiceType"].Value.ToString();
                    bool activeStatus = Convert.ToBoolean(dgvInvoiceTypes.Rows[e.RowIndex].Cells["IsActive"].Value);
                    if (activeStatus == ApplicationConstants.ActiveIndicator)
                    {
                        rdbtnActive.Checked = true;
                        rdbtnInActive.Checked = false;
                    }
                    else
                    {
                        rdbtnActive.Checked = false;
                        rdbtnInActive.Checked = true;
                    }
                }
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("dgvInvoiceTypes_RowEnter error:" + exception.Message + " " + DateTime.Now);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dataTable = new DataTable();
                InvoiceTypeDelegate invoiceTypeDelegate = new InvoiceTypeDelegate();
                if (txtInvoiceName.Text.Trim().Length > 1)
                {
                    InvoiceTypeModel invoiceTypeModel = new InvoiceTypeModel();
                    if (dgvInvoiceTypes.Rows.Count > 0)
                    {
                        invoiceTypeModel.Id = Convert.ToInt32(dgvInvoiceTypes.CurrentRow.Cells["InvoiceId"].Value);
                    }
                    invoiceTypeModel.Name = txtInvoiceName.Text.Trim();
                    if (rdbtnActive.Checked == true)
                    {
                        invoiceTypeModel.Active = ApplicationConstants.ActiveIndicator;
                        
                    }
                    else
                    {
                        invoiceTypeModel.Active = ApplicationConstants.InActiveIndicator;
                       
                    }
                          bool result = false;
                            if (btnSave.Tag == ApplicationConstants.OperationInsert)
                            {
                                string invoiceTypeName = txtInvoiceName.Text;
                                dataTable = invoiceTypeDelegate.GetInvoiceTypesByName(invoiceTypeName);
                                if (dataTable.Rows.Count>0)
                                {
                                    MessageBox.Show("this invoice type already Exits.Please try with another name");
                                    
                                }
                                else
                                {
                                    result = invoiceTypeDelegate.SaveInvoiceType(invoiceTypeModel);
                                }
                               
                            }
                            else if (btnSave.Tag == ApplicationConstants.OperationUpdate)
                            {
                                string invoiceNamedgv = dgvInvoiceTypes.CurrentRow.Cells["InvoiceType"].Value.ToString();
                                if (txtInvoiceName.Text==invoiceNamedgv)
                                {
                                    result = invoiceTypeDelegate.UpdateInvoiceType(invoiceTypeModel);
                                }
                                else
                                {
                                    string invoiceTypeName = txtInvoiceName.Text;
                                    dataTable = invoiceTypeDelegate.GetInvoiceTypesByName(invoiceTypeName);
                                    if (dataTable.Rows.Count > 0)
                                    {
                                        MessageBox.Show("this invoice type already Exits.Please try with another name");

                                    }
                                    else
                                    {
                                        result = invoiceTypeDelegate.UpdateInvoiceType(invoiceTypeModel);
                                    }
                                }
                                 
                            }
                            if (result)
                            {
                                MessageBox.Show("InvoiceType process successfull.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                PopulateInvoiceTypes();
                                grpBoxInvoiceEdit.Enabled = false;
                                grpBoxOperations.Enabled = true;
                                grpBoxSave.Visible = false;
                                grpBoxOperations.Visible = true;
                            }
                            else
                            {
                                MessageBox.Show("InvoiceType process unsuccessfull.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }


                        }
                        
 
                else
                {
                    MessageBox.Show("Please fill all the details.", "Error", MessageBoxButtons.OK);
                }
            }
            catch (Exception exception)
            {
                Utility utility = new Utility();
                utility.WriteLog("btnSave_Click error:" + exception.Message + " " + DateTime.Now);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = false;
                InvoiceTypeDelegate invoiceTypeDelegate = new InvoiceTypeDelegate();
                if (MessageBox.Show("Do you want to delete this  invoice type?", "System Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                     int invoiceId = Convert.ToInt32(dgvInvoiceTypes.CurrentRow.Cells["InvoiceId"].Value);
                     flag=invoiceTypeDelegate.DeleteInvoiceType(invoiceId);
                     if (flag)
                     {
                      MessageBox.Show("Invoice Type Deleted Successfully ") ;
                     }
                     else
	                {
                     MessageBox.Show("Invoice Type Not Deleted"); 
	                }
                     PopulateInvoiceTypes();
               }
            }
            catch (Exception exception)
            {
             Utility utility=new Utility();
             utility.WriteLog("form ManageInvoiceType Method btnDelete_Click " + exception.Message + DateTime.Now);
             
            }
        }
    }
}
