﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    internal class InvoicesService
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public InvoicesService(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveBill(Model.InvoicesModel invoicesModel)
        {
            bool result = false;
            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                result = invoicesHandler.SaveBill(invoicesModel);
                if (result)
                {
                    int invoiceId = invoicesHandler.GetLastInvoiceId();
                    foreach (var invoiceItem in invoicesModel.InvoiceItems)
                    {
                        invoiceItem.InvoiceId = invoiceId;
                        InvoiceDetailHandler invoiceDetailHandler = new InvoiceDetailHandler(oledbConnection, oledbTransaction);
                        result = invoiceDetailHandler.SaveInvoice(invoiceItem);
                        if (result == false)
                            break;
                    }
                }
                return result;
            }
            catch (Exception exception)
            {
                result = false;
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal int GetLastBillId()
        {

            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                return invoicesHandler.GetLastInvoiceId();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetInvoiceByDate(string startDate, string endDate)
        {
            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                return invoicesHandler.GetInvoiceByDate(startDate, endDate);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetInvoiceDetailsById(int id)
        {
            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                return invoicesHandler.GetInvoiceDetailsById(id);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetReportInvoiceData(int id)
        {
            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                return invoicesHandler.GetReportInvoiceData(id);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool DeleteBills(string deleteIds)
        {
            bool result = false;
            try
            {
                InvoicesHandler invoicesHandler = new InvoicesHandler(oledbConnection, oledbTransaction);
                result = invoicesHandler.DeleteBills(deleteIds);
                return result;
            }
            catch (Exception exception)
            {
                result = false;
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
