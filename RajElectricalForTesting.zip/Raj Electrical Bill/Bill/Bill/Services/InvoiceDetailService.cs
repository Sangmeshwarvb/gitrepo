﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    internal class InvoiceDetailService
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public InvoiceDetailService(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }
        internal bool SaveInvoice(Model.InvoiceDetailModel invoiceItem)
        {
            bool result = false;
            try
            {
                InvoiceDetailHandler invoiceDetailHandler = new InvoiceDetailHandler(oledbConnection, oledbTransaction);
                result = invoiceDetailHandler.SaveInvoice(invoiceItem);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetReportInvoiceDetailData(int id)
        {
            try
            {
                InvoiceDetailHandler invoiceDetailHandler = new InvoiceDetailHandler(oledbConnection, oledbTransaction);
                return invoiceDetailHandler.GetReportInvoiceDetailData(id);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
