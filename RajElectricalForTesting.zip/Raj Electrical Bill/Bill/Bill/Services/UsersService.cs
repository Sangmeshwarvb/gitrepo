﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    internal class UsersService
    {
        private OleDbConnection oledbConnection;
        private OleDbTransaction oledbTransaction;

        public UsersService(OleDbConnection oledbConnection, OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal DataTable GetUsers(bool activeIndicator)
        {
            try
            {
                UsersHandler usersHandler = new UsersHandler(oledbConnection, oledbTransaction);
                return usersHandler.GetUsers(activeIndicator);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool SaveUser(Model.UsersModel usersModel)
        {
            try
            {
                UsersHandler usersHandler = new UsersHandler(oledbConnection, oledbTransaction);
                return usersHandler.SaveUser(usersModel);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal DataTable GetUserByName(string userName)
        {
            try
            {
                UsersHandler usersHandler = new UsersHandler(oledbConnection, oledbTransaction);
                return usersHandler.GetUserByName(userName);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
