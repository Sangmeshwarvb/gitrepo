﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    internal class ProductsService
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public ProductsService(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal System.Data.DataTable GetAllProducts(bool activeIndicator)
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection,oledbTransaction);
                return productsHandler.GetAllProducts(activeIndicator);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool SaveProduct(Model.ProductsModel productsModel)
        {
            bool result = false;
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                result=  productsHandler.SaveProduct(productsModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool UpdateProduct(Model.ProductsModel productsModel)
        {
            bool result = false;
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                result = productsHandler.UpdateProduct(productsModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetAllProducts()
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                return productsHandler.GetAllProducts();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetProductsByInvoicesType(bool activeIndicator, int invoicestype)
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                return productsHandler.GetProductsByInvoicesType(activeIndicator, invoicestype);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetAllProductsByCode(string Code)
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                return productsHandler.GetAllProductsByCode(Code);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetProductByName(string productName)
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                return productsHandler.GetProductByName(productName);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }





        internal System.Data.DataTable GetProductInfoByCodeAndInvoiceType(int code, string columnName)
        {
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                return productsHandler.GetProductInfoByCodeAndInvoiceType(code, columnName);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool UpdateProductNameByCode(Model.ProductsModel productsModel)
        {
            bool result = false;
            try
            {
                ProductsHandler productsHandler = new ProductsHandler(oledbConnection, oledbTransaction);
                result = productsHandler.UpdateProductNameByCode(productsModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
