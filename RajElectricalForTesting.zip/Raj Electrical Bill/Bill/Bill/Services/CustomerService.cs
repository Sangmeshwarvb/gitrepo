﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    class CustomerService
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public CustomerService(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveCustomer(Model.CustomerModel customerModel)
        {
            bool result = false;
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                result = customerHandler.SaveCustomer(customerModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool UpdateCustomer(Model.CustomerModel customerModel)
        {
            bool result = false;
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                result = customerHandler.UpdateCustomer(customerModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetAllCustomers()
        {
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                return customerHandler.GetAllCustomers();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetAllCustomers(bool activeIndicator)
        {
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                return customerHandler.GetAllCustomers(activeIndicator);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetCustomerReport(int customerId, DateTime startDate, DateTime endDate)
        {
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                return customerHandler.GetCustomerReport(customerId, startDate, endDate);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetAllCustomersByName(string name)
        {
            try
            {
                CustomerHandler customerHandler = new CustomerHandler(oledbConnection, oledbTransaction);
                return customerHandler.GetAllCustomersByName(name);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
