﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Bill.Handler;

namespace Bill.Services
{
    internal class InvoiceTypeService
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public InvoiceTypeService(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal System.Data.DataTable GetInvoiceTypes(bool activeIndicator)
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.GetInvoiceTypes(activeIndicator);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal DataTable GetAllInvoiceTypes()
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.GetAllInvoiceTypes();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool UpdateInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.UpdateInvoiceType(invoiceTypeModel);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool SaveInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.SaveInvoiceType(invoiceTypeModel);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal DataTable GetInvoiceTypesByName(string invoiceTypeName)
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.GetInvoiceTypesByName(invoiceTypeName);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool DeleteInvoiceType(int invoiceId)
        {
            try
            {
                InvoiceTypeHandler invoiceTypeHandler = new InvoiceTypeHandler(oledbConnection, oledbTransaction);
                return invoiceTypeHandler.DeleteInvoiceType(invoiceId);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                oledbTransaction.Commit();
                if (oledbConnection.State != ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
