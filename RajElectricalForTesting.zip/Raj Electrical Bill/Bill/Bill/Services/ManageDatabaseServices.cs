﻿using Bill.Handler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Services
{
    class ManageDatabaseServices
    {
          private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public ManageDatabaseServices(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveBackupDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            bool result = false;
            try
            {
                ManageDatabaseHandler manageDatabaseHandler = new ManageDatabaseHandler(oledbConnection, oledbTransaction);
                result = manageDatabaseHandler.SaveBackupDetails(objManageDatabaseModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal bool SaveRestoreDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {

            bool result = false;
            try
            {
                ManageDatabaseHandler manageDatabaseHandler = new ManageDatabaseHandler(oledbConnection, oledbTransaction);
                result = manageDatabaseHandler.SaveRestoreDetails(objManageDatabaseModel);
                return result;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (result)
                {
                    oledbTransaction.Commit();
                }
                else
                {
                    oledbTransaction.Rollback();
                }
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        
        }

        internal System.Data.DataTable GetBackUpDetails()
        {

            try
            {
                ManageDatabaseHandler manageDatabaseHandler = new ManageDatabaseHandler(oledbConnection, oledbTransaction);
                return manageDatabaseHandler.GetBackUpDetails();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }

        internal System.Data.DataTable GetRestoreDetails()
        {

            try
            {
                ManageDatabaseHandler manageDatabaseHandler = new ManageDatabaseHandler(oledbConnection, oledbTransaction);
                return manageDatabaseHandler.GetRestoreDetails();
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (oledbConnection.State != System.Data.ConnectionState.Closed)
                {
                    oledbConnection.Close();
                }
            }
        }
    }
}
