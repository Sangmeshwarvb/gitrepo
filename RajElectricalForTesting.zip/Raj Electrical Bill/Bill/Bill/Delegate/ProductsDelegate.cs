﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Facade;
using Bill.Model;

namespace Bill.Delegate
{
    public class ProductsDelegate
    {
        internal System.Data.DataTable GetAllProducts(bool activeIndicator)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetAllProducts(activeIndicator);
        }

        internal bool UpdateProduct(Model.ProductsModel productsModel)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.UpdateProduct(productsModel);
        }

        internal bool SaveProduct(Model.ProductsModel productsModel)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.SaveProduct(productsModel);
        }

        internal System.Data.DataTable GetAllProducts()
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetAllProducts();
        }

        internal System.Data.DataTable GetProductsByInvoicesType(bool activeIndicator, int invoicestype)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetProductsByInvoicesType(activeIndicator, invoicestype);
        }

       

        internal System.Data.DataTable GetAllProductsByCode(string Code)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetAllProductsByCode(Code);
        }

        internal System.Data.DataTable GetProductByName(string productName)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetProductByName(productName);
        }

        internal System.Data.DataTable GetProductInfoByCodeAndInvoiceType(int code, string columnName)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.GetProductInfoByCodeAndInvoiceType(code,columnName);
        }

        internal bool UpdateProductNameByCode(ProductsModel productsModel)
        {
            ProductsFacade productsFacade = new ProductsFacade();
            return productsFacade.UpdateProductNameByCode(productsModel);
        }
    }
}
