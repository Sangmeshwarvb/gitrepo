﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Facade;

namespace Bill.Delegate
{
    class CustomerDelegate
    {
        internal bool SaveCustomer(Model.CustomerModel customerModel)
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.SaveCustomer(customerModel);
        }

        internal bool UpdateCustomer(Model.CustomerModel customerModel)
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.UpdateCustomer(customerModel);
        }

        internal System.Data.DataTable GetAllCustomers()
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.GetAllCustomers();
        }

        internal System.Data.DataTable GetAllCustomers(bool activeIndicator)
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.GetAllCustomers(activeIndicator);
        }

        internal System.Data.DataTable GetCustomerReport(int customerId, DateTime startDate, DateTime endDate)
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.GetCustomerReport(customerId, startDate, endDate);
        }

        internal System.Data.DataTable GetAllCustomersByName(string name)
        {
            CustomerFacade customerFacade = new CustomerFacade();
            return customerFacade.GetAllCustomersByName(name);
        }
    }
}
