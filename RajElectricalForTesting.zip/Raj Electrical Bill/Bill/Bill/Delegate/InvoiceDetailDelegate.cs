﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Facade;

namespace Bill.Delegate
{
    public class InvoiceDetailDelegate
    {
        internal System.Data.DataTable GetReportInvoiceDetailData(int id)
        {
            InvoiceDetailFacade invoiceDetailFacade = new InvoiceDetailFacade();
            return invoiceDetailFacade.GetReportInvoiceDetailData(id);
        }
    }
}
