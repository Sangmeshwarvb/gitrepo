﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Facade;

namespace Bill.Delegate
{
    public class InvoiceTypeDelegate
    {
        internal System.Data.DataTable GetInvoiceTypes(bool activeIndicator)
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.GetInvoiceTypes(activeIndicator);
        }

        internal System.Data.DataTable GetAllInvoiceTypes()
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.GetAllInvoiceTypes();
        }

        internal bool SaveInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.SaveInvoiceType(invoiceTypeModel);
        }

        internal bool UpdateInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.UpdateInvoiceType(invoiceTypeModel);
        }

        internal System.Data.DataTable GetInvoiceTypesByName(string invoiceTypeName)
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.GetInvoiceTypesByName(invoiceTypeName);
        }

        internal bool DeleteInvoiceType(int invoiceId)
        {
            InvoiceTypeFacade invoiceTypeFacade = new InvoiceTypeFacade();
            return invoiceTypeFacade.DeleteInvoiceType(invoiceId);
        }
    }
}
