﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Facade;

namespace Bill.Delegate
{
    public class InvoicesDelegate
    {
        internal bool SaveBill(Model.InvoicesModel invoicesModel)
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.SaveBill(invoicesModel);
        }

        internal int GetLastBillId()
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.GetLastBillId();
        }

        internal System.Data.DataTable GetInvoiceByDate(string startDate, string endDate)
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.GetInvoiceByDate(startDate, endDate);
        }

        internal System.Data.DataTable GetInvoiceDetailsById(int id)
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.GetInvoiceDetailsById(id);
        }

        internal System.Data.DataTable GetReportInvoiceData(int id)
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.GetReportInvoiceData(id);
        }

        internal bool DeleteBills(string deleteIds)
        {
            InvoicesFacade invoicesFacade = new InvoicesFacade();
            return invoicesFacade.DeleteBills(deleteIds);
        }
    }
}
