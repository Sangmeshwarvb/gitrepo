﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Bill.Facade;

namespace Bill.Delegate
{
    public class UsersDelegate
    {

        internal DataTable GetUsers(bool activeIndicator)
        {
            UsersFacade usersFacade = new UsersFacade();
            return usersFacade.GetUsers(activeIndicator);
        }

        internal bool SaveUser(Model.UsersModel usersModel)
        {
            UsersFacade usersFacade = new UsersFacade();
            return usersFacade.SaveUser(usersModel);
        }

        internal DataTable GetUserByName(string userName)
        {
            UsersFacade usersFacade = new UsersFacade();
            return usersFacade.GetUserByName(userName);
        }
    }
}
