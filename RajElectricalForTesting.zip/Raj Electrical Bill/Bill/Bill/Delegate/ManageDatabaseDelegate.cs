﻿using Bill.Facade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Delegate
{
    class ManageDatabaseDelegate
    {
        internal bool SaveBackupDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            ManageDatabaseFacade manageDatabaseFacade = new ManageDatabaseFacade();
            return manageDatabaseFacade.SaveBackupDetails(objManageDatabaseModel);
        
        }

        internal bool SaveRestoreDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            ManageDatabaseFacade manageDatabaseFacade = new ManageDatabaseFacade();
            return manageDatabaseFacade.SaveRestoreDetails(objManageDatabaseModel);
        }

        internal System.Data.DataTable GetBackUpDetails()
        {
            ManageDatabaseFacade manageDatabaseFacade = new ManageDatabaseFacade();
            return manageDatabaseFacade.GetBackUpDetails();
        }

        internal System.Data.DataTable GetRestoreDetails()
        {
            ManageDatabaseFacade manageDatabaseFacade = new ManageDatabaseFacade();
            return manageDatabaseFacade.GetRestoreDetails();
        }
    }
}
