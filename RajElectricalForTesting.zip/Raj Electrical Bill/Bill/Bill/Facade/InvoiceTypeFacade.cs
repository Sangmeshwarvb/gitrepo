﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;

namespace Bill.Facade
{
    public class InvoiceTypeFacade : BaseFacade
    {
        internal System.Data.DataTable GetInvoiceTypes(bool activeIndicator)
        {
            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.GetInvoiceTypes(activeIndicator);
        }

        internal System.Data.DataTable GetAllInvoiceTypes()
        {
            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.GetAllInvoiceTypes();
        }

        internal bool UpdateInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {

            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.UpdateInvoiceType(invoiceTypeModel);
        }

        internal bool SaveInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {

            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.SaveInvoiceType(invoiceTypeModel);
        }

        internal System.Data.DataTable GetInvoiceTypesByName(string invoiceTypeName)
        {
            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.GetInvoiceTypesByName(invoiceTypeName);
        }

        internal bool DeleteInvoiceType(int invoiceId)
        {
            InvoiceTypeService invoiceTypeService = new InvoiceTypeService(oledbConnection, oledbTransaction);
            return invoiceTypeService.DeleteInvoiceType(invoiceId);
        }
    }
}
