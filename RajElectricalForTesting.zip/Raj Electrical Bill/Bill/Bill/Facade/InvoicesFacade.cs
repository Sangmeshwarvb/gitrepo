﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;

namespace Bill.Facade
{
    public class InvoicesFacade : BaseFacade
    {
        internal bool SaveBill(Model.InvoicesModel invoicesModel)
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.SaveBill(invoicesModel);
        }

        internal int GetLastBillId()
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.GetLastBillId();
        }

        internal System.Data.DataTable GetInvoiceByDate(string startDate, string endDate)
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.GetInvoiceByDate(startDate, endDate);
        }

        internal System.Data.DataTable GetInvoiceDetailsById(int id)
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.GetInvoiceDetailsById(id);
        }

        internal System.Data.DataTable GetReportInvoiceData(int id)
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.GetReportInvoiceData(id);
        }

        internal bool DeleteBills(string deleteIds)
        {
            InvoicesService invoicesService = new InvoicesService(oledbConnection, oledbTransaction);
            return invoicesService.DeleteBills(deleteIds);
        }
    }
}
