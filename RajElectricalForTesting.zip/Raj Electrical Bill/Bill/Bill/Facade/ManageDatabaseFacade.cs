﻿using Bill.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Facade
{
    class ManageDatabaseFacade:BaseFacade
    {
        internal bool SaveBackupDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            ManageDatabaseServices manageDatabaseServices = new ManageDatabaseServices(oledbConnection, oledbTransaction);
            return manageDatabaseServices.SaveBackupDetails(objManageDatabaseModel);
           
       
        }

        internal bool SaveRestoreDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            ManageDatabaseServices manageDatabaseServices = new ManageDatabaseServices(oledbConnection, oledbTransaction);
            return manageDatabaseServices.SaveRestoreDetails(objManageDatabaseModel);
           
        }

        internal System.Data.DataTable GetBackUpDetails()
        {
            ManageDatabaseServices manageDatabaseServices = new ManageDatabaseServices(oledbConnection, oledbTransaction);
            return manageDatabaseServices.GetBackUpDetails();
           
           
        }

        internal System.Data.DataTable GetRestoreDetails()
        {
            ManageDatabaseServices manageDatabaseServices = new ManageDatabaseServices(oledbConnection, oledbTransaction);
            return manageDatabaseServices.GetRestoreDetails();
           
        }
    }
}
