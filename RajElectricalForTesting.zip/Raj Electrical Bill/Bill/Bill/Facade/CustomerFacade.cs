﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;

namespace Bill.Facade
{
    class CustomerFacade: BaseFacade
    {

        internal bool SaveCustomer(Model.CustomerModel customerModel)
        {
            CustomerService customerService = new CustomerService(oledbConnection,oledbTransaction);
            return customerService.SaveCustomer(customerModel);
        }

        internal bool UpdateCustomer(Model.CustomerModel customerModel)
        {
            CustomerService customerService = new CustomerService(oledbConnection, oledbTransaction);
            return customerService.UpdateCustomer(customerModel);
        }

        internal System.Data.DataTable GetAllCustomers()
        {
            CustomerService customerService = new CustomerService(oledbConnection, oledbTransaction);
            return customerService.GetAllCustomers();
        }

        internal System.Data.DataTable GetAllCustomers(bool activeIndicator)
        {
            CustomerService customerService = new CustomerService(oledbConnection, oledbTransaction);
            return customerService.GetAllCustomers(activeIndicator);
        }

        internal System.Data.DataTable GetCustomerReport(int customerId, DateTime startDate, DateTime endDate)
        {
            CustomerService customerService = new CustomerService(oledbConnection, oledbTransaction);
            return customerService.GetCustomerReport(customerId, startDate, endDate);
        }

        internal System.Data.DataTable GetAllCustomersByName(string name)
        {
            CustomerService customerService = new CustomerService(oledbConnection, oledbTransaction);
            return customerService.GetAllCustomersByName(name);
        }
    }
}
