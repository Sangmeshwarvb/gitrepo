﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;

namespace Bill.Facade
{
    public class UsersFacade :BaseFacade
    {
        internal System.Data.DataTable GetUsers(bool activeIndicator)
        {
            UsersService usersService = new UsersService(oledbConnection, oledbTransaction);
            return usersService.GetUsers(activeIndicator);
        }

        internal bool SaveUser(Model.UsersModel usersModel)
        {
            UsersService usersService = new UsersService(oledbConnection, oledbTransaction);
            return usersService.SaveUser(usersModel);
        }

        internal System.Data.DataTable GetUserByName(string userName)
        {
            UsersService usersService = new UsersService(oledbConnection, oledbTransaction);
            return usersService.GetUserByName(userName);
        }
    }
}
