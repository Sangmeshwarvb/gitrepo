﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;

namespace Bill.Facade
{
    public class InvoiceDetailFacade : BaseFacade
    {
        internal System.Data.DataTable GetReportInvoiceDetailData(int id)
        {
            InvoiceDetailService invoiceDetailService = new InvoiceDetailService(oledbConnection, oledbTransaction);
            return invoiceDetailService.GetReportInvoiceDetailData(id);
        }
    }
}
