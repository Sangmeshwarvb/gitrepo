﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.OleDb;

namespace Bill.Facade
{
    public class BaseFacade
    {
        protected OleDbConnection oledbConnection = null;
        protected OleDbTransaction oledbTransaction = null;
        public BaseFacade()
        {
            SetConnection();
        }

        private void SetConnection()
        {
            oledbConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["AccessConnectionString"].ConnectionString);
            oledbConnection.Open();
            oledbTransaction = oledbConnection.BeginTransaction();
        }
    }
}
