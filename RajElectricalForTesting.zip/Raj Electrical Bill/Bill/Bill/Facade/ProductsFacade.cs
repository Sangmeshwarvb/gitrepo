﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.Services;
using Bill.Model;

namespace Bill.Facade
{
    public class ProductsFacade: BaseFacade
    {
        internal System.Data.DataTable GetAllProducts(bool activeIndicator)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetAllProducts(activeIndicator);
        }

        internal bool SaveProduct(Model.ProductsModel productsModel)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.SaveProduct(productsModel);
        }

        internal bool UpdateProduct(Model.ProductsModel productsModel)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.UpdateProduct(productsModel);
        }

        internal System.Data.DataTable GetAllProducts()
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetAllProducts();
        }

        internal System.Data.DataTable GetProductsByInvoicesType(bool activeIndicator, int invoicestype)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetProductsByInvoicesType(activeIndicator, invoicestype);
        }

        internal System.Data.DataTable GetAllProductsByCode(string Code)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetAllProductsByCode(Code);
        }

        internal System.Data.DataTable GetProductByName(string productName)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetProductByName(productName);
        }


        internal System.Data.DataTable GetProductInfoByCodeAndInvoiceType(int code, string columnName)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.GetProductInfoByCodeAndInvoiceType(code, columnName);
        }

        internal bool UpdateProductNameByCode(ProductsModel productsModel)
        {
            ProductsService productsService = new ProductsService(oledbConnection, oledbTransaction);
            return productsService.UpdateProductNameByCode(productsModel);
        }
    }
}
