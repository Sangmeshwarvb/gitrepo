﻿namespace Bill
{
    partial class BillMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.billToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMenuIcons = new System.Windows.Forms.Panel();
            this.grpBoxAdmin = new System.Windows.Forms.GroupBox();
            this.btnManageDatabase = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnInvoiceType = new System.Windows.Forms.Button();
            this.btnProduct = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.grpBoxBill = new System.Windows.Forms.GroupBox();
            this.btnCustomerSales = new System.Windows.Forms.Button();
            this.btnNewBill = new System.Windows.Forms.Button();
            this.btnViewInvoices = new System.Windows.Forms.Button();
            this.menuStrip.SuspendLayout();
            this.pnlMenuIcons.SuspendLayout();
            this.grpBoxAdmin.SuspendLayout();
            this.grpBoxBill.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.White;
            this.menuStrip.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.billToolStripMenuItem,
            this.adminToolStripMenuItem,
            this.exitMainToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(984, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // billToolStripMenuItem
            // 
            this.billToolStripMenuItem.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.billToolStripMenuItem.Name = "billToolStripMenuItem";
            this.billToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
            this.billToolStripMenuItem.Text = "&Bill";
            this.billToolStripMenuItem.Click += new System.EventHandler(this.billToolStripMenuItem_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.adminToolStripMenuItem.Text = "&Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // exitMainToolStripMenuItem
            // 
            this.exitMainToolStripMenuItem.Name = "exitMainToolStripMenuItem";
            this.exitMainToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.exitMainToolStripMenuItem.Text = "E&xit";
            this.exitMainToolStripMenuItem.Click += new System.EventHandler(this.exitMainToolStripMenuItem_Click);
            // 
            // pnlMenuIcons
            // 
            this.pnlMenuIcons.BackColor = System.Drawing.Color.White;
            this.pnlMenuIcons.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMenuIcons.Controls.Add(this.grpBoxAdmin);
            this.pnlMenuIcons.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMenuIcons.Location = new System.Drawing.Point(0, 24);
            this.pnlMenuIcons.Name = "pnlMenuIcons";
            this.pnlMenuIcons.Size = new System.Drawing.Size(984, 74);
            this.pnlMenuIcons.TabIndex = 12;
            // 
            // grpBoxAdmin
            // 
            this.grpBoxAdmin.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpBoxAdmin.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxAdmin.Controls.Add(this.btnManageDatabase);
            this.grpBoxAdmin.Controls.Add(this.btnCustomer);
            this.grpBoxAdmin.Controls.Add(this.btnInvoiceType);
            this.grpBoxAdmin.Controls.Add(this.btnProduct);
            this.grpBoxAdmin.Controls.Add(this.btnUsers);
            this.grpBoxAdmin.Location = new System.Drawing.Point(3, 1);
            this.grpBoxAdmin.Name = "grpBoxAdmin";
            this.grpBoxAdmin.Size = new System.Drawing.Size(558, 71);
            this.grpBoxAdmin.TabIndex = 17;
            this.grpBoxAdmin.TabStop = false;
            // 
            // btnManageDatabase
            // 
            this.btnManageDatabase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageDatabase.FlatAppearance.BorderSize = 0;
            this.btnManageDatabase.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnManageDatabase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageDatabase.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageDatabase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnManageDatabase.Image = global::Bill.Properties.Resources.Update_database;
            this.btnManageDatabase.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnManageDatabase.Location = new System.Drawing.Point(387, 11);
            this.btnManageDatabase.Name = "btnManageDatabase";
            this.btnManageDatabase.Size = new System.Drawing.Size(149, 56);
            this.btnManageDatabase.TabIndex = 33;
            this.btnManageDatabase.Text = "Manage Database";
            this.btnManageDatabase.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnManageDatabase.UseVisualStyleBackColor = true;
            this.btnManageDatabase.Click += new System.EventHandler(this.btnManageDatabase_Click);
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCustomer.FlatAppearance.BorderSize = 0;
            this.btnCustomer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomer.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnCustomer.Image = global::Bill.Properties.Resources.customer;
            this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCustomer.Location = new System.Drawing.Point(290, 11);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(91, 56);
            this.btnCustomer.TabIndex = 32;
            this.btnCustomer.Text = "Customers";
            this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // btnInvoiceType
            // 
            this.btnInvoiceType.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnInvoiceType.FlatAppearance.BorderSize = 0;
            this.btnInvoiceType.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnInvoiceType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInvoiceType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoiceType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnInvoiceType.Image = global::Bill.Properties.Resources.invoice;
            this.btnInvoiceType.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnInvoiceType.Location = new System.Drawing.Point(6, 11);
            this.btnInvoiceType.Name = "btnInvoiceType";
            this.btnInvoiceType.Size = new System.Drawing.Size(110, 56);
            this.btnInvoiceType.TabIndex = 31;
            this.btnInvoiceType.Text = "Invoice Types";
            this.btnInvoiceType.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInvoiceType.UseVisualStyleBackColor = true;
            this.btnInvoiceType.Click += new System.EventHandler(this.btnInvoiceType_Click);
            // 
            // btnProduct
            // 
            this.btnProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnProduct.FlatAppearance.BorderSize = 0;
            this.btnProduct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProduct.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnProduct.Image = global::Bill.Properties.Resources.product;
            this.btnProduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnProduct.Location = new System.Drawing.Point(119, 11);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Size = new System.Drawing.Size(81, 56);
            this.btnProduct.TabIndex = 29;
            this.btnProduct.Text = "Products";
            this.btnProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProduct.UseVisualStyleBackColor = true;
            this.btnProduct.Click += new System.EventHandler(this.btnProduct_Click);
            // 
            // btnUsers
            // 
            this.btnUsers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnUsers.FlatAppearance.BorderSize = 0;
            this.btnUsers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsers.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnUsers.Image = global::Bill.Properties.Resources.Users;
            this.btnUsers.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUsers.Location = new System.Drawing.Point(203, 11);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(81, 56);
            this.btnUsers.TabIndex = 27;
            this.btnUsers.Text = "Users";
            this.btnUsers.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.label11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(0, 622);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(984, 39);
            this.label11.TabIndex = 18;
            this.label11.Text = "Powered By   ASK Tech Developers  V1.1       |      Pune      |      +91 89289832" +
    "68";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpBoxBill
            // 
            this.grpBoxBill.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpBoxBill.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxBill.Controls.Add(this.btnCustomerSales);
            this.grpBoxBill.Controls.Add(this.btnNewBill);
            this.grpBoxBill.Controls.Add(this.btnViewInvoices);
            this.grpBoxBill.Location = new System.Drawing.Point(3, 113);
            this.grpBoxBill.Name = "grpBoxBill";
            this.grpBoxBill.Size = new System.Drawing.Size(314, 71);
            this.grpBoxBill.TabIndex = 31;
            this.grpBoxBill.TabStop = false;
            // 
            // btnCustomerSales
            // 
            this.btnCustomerSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCustomerSales.FlatAppearance.BorderSize = 0;
            this.btnCustomerSales.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnCustomerSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomerSales.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerSales.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnCustomerSales.Image = global::Bill.Properties.Resources.monthly_payment;
            this.btnCustomerSales.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCustomerSales.Location = new System.Drawing.Point(176, 11);
            this.btnCustomerSales.Name = "btnCustomerSales";
            this.btnCustomerSales.Size = new System.Drawing.Size(133, 56);
            this.btnCustomerSales.TabIndex = 30;
            this.btnCustomerSales.Text = "CustomerSales";
            this.btnCustomerSales.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCustomerSales.UseVisualStyleBackColor = true;
            this.btnCustomerSales.Click += new System.EventHandler(this.btnCustomerSales_Click);
            // 
            // btnNewBill
            // 
            this.btnNewBill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNewBill.FlatAppearance.BorderSize = 0;
            this.btnNewBill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnNewBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewBill.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewBill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnNewBill.Image = global::Bill.Properties.Resources.New_bill;
            this.btnNewBill.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNewBill.Location = new System.Drawing.Point(6, 11);
            this.btnNewBill.Name = "btnNewBill";
            this.btnNewBill.Size = new System.Drawing.Size(81, 56);
            this.btnNewBill.TabIndex = 28;
            this.btnNewBill.Text = "New Bill";
            this.btnNewBill.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNewBill.UseVisualStyleBackColor = true;
            this.btnNewBill.Click += new System.EventHandler(this.btnNewBill_Click);
            // 
            // btnViewInvoices
            // 
            this.btnViewInvoices.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnViewInvoices.FlatAppearance.BorderSize = 0;
            this.btnViewInvoices.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.btnViewInvoices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewInvoices.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewInvoices.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnViewInvoices.Image = global::Bill.Properties.Resources.Bill_list;
            this.btnViewInvoices.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnViewInvoices.Location = new System.Drawing.Point(91, 11);
            this.btnViewInvoices.Name = "btnViewInvoices";
            this.btnViewInvoices.Size = new System.Drawing.Size(81, 56);
            this.btnViewInvoices.TabIndex = 27;
            this.btnViewInvoices.Text = "Bills";
            this.btnViewInvoices.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnViewInvoices.UseVisualStyleBackColor = true;
            this.btnViewInvoices.Click += new System.EventHandler(this.btnViewInvoices_Click);
            // 
            // BillMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.ControlBox = false;
            this.Controls.Add(this.grpBoxBill);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pnlMenuIcons);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "BillMDI";
            this.Text = "BillMDI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.BillMDI_Load);
            this.Shown += new System.EventHandler(this.BillMDI_Shown);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.pnlMenuIcons.ResumeLayout(false);
            this.grpBoxAdmin.ResumeLayout(false);
            this.grpBoxBill.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitMainToolStripMenuItem;
        private System.Windows.Forms.Panel pnlMenuIcons;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.GroupBox grpBoxAdmin;
        private System.Windows.Forms.Button btnProduct;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Button btnInvoiceType;
        public System.Windows.Forms.GroupBox grpBoxBill;
        private System.Windows.Forms.Button btnCustomerSales;
        private System.Windows.Forms.Button btnNewBill;
        private System.Windows.Forms.Button btnViewInvoices;
        private System.Windows.Forms.ToolStripMenuItem billToolStripMenuItem;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnManageDatabase;
    }
}



