﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Utilities;
using System.Collections;
using Bill.Model;
using Bill.Delegate;
using System.IO;

namespace Bill
{
    public partial class ManageDatabase : Form
    {
        public ManageDatabase()
        {
            InitializeComponent();
        }

        private void btnBackUp_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog SaveFD1 = new SaveFileDialog();
                string FileName = "";
                SaveFD1.InitialDirectory = "D:";
                SaveFD1.FileName = "";
                SaveFD1.Title = "Backup ";
                SaveFD1.DefaultExt = "mdb";
                SaveFD1.Filter = "Ms-Access Files (*.mdb)|*.mdb|All Files|*.*";
                SaveFD1.FilterIndex = 1;
                SaveFD1.RestoreDirectory = true;

                if (SaveFD1.ShowDialog() == DialogResult.OK)
                {
                   
                    
                    FileName = SaveFD1.FileName;
                   
                    Backup(FileName);
                   
                   
                }
            }
            catch (Exception ex)
            {
                Utility oblUtility = new Utility();
                oblUtility.WriteLog("Form Manage Database Method btnBackUp" +ex.Message+ DateTime.Now);
            }

        }
        public void Backup(string path)
        {
            try
            {
                string src = Application.StartupPath + @"\App_Data\DB\RajElectricalBill.mdb";
                string dst = path;
                System.IO.File.Copy(src, dst, true);
                string fileName = Path.GetFileName(path);
                string location = Path.GetDirectoryName(path);
                ManageDatabaseModel objManageDatabaseModel = new ManageDatabaseModel();
                ManageDatabaseDelegate objManageDatabaseDelegate = new ManageDatabaseDelegate();
                bool flag = false;

                objManageDatabaseModel.FileName = fileName;
                objManageDatabaseModel.Location = location;
                objManageDatabaseModel.CreatedDate = DateTime.Now;
                flag = objManageDatabaseDelegate.SaveBackupDetails(objManageDatabaseModel);
                if (flag)
                {
                    MessageBox.Show("Backup Process is Completed Successfully !", "Backup Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception exception)
            {

                Utility objUtility = new Utility();
                objUtility.WriteLog("form manage database method Backup"+exception.Message+DateTime.Now);
            }
           
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog SaveFD12 = new OpenFileDialog();
                
                string FileName = "";
                SaveFD12.InitialDirectory = "C:";
                SaveFD12.FileName = "";
                SaveFD12.Title = "Choose Backup file to Restore ";
                SaveFD12.DefaultExt = "mdb";
                SaveFD12.Filter = "Ms-Access Files (*.mdb)|*.mdb|All Files|*.*";
                SaveFD12.FilterIndex = 1;
                SaveFD12.RestoreDirectory = true;
                if (SaveFD12.ShowDialog() == DialogResult.OK)
                {
                    FileName = SaveFD12.FileName;
                    string location = Path.GetDirectoryName(FileName);
                    string src = FileName;
                    string fileName = Path.GetFileName(FileName);
                    string dst = Application.StartupPath + @"\App_Data\DB\RajElectricalBill.mdb";
                   
                    System.IO.File.Copy(src, dst, true);
                    ManageDatabaseModel objManageDatabaseModel = new ManageDatabaseModel();
                    ManageDatabaseDelegate objManageDatabaseDelegate = new ManageDatabaseDelegate();
                    bool flag = false;
                   // objManageDatabaseModel.ManageType = "Restore";
                    objManageDatabaseModel.FileName = fileName;
                    objManageDatabaseModel.Location = location;
                    objManageDatabaseModel.CreatedDate = DateTime.Now;
                    flag = objManageDatabaseDelegate.SaveRestoreDetails(objManageDatabaseModel);
                    
                    if (flag)
                    {
                        MessageBox.Show("Restored Successfully !", "Restore Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                    }
                   
                   
                }
            }
            catch (Exception ex)
            {
                Utility oblUtility = new Utility();
                oblUtility.WriteLog("Form Manage Database Method btnRestore" + ex.Message + DateTime.Now);

            }
        }

        private void ManageDatabase_Load(object sender, EventArgs e)
        {
            try
            {

                String[] list = { "--Select--", "Back Up", "Restore" };
                cmbDetails.DataSource = list;

            }
            catch (Exception ex)
            {
                
              Utility oblUtility = new Utility();
                oblUtility.WriteLog("Form Manage Database Method manage database load" + ex.Message + DateTime.Now);
            }
         
        }

        private void btnGetDetails_Click(object sender, EventArgs e)
        {
            try
            {
                ManageDatabaseDelegate objManageDatabaseDelegate = new ManageDatabaseDelegate();
                DataTable objDataTable = new DataTable();

                if (cmbDetails.SelectedValue.ToString() == "Back Up")
                {
                    objDataTable = objManageDatabaseDelegate.GetBackUpDetails();

                    int couunt = objDataTable.Rows.Count;
                    int count = couunt - 1;
                    for (int row = 0; row < couunt - 1; row++)
                    {
                        objDataTable.Rows.RemoveAt(0);
                    }
                    dgvDetails.DataSource = objDataTable;

                }
                else if (cmbDetails.SelectedValue.ToString() == "Restore")
                {
                    objDataTable = objManageDatabaseDelegate.GetRestoreDetails();

                    int couunt = objDataTable.Rows.Count;
                    int count = couunt - 1;
                    for (int row = 0; row < couunt - 1; row++)
                    {
                        objDataTable.Rows.RemoveAt(0);
                    }
                    dgvDetails.DataSource = objDataTable;


                }

            }
            catch (Exception ex)
            {
                Utility oblUtility = new Utility();
                oblUtility.WriteLog("Form Manage Database Method btnGetDetails_click" + ex.Message + DateTime.Now);
              
            }
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {

                Utility oblUtility = new Utility();
                oblUtility.WriteLog("Form Manage Database Method btnExit_Click" + ex.Message + DateTime.Now);
            }
          
        }



    }
}
