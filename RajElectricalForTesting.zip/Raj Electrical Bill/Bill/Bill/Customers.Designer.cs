﻿namespace Bill
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpAddEditCustomer = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdbtnInActive = new System.Windows.Forms.RadioButton();
            this.rdbtnActive = new System.Windows.Forms.RadioButton();
            this.lblActive = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtTinNo = new System.Windows.Forms.TextBox();
            this.lblTinNo = new System.Windows.Forms.Label();
            this.txtMobileNumber = new System.Windows.Forms.TextBox();
            this.lblMobileNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.grpSaveCancel = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grpAddEdit = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvCustomers = new System.Windows.Forms.DataGridView();
            this.dtcolId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolPhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolMobileNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolTinNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolIsActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtcolCreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.grpAddEditCustomer.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grpSaveCancel.SuspendLayout();
            this.grpAddEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpAddEditCustomer
            // 
            this.grpAddEditCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpAddEditCustomer.Controls.Add(this.panel2);
            this.grpAddEditCustomer.Controls.Add(this.lblActive);
            this.grpAddEditCustomer.Controls.Add(this.txtAddress);
            this.grpAddEditCustomer.Controls.Add(this.lblAddress);
            this.grpAddEditCustomer.Controls.Add(this.txtTinNo);
            this.grpAddEditCustomer.Controls.Add(this.lblTinNo);
            this.grpAddEditCustomer.Controls.Add(this.txtMobileNumber);
            this.grpAddEditCustomer.Controls.Add(this.lblMobileNumber);
            this.grpAddEditCustomer.Controls.Add(this.txtPhoneNumber);
            this.grpAddEditCustomer.Controls.Add(this.lblPhoneNumber);
            this.grpAddEditCustomer.Controls.Add(this.txtEmail);
            this.grpAddEditCustomer.Controls.Add(this.lblEmail);
            this.grpAddEditCustomer.Controls.Add(this.txtName);
            this.grpAddEditCustomer.Controls.Add(this.lblName);
            this.grpAddEditCustomer.Enabled = false;
            this.grpAddEditCustomer.Location = new System.Drawing.Point(7, 3);
            this.grpAddEditCustomer.Name = "grpAddEditCustomer";
            this.grpAddEditCustomer.Size = new System.Drawing.Size(394, 314);
            this.grpAddEditCustomer.TabIndex = 0;
            this.grpAddEditCustomer.TabStop = false;
            this.grpAddEditCustomer.Text = "Add/Edit Customer";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdbtnInActive);
            this.panel2.Controls.Add(this.rdbtnActive);
            this.panel2.Location = new System.Drawing.Point(111, 274);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 32);
            this.panel2.TabIndex = 111;
            // 
            // rdbtnInActive
            // 
            this.rdbtnInActive.AutoSize = true;
            this.rdbtnInActive.Location = new System.Drawing.Point(135, 8);
            this.rdbtnInActive.Name = "rdbtnInActive";
            this.rdbtnInActive.Size = new System.Drawing.Size(64, 17);
            this.rdbtnInActive.TabIndex = 8;
            this.rdbtnInActive.TabStop = true;
            this.rdbtnInActive.Text = "InActive";
            this.rdbtnInActive.UseVisualStyleBackColor = true;
            // 
            // rdbtnActive
            // 
            this.rdbtnActive.AutoSize = true;
            this.rdbtnActive.Checked = true;
            this.rdbtnActive.Location = new System.Drawing.Point(52, 8);
            this.rdbtnActive.Name = "rdbtnActive";
            this.rdbtnActive.Size = new System.Drawing.Size(55, 17);
            this.rdbtnActive.TabIndex = 7;
            this.rdbtnActive.TabStop = true;
            this.rdbtnActive.Text = "Active";
            this.rdbtnActive.UseVisualStyleBackColor = true;
            // 
            // lblActive
            // 
            this.lblActive.AutoSize = true;
            this.lblActive.Location = new System.Drawing.Point(53, 284);
            this.lblActive.Name = "lblActive";
            this.lblActive.Size = new System.Drawing.Size(37, 13);
            this.lblActive.TabIndex = 2;
            this.lblActive.Text = "Active";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(111, 185);
            this.txtAddress.MaxLength = 100;
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(250, 82);
            this.txtAddress.TabIndex = 6;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(52, 188);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(45, 13);
            this.lblAddress.TabIndex = 0;
            this.lblAddress.Text = "Address";
            // 
            // txtTinNo
            // 
            this.txtTinNo.Location = new System.Drawing.Point(111, 152);
            this.txtTinNo.MaxLength = 20;
            this.txtTinNo.Name = "txtTinNo";
            this.txtTinNo.Size = new System.Drawing.Size(250, 20);
            this.txtTinNo.TabIndex = 5;
            // 
            // lblTinNo
            // 
            this.lblTinNo.AutoSize = true;
            this.lblTinNo.Location = new System.Drawing.Point(52, 155);
            this.lblTinNo.Name = "lblTinNo";
            this.lblTinNo.Size = new System.Drawing.Size(42, 13);
            this.lblTinNo.TabIndex = 0;
            this.lblTinNo.Text = "Tin No.";
            // 
            // txtMobileNumber
            // 
            this.txtMobileNumber.Location = new System.Drawing.Point(111, 118);
            this.txtMobileNumber.MaxLength = 10;
            this.txtMobileNumber.Name = "txtMobileNumber";
            this.txtMobileNumber.Size = new System.Drawing.Size(250, 20);
            this.txtMobileNumber.TabIndex = 4;
            this.txtMobileNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMobileNumber_KeyPress);
            // 
            // lblMobileNumber
            // 
            this.lblMobileNumber.AutoSize = true;
            this.lblMobileNumber.Location = new System.Drawing.Point(52, 121);
            this.lblMobileNumber.Name = "lblMobileNumber";
            this.lblMobileNumber.Size = new System.Drawing.Size(38, 13);
            this.lblMobileNumber.TabIndex = 0;
            this.lblMobileNumber.Text = "Mobile";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(111, 82);
            this.txtPhoneNumber.MaxLength = 11;
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(250, 20);
            this.txtPhoneNumber.TabIndex = 3;
            this.txtPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNumber_KeyPress);
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(52, 85);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(38, 13);
            this.lblPhoneNumber.TabIndex = 0;
            this.lblPhoneNumber.Text = "Phone";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(111, 49);
            this.txtEmail.MaxLength = 40;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(250, 20);
            this.txtEmail.TabIndex = 2;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(52, 52);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 0;
            this.lblEmail.Text = "Email";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(111, 19);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(250, 20);
            this.txtName.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(52, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // grpSaveCancel
            // 
            this.grpSaveCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpSaveCancel.Controls.Add(this.btnCancel);
            this.grpSaveCancel.Controls.Add(this.btnSave);
            this.grpSaveCancel.Location = new System.Drawing.Point(3, 323);
            this.grpSaveCancel.Name = "grpSaveCancel";
            this.grpSaveCancel.Size = new System.Drawing.Size(394, 66);
            this.grpSaveCancel.TabIndex = 1;
            this.grpSaveCancel.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(200, 20);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(114, 20);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // grpAddEdit
            // 
            this.grpAddEdit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpAddEdit.Controls.Add(this.btnExit);
            this.grpAddEdit.Controls.Add(this.btnEdit);
            this.grpAddEdit.Controls.Add(this.btnAdd);
            this.grpAddEdit.Location = new System.Drawing.Point(7, 397);
            this.grpAddEdit.Name = "grpAddEdit";
            this.grpAddEdit.Size = new System.Drawing.Size(394, 66);
            this.grpAddEdit.TabIndex = 1;
            this.grpAddEdit.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(243, 22);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Location = new System.Drawing.Point(157, 22);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(80, 30);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(90)))));
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(71, 22);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(80, 30);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvCustomers
            // 
            this.dgvCustomers.AllowUserToAddRows = false;
            this.dgvCustomers.AllowUserToDeleteRows = false;
            this.dgvCustomers.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvCustomers.BackgroundColor = System.Drawing.Color.White;
            this.dgvCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dtcolId,
            this.dtcolCustomerName,
            this.dtcolAddress,
            this.dtcolPhoneNumber,
            this.dtcolMobileNumber,
            this.dtcolEmail,
            this.dtcolTinNo,
            this.dtcolIsActive,
            this.dtcolCreatedDate});
            this.dgvCustomers.Location = new System.Drawing.Point(434, 50);
            this.dgvCustomers.Name = "dgvCustomers";
            this.dgvCustomers.ReadOnly = true;
            this.dgvCustomers.RowHeadersVisible = false;
            this.dgvCustomers.Size = new System.Drawing.Size(308, 386);
            this.dgvCustomers.TabIndex = 2;
            this.dgvCustomers.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustomers_RowEnter);
            // 
            // dtcolId
            // 
            this.dtcolId.DataPropertyName = "Id";
            this.dtcolId.HeaderText = "Id";
            this.dtcolId.Name = "dtcolId";
            this.dtcolId.ReadOnly = true;
            this.dtcolId.Visible = false;
            // 
            // dtcolCustomerName
            // 
            this.dtcolCustomerName.DataPropertyName = "Name";
            this.dtcolCustomerName.HeaderText = "Name";
            this.dtcolCustomerName.Name = "dtcolCustomerName";
            this.dtcolCustomerName.ReadOnly = true;
            this.dtcolCustomerName.Width = 250;
            // 
            // dtcolAddress
            // 
            this.dtcolAddress.DataPropertyName = "Address";
            this.dtcolAddress.HeaderText = "Address";
            this.dtcolAddress.Name = "dtcolAddress";
            this.dtcolAddress.ReadOnly = true;
            this.dtcolAddress.Visible = false;
            // 
            // dtcolPhoneNumber
            // 
            this.dtcolPhoneNumber.DataPropertyName = "PhoneNumber";
            this.dtcolPhoneNumber.HeaderText = "PhoneNumber";
            this.dtcolPhoneNumber.Name = "dtcolPhoneNumber";
            this.dtcolPhoneNumber.ReadOnly = true;
            this.dtcolPhoneNumber.Visible = false;
            // 
            // dtcolMobileNumber
            // 
            this.dtcolMobileNumber.DataPropertyName = "MobileNumber";
            this.dtcolMobileNumber.HeaderText = "MobileNumber";
            this.dtcolMobileNumber.Name = "dtcolMobileNumber";
            this.dtcolMobileNumber.ReadOnly = true;
            this.dtcolMobileNumber.Visible = false;
            // 
            // dtcolEmail
            // 
            this.dtcolEmail.DataPropertyName = "Email";
            this.dtcolEmail.HeaderText = "Email";
            this.dtcolEmail.Name = "dtcolEmail";
            this.dtcolEmail.ReadOnly = true;
            this.dtcolEmail.Visible = false;
            // 
            // dtcolTinNo
            // 
            this.dtcolTinNo.DataPropertyName = "PartyTinNo";
            this.dtcolTinNo.HeaderText = "TinNo";
            this.dtcolTinNo.Name = "dtcolTinNo";
            this.dtcolTinNo.ReadOnly = true;
            this.dtcolTinNo.Visible = false;
            // 
            // dtcolIsActive
            // 
            this.dtcolIsActive.DataPropertyName = "IsActive";
            this.dtcolIsActive.HeaderText = "IsActive";
            this.dtcolIsActive.Name = "dtcolIsActive";
            this.dtcolIsActive.ReadOnly = true;
            this.dtcolIsActive.Visible = false;
            // 
            // dtcolCreatedDate
            // 
            this.dtcolCreatedDate.DataPropertyName = "CreatedDate";
            this.dtcolCreatedDate.HeaderText = "CreatedDate";
            this.dtcolCreatedDate.Name = "dtcolCreatedDate";
            this.dtcolCreatedDate.ReadOnly = true;
            this.dtcolCreatedDate.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.Controls.Add(this.grpAddEdit);
            this.panel1.Controls.Add(this.grpSaveCancel);
            this.panel1.Controls.Add(this.grpAddEditCustomer);
            this.panel1.Location = new System.Drawing.Point(19, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(409, 473);
            this.panel1.TabIndex = 3;
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoSize = true;
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(754, 24);
            this.pnlHeader.TabIndex = 11;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(299, 3);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(156, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Manage Customers";
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 556);
            this.ControlBox = false;
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvCustomers);
            this.Name = "Customers";
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.Customers_Load);
            this.Shown += new System.EventHandler(this.Customers_Shown);
            this.grpAddEditCustomer.ResumeLayout(false);
            this.grpAddEditCustomer.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.grpSaveCancel.ResumeLayout(false);
            this.grpAddEdit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpAddEditCustomer;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtMobileNumber;
        private System.Windows.Forms.Label lblMobileNumber;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.GroupBox grpSaveCancel;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox grpAddEdit;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvCustomers;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdbtnInActive;
        private System.Windows.Forms.RadioButton rdbtnActive;
        private System.Windows.Forms.Label lblActive;
        private System.Windows.Forms.TextBox txtTinNo;
        private System.Windows.Forms.Label lblTinNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolPhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolMobileNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolTinNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolIsActive;
        private System.Windows.Forms.DataGridViewTextBoxColumn dtcolCreatedDate;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
    }
}