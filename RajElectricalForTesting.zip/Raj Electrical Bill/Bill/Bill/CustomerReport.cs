﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Utilities;
using Bill.Delegate;
using Bill.Constants;
using System.Globalization;
namespace Bill
{
    public partial class CustomerReport : Form
    {
        public CustomerReport()
        {
            InitializeComponent();
        }

        private void CustomerReport_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateCustomers();
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("CustomerReport_Load : " + ex + " " + DateTime.Now);
            }
        }

        private void PopulateCustomers()
        {
            CustomerDelegate customerDelegate = new CustomerDelegate();
            DataTable dataTable = customerDelegate.GetAllCustomers(ApplicationConstants.ActiveIndicator);
            cmbCustomerName.ValueMember = "ID";
            cmbCustomerName.DisplayMember = "Name";
            cmbCustomerName.DataSource = dataTable;
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {
               
                CustomerDelegate customerDelegate = new CustomerDelegate();
                int customerId = Convert.ToInt32(cmbCustomerName.SelectedValue);
                DateTime startDate = dtpStartDate.Value.Date;
                DateTime endDate = dtpEndDate.Value.Date.AddDays(1);
                DataTable dataTable = customerDelegate.GetCustomerReport(customerId, startDate, endDate);
                dgvCustomerReport.DataSource = dataTable;
                if (dgvCustomerReport.RowCount>0)
                {
                    int totalRs = 0;
                    int totalPs = 0;
                    for (int counter = 0; counter < dataTable.Rows.Count; counter++)
                    {
                        totalRs += Convert.ToInt32(dataTable.Rows[counter]["TotalRs"]);
                        totalPs += Convert.ToInt32(dataTable.Rows[counter]["TotalPs"]);
                        if (totalPs >= 100)
                        {
                            totalRs++;
                            totalPs -= 100;
                        }
                    }
                    lblTotalSaleValue.Text = String.Format("{0}.{1}", totalRs, totalPs);
                    lblTotalSaleValue.Left = lblTotalText.Left + lblTotalText.Width + 20;  
                }
                else
                {
                    MessageBox.Show("No Record Exits of Selected Customer");
                }
               
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("btnGenerateReport_Click : " + ex + " " + DateTime.Now);
               
            }
        }

        private void CustomerReport_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            lblTotalSaleValue.Left = lblTotalText.Left + lblTotalText.Width + 20;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCustomerReport_DataSourceChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvCustomerReport.DataSource != null)
                {
                    DataTable dtSales = dgvCustomerReport.DataSource as DataTable;

                    if (dtSales != null)
                    {
                        if (dtSales.Rows.Count > 0)
                        {
                            double total = 0;
                            for (int counter = 0; counter < dtSales.Rows.Count; counter++)
                            {
                                total += Convert.ToDouble(dtSales.Rows[counter]["TotalRs"]);
                                total += (Convert.ToDouble(dtSales.Rows[counter]["TotalPs"]) / 100);
                            }
                            lblTotalSaleValue.Text = total.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("btnGenerateReport_Click : " + ex + " " + DateTime.Now);
            }
        }
    }
}
