﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Delegate;

namespace Bill
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPassword.Text.Length <= 0 || txtUserName.Text.Length <= 0)
                {
                    MessageBox.Show("Please provide all data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    string userName = txtUserName.Text.Trim();
                    string password = txtPassword.Text;
                    UsersDelegate usersDelegate = new UsersDelegate();
                    DataTable dtUsers = usersDelegate.GetUserByName(userName);
                    if (dtUsers.Rows.Count > 0)
                    {
                        string dbPassword = dtUsers.Rows[0]["Password"].ToString();
                  //  string dbPassword = "admin";
                        if (String.Compare(password, dbPassword) == 0)
                        {
                            this.Hide();
                            BillMDI billMDI = new BillMDI();
                            billMDI.WindowState = FormWindowState.Minimized;
                            billMDI.Show();
                        }
                        else
                        {
                            MessageBox.Show("Wrong password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Wrong username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Utilities.Utility objUtility = new Utilities.Utility();
                objUtility.WriteLog("Login Error: " + ex.ToString() + " " + DateTime.Now);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }

        private void Login_Shown(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }
    }
}
