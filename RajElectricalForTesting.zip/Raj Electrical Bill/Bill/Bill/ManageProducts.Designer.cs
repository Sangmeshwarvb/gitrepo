﻿namespace Bill
{
    partial class ManageProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxOperations = new System.Windows.Forms.GroupBox();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.grpBoxProductEdit = new System.Windows.Forms.GroupBox();
            this.ckbChangeName = new System.Windows.Forms.CheckBox();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.cmbInvoiceType = new System.Windows.Forms.ComboBox();
            this.lblInvoiceType = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.rdbtnInActive = new System.Windows.Forms.RadioButton();
            this.rdbtnActive = new System.Windows.Forms.RadioButton();
            this.lblActiveStatus = new System.Windows.Forms.Label();
            this.txtProductPrice = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.dgvColCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceTypeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.grpBoxSave = new System.Windows.Forms.GroupBox();
            this.dgvAddProduct = new System.Windows.Forms.DataGridView();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductInvoice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceTypeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSearchProduct = new System.Windows.Forms.Label();
            this.txtSearchProduct = new System.Windows.Forms.TextBox();
            this.btnSearchProduct = new System.Windows.Forms.Button();
            this.lblProductID = new System.Windows.Forms.Label();
            this.grpSaveInvoice = new System.Windows.Forms.GroupBox();
            this.btnSaveProduct = new System.Windows.Forms.Button();
            this.btnExitProduct = new System.Windows.Forms.Button();
            this.grpBoxOperations.SuspendLayout();
            this.grpBoxProductEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.pnlHeader.SuspendLayout();
            this.grpBoxSave.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddProduct)).BeginInit();
            this.grpSaveInvoice.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxOperations
            // 
            this.grpBoxOperations.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxOperations.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxOperations.Controls.Add(this.btnAddNew);
            this.grpBoxOperations.Controls.Add(this.btnExit);
            this.grpBoxOperations.Controls.Add(this.btnEdit);
            this.grpBoxOperations.Location = new System.Drawing.Point(106, 424);
            this.grpBoxOperations.Name = "grpBoxOperations";
            this.grpBoxOperations.Size = new System.Drawing.Size(355, 55);
            this.grpBoxOperations.TabIndex = 9;
            this.grpBoxOperations.TabStop = false;
            // 
            // btnAddNew
            // 
            this.btnAddNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(90)))));
            this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNew.ForeColor = System.Drawing.Color.White;
            this.btnAddNew.Location = new System.Drawing.Point(51, 16);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(80, 30);
            this.btnAddNew.TabIndex = 2;
            this.btnAddNew.Text = "&Add";
            this.btnAddNew.UseVisualStyleBackColor = false;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(223, 16);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Cancel";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Location = new System.Drawing.Point(137, 16);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(80, 30);
            this.btnEdit.TabIndex = 0;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // grpBoxProductEdit
            // 
            this.grpBoxProductEdit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxProductEdit.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxProductEdit.Controls.Add(this.ckbChangeName);
            this.grpBoxProductEdit.Controls.Add(this.btnAddProduct);
            this.grpBoxProductEdit.Controls.Add(this.cmbInvoiceType);
            this.grpBoxProductEdit.Controls.Add(this.lblInvoiceType);
            this.grpBoxProductEdit.Controls.Add(this.txtProductCode);
            this.grpBoxProductEdit.Controls.Add(this.lblProductCode);
            this.grpBoxProductEdit.Controls.Add(this.rdbtnInActive);
            this.grpBoxProductEdit.Controls.Add(this.rdbtnActive);
            this.grpBoxProductEdit.Controls.Add(this.lblActiveStatus);
            this.grpBoxProductEdit.Controls.Add(this.txtProductPrice);
            this.grpBoxProductEdit.Controls.Add(this.txtProductName);
            this.grpBoxProductEdit.Controls.Add(this.lblPrice);
            this.grpBoxProductEdit.Controls.Add(this.lblProductName);
            this.grpBoxProductEdit.Enabled = false;
            this.grpBoxProductEdit.ForeColor = System.Drawing.Color.Black;
            this.grpBoxProductEdit.Location = new System.Drawing.Point(100, 69);
            this.grpBoxProductEdit.Name = "grpBoxProductEdit";
            this.grpBoxProductEdit.Size = new System.Drawing.Size(355, 165);
            this.grpBoxProductEdit.TabIndex = 8;
            this.grpBoxProductEdit.TabStop = false;
            this.grpBoxProductEdit.Text = "Add/Edit Product";
            // 
            // ckbChangeName
            // 
            this.ckbChangeName.AutoSize = true;
            this.ckbChangeName.Location = new System.Drawing.Point(266, 28);
            this.ckbChangeName.Name = "ckbChangeName";
            this.ckbChangeName.Size = new System.Drawing.Size(15, 14);
            this.ckbChangeName.TabIndex = 11;
            this.ckbChangeName.UseVisualStyleBackColor = true;
            this.ckbChangeName.Visible = false;
            this.ckbChangeName.CheckedChanged += new System.EventHandler(this.ckbChangeName_CheckedChanged);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(90)))));
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddProduct.Location = new System.Drawing.Point(274, 136);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(75, 23);
            this.btnAddProduct.TabIndex = 7;
            this.btnAddProduct.Text = "Add";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // cmbInvoiceType
            // 
            this.cmbInvoiceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInvoiceType.FormattingEnabled = true;
            this.cmbInvoiceType.Location = new System.Drawing.Point(108, 86);
            this.cmbInvoiceType.Name = "cmbInvoiceType";
            this.cmbInvoiceType.Size = new System.Drawing.Size(151, 21);
            this.cmbInvoiceType.TabIndex = 2;
            // 
            // lblInvoiceType
            // 
            this.lblInvoiceType.AutoSize = true;
            this.lblInvoiceType.Location = new System.Drawing.Point(28, 86);
            this.lblInvoiceType.Name = "lblInvoiceType";
            this.lblInvoiceType.Size = new System.Drawing.Size(69, 13);
            this.lblInvoiceType.TabIndex = 10;
            this.lblInvoiceType.Text = "Invoice Type";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Location = new System.Drawing.Point(108, 55);
            this.txtProductCode.MaxLength = 15;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(151, 20);
            this.txtProductCode.TabIndex = 1;
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Location = new System.Drawing.Point(28, 58);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(72, 13);
            this.lblProductCode.TabIndex = 8;
            this.lblProductCode.Text = "Product Code";
            // 
            // rdbtnInActive
            // 
            this.rdbtnInActive.AutoSize = true;
            this.rdbtnInActive.Location = new System.Drawing.Point(178, 138);
            this.rdbtnInActive.Name = "rdbtnInActive";
            this.rdbtnInActive.Size = new System.Drawing.Size(64, 17);
            this.rdbtnInActive.TabIndex = 6;
            this.rdbtnInActive.Text = "InActive";
            this.rdbtnInActive.UseVisualStyleBackColor = true;
            // 
            // rdbtnActive
            // 
            this.rdbtnActive.AutoSize = true;
            this.rdbtnActive.Checked = true;
            this.rdbtnActive.Location = new System.Drawing.Point(108, 138);
            this.rdbtnActive.Name = "rdbtnActive";
            this.rdbtnActive.Size = new System.Drawing.Size(55, 17);
            this.rdbtnActive.TabIndex = 4;
            this.rdbtnActive.TabStop = true;
            this.rdbtnActive.Text = "Active";
            this.rdbtnActive.UseVisualStyleBackColor = true;
            // 
            // lblActiveStatus
            // 
            this.lblActiveStatus.AutoSize = true;
            this.lblActiveStatus.Location = new System.Drawing.Point(60, 140);
            this.lblActiveStatus.Name = "lblActiveStatus";
            this.lblActiveStatus.Size = new System.Drawing.Size(37, 13);
            this.lblActiveStatus.TabIndex = 5;
            this.lblActiveStatus.Text = "Status";
            // 
            // txtProductPrice
            // 
            this.txtProductPrice.Location = new System.Drawing.Point(108, 115);
            this.txtProductPrice.Name = "txtProductPrice";
            this.txtProductPrice.Size = new System.Drawing.Size(151, 20);
            this.txtProductPrice.TabIndex = 3;
            this.txtProductPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductPrice_KeyPress);
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(108, 26);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(151, 20);
            this.txtProductName.TabIndex = 0;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(66, 117);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(25, 28);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(75, 13);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.Text = "Product Name";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(186, 17);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(89, 17);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dgvProducts
            // 
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.AllowUserToResizeColumns = false;
            this.dgvProducts.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvProducts.BackgroundColor = System.Drawing.Color.White;
            this.dgvProducts.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvColCode,
            this.ID,
            this.Product,
            this.InvoiceTypeName,
            this.Price,
            this.IsActive});
            this.dgvProducts.Location = new System.Drawing.Point(504, 117);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.ReadOnly = true;
            this.dgvProducts.RowHeadersVisible = false;
            this.dgvProducts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvProducts.Size = new System.Drawing.Size(355, 352);
            this.dgvProducts.TabIndex = 7;
            this.dgvProducts.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellEnter);
            // 
            // dgvColCode
            // 
            this.dgvColCode.DataPropertyName = "Code";
            this.dgvColCode.Frozen = true;
            this.dgvColCode.HeaderText = "Code";
            this.dgvColCode.Name = "dgvColCode";
            this.dgvColCode.ReadOnly = true;
            this.dgvColCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColCode.Width = 50;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Product
            // 
            this.Product.DataPropertyName = "ProductName";
            this.Product.Frozen = true;
            this.Product.HeaderText = "Product";
            this.Product.Name = "Product";
            this.Product.ReadOnly = true;
            this.Product.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Product.Width = 130;
            // 
            // InvoiceTypeName
            // 
            this.InvoiceTypeName.DataPropertyName = "InvoiceType";
            this.InvoiceTypeName.HeaderText = "InvoiceType";
            this.InvoiceTypeName.Name = "InvoiceTypeName";
            this.InvoiceTypeName.ReadOnly = true;
            this.InvoiceTypeName.Visible = false;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Visible = false;
            // 
            // IsActive
            // 
            this.IsActive.DataPropertyName = "IsActive";
            this.IsActive.HeaderText = "Active";
            this.IsActive.Name = "IsActive";
            this.IsActive.ReadOnly = true;
            this.IsActive.Visible = false;
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(922, 25);
            this.pnlHeader.TabIndex = 10;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(390, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(143, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Manage Products";
            // 
            // grpBoxSave
            // 
            this.grpBoxSave.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxSave.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxSave.Controls.Add(this.btnSave);
            this.grpBoxSave.Controls.Add(this.btnCancel);
            this.grpBoxSave.Location = new System.Drawing.Point(102, 473);
            this.grpBoxSave.Name = "grpBoxSave";
            this.grpBoxSave.Size = new System.Drawing.Size(355, 55);
            this.grpBoxSave.TabIndex = 11;
            this.grpBoxSave.TabStop = false;
            this.grpBoxSave.Visible = false;
            // 
            // dgvAddProduct
            // 
            this.dgvAddProduct.AllowUserToAddRows = false;
            this.dgvAddProduct.AllowUserToDeleteRows = false;
            this.dgvAddProduct.AllowUserToOrderColumns = true;
            this.dgvAddProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvAddProduct.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvAddProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAddProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductName,
            this.ProductCode,
            this.ProductInvoice,
            this.InvoiceTypeID,
            this.ProductPrice,
            this.ProductStatus});
            this.dgvAddProduct.Location = new System.Drawing.Point(54, 245);
            this.dgvAddProduct.Name = "dgvAddProduct";
            this.dgvAddProduct.RowHeadersVisible = false;
            this.dgvAddProduct.Size = new System.Drawing.Size(442, 177);
            this.dgvAddProduct.TabIndex = 12;
            // 
            // ProductName
            // 
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            // 
            // ProductCode
            // 
            this.ProductCode.HeaderText = "Product Code";
            this.ProductCode.Name = "ProductCode";
            // 
            // ProductInvoice
            // 
            this.ProductInvoice.HeaderText = "Invoice Type";
            this.ProductInvoice.Name = "ProductInvoice";
            // 
            // InvoiceTypeID
            // 
            this.InvoiceTypeID.HeaderText = "InvoiceTypeID";
            this.InvoiceTypeID.Name = "InvoiceTypeID";
            this.InvoiceTypeID.Visible = false;
            // 
            // ProductPrice
            // 
            this.ProductPrice.HeaderText = "Price";
            this.ProductPrice.Name = "ProductPrice";
            // 
            // ProductStatus
            // 
            this.ProductStatus.HeaderText = " Status";
            this.ProductStatus.Name = "ProductStatus";
            // 
            // lblSearchProduct
            // 
            this.lblSearchProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblSearchProduct.AutoSize = true;
            this.lblSearchProduct.Location = new System.Drawing.Point(510, 81);
            this.lblSearchProduct.Name = "lblSearchProduct";
            this.lblSearchProduct.Size = new System.Drawing.Size(81, 13);
            this.lblSearchProduct.TabIndex = 13;
            this.lblSearchProduct.Text = "Search Product";
            // 
            // txtSearchProduct
            // 
            this.txtSearchProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSearchProduct.Location = new System.Drawing.Point(617, 78);
            this.txtSearchProduct.Name = "txtSearchProduct";
            this.txtSearchProduct.Size = new System.Drawing.Size(151, 20);
            this.txtSearchProduct.TabIndex = 14;
            // 
            // btnSearchProduct
            // 
            this.btnSearchProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSearchProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(90)))));
            this.btnSearchProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchProduct.ForeColor = System.Drawing.Color.White;
            this.btnSearchProduct.Location = new System.Drawing.Point(793, 76);
            this.btnSearchProduct.Name = "btnSearchProduct";
            this.btnSearchProduct.Size = new System.Drawing.Size(75, 23);
            this.btnSearchProduct.TabIndex = 15;
            this.btnSearchProduct.Text = "Search";
            this.btnSearchProduct.UseVisualStyleBackColor = false;
            this.btnSearchProduct.Click += new System.EventHandler(this.btnSearchProduct_Click);
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(208, 50);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(55, 13);
            this.lblProductID.TabIndex = 16;
            this.lblProductID.Text = "ProductID";
            this.lblProductID.Visible = false;
            // 
            // grpSaveInvoice
            // 
            this.grpSaveInvoice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpSaveInvoice.BackColor = System.Drawing.Color.Transparent;
            this.grpSaveInvoice.Controls.Add(this.btnSaveProduct);
            this.grpSaveInvoice.Controls.Add(this.btnExitProduct);
            this.grpSaveInvoice.Location = new System.Drawing.Point(504, 475);
            this.grpSaveInvoice.Name = "grpSaveInvoice";
            this.grpSaveInvoice.Size = new System.Drawing.Size(355, 47);
            this.grpSaveInvoice.TabIndex = 12;
            this.grpSaveInvoice.TabStop = false;
            this.grpSaveInvoice.Visible = false;
            // 
            // btnSaveProduct
            // 
            this.btnSaveProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnSaveProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveProduct.ForeColor = System.Drawing.Color.White;
            this.btnSaveProduct.Location = new System.Drawing.Point(89, 11);
            this.btnSaveProduct.Name = "btnSaveProduct";
            this.btnSaveProduct.Size = new System.Drawing.Size(80, 30);
            this.btnSaveProduct.TabIndex = 8;
            this.btnSaveProduct.Text = "Save";
            this.btnSaveProduct.UseVisualStyleBackColor = false;
            this.btnSaveProduct.Click += new System.EventHandler(this.btnSaveInvoice_Click);
            // 
            // btnExitProduct
            // 
            this.btnExitProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExitProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExitProduct.ForeColor = System.Drawing.Color.White;
            this.btnExitProduct.Location = new System.Drawing.Point(186, 11);
            this.btnExitProduct.Name = "btnExitProduct";
            this.btnExitProduct.Size = new System.Drawing.Size(80, 30);
            this.btnExitProduct.TabIndex = 9;
            this.btnExitProduct.Text = "Cancel";
            this.btnExitProduct.UseVisualStyleBackColor = false;
            this.btnExitProduct.Click += new System.EventHandler(this.btnExitProduct_Click);
            // 
            // ManageProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(922, 523);
            this.ControlBox = false;
            this.Controls.Add(this.grpSaveInvoice);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.btnSearchProduct);
            this.Controls.Add(this.txtSearchProduct);
            this.Controls.Add(this.lblSearchProduct);
            this.Controls.Add(this.dgvAddProduct);
            this.Controls.Add(this.grpBoxSave);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.grpBoxOperations);
            this.Controls.Add(this.grpBoxProductEdit);
            this.Controls.Add(this.dgvProducts);
            this.Name = "ManageProducts";
            this.Text = "ManageProducts";
            this.Load += new System.EventHandler(this.ManageProducts_Load);
            this.Shown += new System.EventHandler(this.ManageProducts_Shown);
            this.grpBoxOperations.ResumeLayout(false);
            this.grpBoxProductEdit.ResumeLayout(false);
            this.grpBoxProductEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.grpBoxSave.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddProduct)).EndInit();
            this.grpSaveInvoice.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxOperations;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.GroupBox grpBoxProductEdit;
        private System.Windows.Forms.RadioButton rdbtnInActive;
        private System.Windows.Forms.RadioButton rdbtnActive;
        private System.Windows.Forms.Label lblActiveStatus;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.TextBox txtProductPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox grpBoxSave;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.Label lblInvoiceType;
        private System.Windows.Forms.ComboBox cmbInvoiceType;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.DataGridView dgvAddProduct;
        private System.Windows.Forms.Label lblSearchProduct;
        private System.Windows.Forms.TextBox txtSearchProduct;
        private System.Windows.Forms.Button btnSearchProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductInvoice;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceTypeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductStatus;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.GroupBox grpSaveInvoice;
        private System.Windows.Forms.Button btnSaveProduct;
        private System.Windows.Forms.Button btnExitProduct;
        private System.Windows.Forms.CheckBox ckbChangeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceTypeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsActive;
    }
}