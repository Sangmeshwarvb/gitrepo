﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Delegate;
using Bill.Utilities;

namespace Bill
{
    public partial class ViewInvoice : Form
    {
        public ViewInvoice()
        {
            InitializeComponent();
        }

        private void btnFilterDate_Click(object sender, EventArgs e)
        {
            try
            {
                decimal totalamt = 0;
                string startDate = dtPickerInvoiceStartDate.Value.ToString("dd-MMM-yy");
                string endDate = dtPickerInvoiceEndDate.Value.AddDays(1).ToString("dd-MMM-yy");
                InvoicesDelegate invoicesDelegate = new InvoicesDelegate();
                DataTable dtInvoices = invoicesDelegate.GetInvoiceByDate(startDate, endDate);
                Utility objUtility = new Utility();
                objUtility.WriteLog("Total Record : " + dtInvoices.Rows.Count + " " + DateTime.Now);
                for (int counter = 0; counter < dtInvoices.Rows.Count; counter++)
                {
                    objUtility.WriteLog("Record: " + (counter + 1) + dtInvoices.Rows[counter]["Id"].ToString() + " " + DateTime.Now);
                }
                dgvInvoices.DataSource = dtInvoices;
                for (int counter = 0; counter < dtInvoices.Rows.Count; counter++)
                {
                    decimal total = Convert.ToDecimal(dtInvoices.Rows[counter]["Total"]);
                    decimal add = totalamt + total;
                    totalamt = add;
                }
                lblTotalSalesValue.Text = totalamt.ToString();

            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ViewInvoice form btnFilterDate_Click : " + exception.Message + DateTime.Now);
            }
        }

        private void ViewInvoice_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Close();
        }

        private void dgvInvoices_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    InvoicesDelegate invoicesDelegate = new InvoicesDelegate();
                    int id = Convert.ToInt32(dgvInvoices.Rows[e.RowIndex].Cells["dgColInvoiceId"].Value);
                    DataTable dtInvoicesDetails = invoicesDelegate.GetInvoiceDetailsById(id);
                    dgvInvoicesDetails.DataSource = dtInvoicesDetails;
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ViewInvoice form dgvInvoices_CellEnter : " + exception.Message + DateTime.Now);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                int count = 0;
                foreach (DataGridViewRow row in dgvInvoices.Rows)
                {
                    
                    var selected = Convert.ToBoolean(row.Cells["dgvColSelInvoices"].Value);
                    if (selected)
                    {
                        count++;
                    }
                }
                    if(count>1 )
                    {
                        MessageBox.Show("You can select any one bill at a time to print");
                    }
                    else
                    {
                        if (MessageBox.Show("Do you want to print the invoice?", "System Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            InvoicesDelegate invoicesDelegate = new InvoicesDelegate();
                            int id = Convert.ToInt32(dgvInvoices.CurrentRow.Cells["dgColInvoiceId"].Value);
                            DataTable dtInvoicesData = invoicesDelegate.GetReportInvoiceData(id);
                            dtInvoicesData.TableName = "InvoiceData";
                            InvoiceDetailDelegate invoiceDetailDelegate = new InvoiceDetailDelegate();
                            DataTable dtInvoicesDetailData = invoiceDetailDelegate.GetReportInvoiceDetailData(id);
                            dtInvoicesDetailData.TableName = "InvoiceDetail";
                            DataSet dataSet = new DataSet();
                            dataSet.Tables.Add(dtInvoicesData);
                            dataSet.Tables.Add(dtInvoicesDetailData);
                            BillPrint crBillReport = new BillPrint();
                            crBillReport.SetDataSource(dataSet);
                            BillViewer viewer = new BillViewer();
                            viewer.crBillPrint.ReportSource = crBillReport;
                            viewer.crBillPrint.Refresh();
                            viewer.crBillPrint.ShowLastPage();
                            int lastpgno = viewer.crBillPrint.GetCurrentPageNumber();
                            crBillReport.PrintToPrinter(1, false, 1, lastpgno);
                            MessageBox.Show("Invoice Printed", "System Confirmation", MessageBoxButtons.OK);
                        }

                    }
                

            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ViewInvoice form dgvInvoices_CellEnter : " + exception.Message + DateTime.Now);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string deleteIds = string.Empty;
                int count = 0;
                foreach (DataGridViewRow row in dgvInvoices.Rows)
                {
                    var selected = Convert.ToBoolean(row.Cells["dgvColSelInvoices"].Value);
                    if (selected)
                    {
                        count++;
                        deleteIds = String.Concat(deleteIds, row.Cells["dgColInvoiceId"].Value, ",");
                    }
                }
                if (count <= 0)
                {
                    MessageBox.Show("Please select atleast one bill to delete it.");
                }
                else
                {
                    if (MessageBox.Show("Are you sure you want to delete all the selected bills.", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        deleteIds = deleteIds.Substring(0, deleteIds.Length - 1);
                        Delegate.InvoicesDelegate invoicesDelegate = new InvoicesDelegate();
                        bool flag = invoicesDelegate.DeleteBills(deleteIds);
                        if (flag)
                        {
                            MessageBox.Show("Bill deletion successfull.", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dgvInvoicesDetails.DataSource = new DataTable();
                            btnFilterDate_Click(sender, e);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("ViewInvoice form DeleteBill : " + exception.Message + DateTime.Now);
            }
        }
    }
}
