﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Bill.Constants
{
    public class ApplicationConstants
    {
        public const bool ActiveIndicator = true;
        public const bool InActiveIndicator = false;
        public const string ActiveIndicatorText = "Active";
        public const string InActiveIndicatorText = "InActive";

        public const string OperationUpdate = "Update";
        public const string OperationInsert = "Insert";

        public static int CurrentInvoiceType { get; set; }
        public static string CurrentInvoiceTypeText { get; set; }
        public static string SysDateFormat = CultureInfo.CurrentUICulture.DateTimeFormat.ShortDatePattern;
    }
}
