﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Model
{
    class ManageDatabaseModel
    {
        public int ID { get; set; }
      //  public string  ManageType { get; set; }
        public string  FileName { get; set; }
        public string  Location { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
