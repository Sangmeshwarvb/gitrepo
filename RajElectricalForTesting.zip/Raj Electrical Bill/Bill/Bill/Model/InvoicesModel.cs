﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Model
{
    public class InvoicesModel
    {
        public int ID { get; set; }
        public int CustomerID { get; set; }
        public string ClientNameLine1 { get; set; }
        public string ClientNameLine2 { get; set; }
        public string PartyTinNo { get; set; }
        public int InvoiceType { get; set; }
        public int ComplaintNo { get; set; }
        public string InvoiceDate { get; set; }
        public string AmountWords { get; set; }
        public int SubTotalRs { get; set; }
        public int SubTotalPs { get; set; }
        public int VAT12Rs { get; set; }
        public int VAT12Ps { get; set; }
        public int VAT5Rs { get; set; }
        public int VAT5Ps { get; set; }
        public int TotalRs { get; set; }
        public int TotalPs { get; set; }
        public List<InvoiceDetailModel> InvoiceItems { get; set; }
    }
}
