﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Model
{
    public class InvoiceDetailModel
    {
        public int ID { get; set; }
        public int InvoiceId { get; set; }
        public int ItemNo { get; set; }
        public int ProductId { get; set; }
        public int Qty { get; set; }
        public decimal Rate { get; set; }
        public decimal VAT { get; set; }
        public int AmountRs { get; set; }
        public int AmountPs { get; set; }
    }
}
