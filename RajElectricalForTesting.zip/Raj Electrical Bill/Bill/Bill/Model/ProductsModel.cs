﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.Model
{
    public class ProductsModel
    {
        public int ID { get; set; }
        public int InvoicesType { get; set; }
        public string Name { get; set; }
       // public int TypeId { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Code { get; set; }
    }
}
