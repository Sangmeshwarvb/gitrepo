﻿namespace Bill
{
    partial class ViewInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewInvoice));
            this.grpBoxSelectDate = new System.Windows.Forms.GroupBox();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.dtPickerInvoiceEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.btnFilterDate = new System.Windows.Forms.Button();
            this.dtPickerInvoiceStartDate = new System.Windows.Forms.DateTimePicker();
            this.dgvInvoicesDetails = new System.Windows.Forms.DataGridView();
            this.dgvColInvoiceDetailId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColVAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExit = new System.Windows.Forms.Button();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.dgvInvoices = new System.Windows.Forms.DataGridView();
            this.dgColInvoiceId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColSelInvoices = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgColInvDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgColInvoicePartyTin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgColInvType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgColInvTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblInvoiceDetailText = new System.Windows.Forms.Label();
            this.lblInvoiceText = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblTotalSales = new System.Windows.Forms.Label();
            this.lblTotalSalesValue = new System.Windows.Forms.Label();
            this.grpBoxSelectDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoicesDetails)).BeginInit();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoices)).BeginInit();
            this.SuspendLayout();
            // 
            // grpBoxSelectDate
            // 
            this.grpBoxSelectDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxSelectDate.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxSelectDate.Controls.Add(this.lblEndDate);
            this.grpBoxSelectDate.Controls.Add(this.dtPickerInvoiceEndDate);
            this.grpBoxSelectDate.Controls.Add(this.lblStartDate);
            this.grpBoxSelectDate.Controls.Add(this.btnFilterDate);
            this.grpBoxSelectDate.Controls.Add(this.dtPickerInvoiceStartDate);
            this.grpBoxSelectDate.ForeColor = System.Drawing.Color.Black;
            this.grpBoxSelectDate.Location = new System.Drawing.Point(12, 47);
            this.grpBoxSelectDate.Name = "grpBoxSelectDate";
            this.grpBoxSelectDate.Size = new System.Drawing.Size(875, 82);
            this.grpBoxSelectDate.TabIndex = 0;
            this.grpBoxSelectDate.TabStop = false;
            this.grpBoxSelectDate.Text = "Select Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDate.Location = new System.Drawing.Point(396, 21);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(64, 16);
            this.lblEndDate.TabIndex = 4;
            this.lblEndDate.Text = "End Date";
            // 
            // dtPickerInvoiceEndDate
            // 
            this.dtPickerInvoiceEndDate.Location = new System.Drawing.Point(399, 40);
            this.dtPickerInvoiceEndDate.Name = "dtPickerInvoiceEndDate";
            this.dtPickerInvoiceEndDate.Size = new System.Drawing.Size(200, 20);
            this.dtPickerInvoiceEndDate.TabIndex = 1;
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(156, 21);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(67, 16);
            this.lblStartDate.TabIndex = 2;
            this.lblStartDate.Text = "Start Date";
            // 
            // btnFilterDate
            // 
            this.btnFilterDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnFilterDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilterDate.ForeColor = System.Drawing.Color.White;
            this.btnFilterDate.Location = new System.Drawing.Point(631, 30);
            this.btnFilterDate.Name = "btnFilterDate";
            this.btnFilterDate.Size = new System.Drawing.Size(88, 30);
            this.btnFilterDate.TabIndex = 2;
            this.btnFilterDate.Text = "Get Invoices";
            this.btnFilterDate.UseVisualStyleBackColor = false;
            this.btnFilterDate.Click += new System.EventHandler(this.btnFilterDate_Click);
            // 
            // dtPickerInvoiceStartDate
            // 
            this.dtPickerInvoiceStartDate.Location = new System.Drawing.Point(159, 40);
            this.dtPickerInvoiceStartDate.Name = "dtPickerInvoiceStartDate";
            this.dtPickerInvoiceStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtPickerInvoiceStartDate.TabIndex = 0;
            // 
            // dgvInvoicesDetails
            // 
            this.dgvInvoicesDetails.AllowUserToAddRows = false;
            this.dgvInvoicesDetails.AllowUserToDeleteRows = false;
            this.dgvInvoicesDetails.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvInvoicesDetails.BackgroundColor = System.Drawing.Color.White;
            this.dgvInvoicesDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoicesDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvColInvoiceDetailId,
            this.dgvColProductName,
            this.dgvColQty,
            this.dgvColRate,
            this.dgvColVAT,
            this.dgvColAmount});
            this.dgvInvoicesDetails.Location = new System.Drawing.Point(505, 168);
            this.dgvInvoicesDetails.Name = "dgvInvoicesDetails";
            this.dgvInvoicesDetails.ReadOnly = true;
            this.dgvInvoicesDetails.RowHeadersVisible = false;
            this.dgvInvoicesDetails.Size = new System.Drawing.Size(382, 339);
            this.dgvInvoicesDetails.TabIndex = 1;
            // 
            // dgvColInvoiceDetailId
            // 
            this.dgvColInvoiceDetailId.DataPropertyName = "Id";
            this.dgvColInvoiceDetailId.HeaderText = "Id";
            this.dgvColInvoiceDetailId.Name = "dgvColInvoiceDetailId";
            this.dgvColInvoiceDetailId.ReadOnly = true;
            this.dgvColInvoiceDetailId.Visible = false;
            // 
            // dgvColProductName
            // 
            this.dgvColProductName.DataPropertyName = "Name";
            this.dgvColProductName.HeaderText = "ProductName";
            this.dgvColProductName.Name = "dgvColProductName";
            this.dgvColProductName.ReadOnly = true;
            this.dgvColProductName.Width = 170;
            // 
            // dgvColQty
            // 
            this.dgvColQty.DataPropertyName = "Qty";
            this.dgvColQty.HeaderText = "Qty";
            this.dgvColQty.Name = "dgvColQty";
            this.dgvColQty.ReadOnly = true;
            this.dgvColQty.Width = 30;
            // 
            // dgvColRate
            // 
            this.dgvColRate.DataPropertyName = "Rate";
            this.dgvColRate.HeaderText = "Rate";
            this.dgvColRate.Name = "dgvColRate";
            this.dgvColRate.ReadOnly = true;
            this.dgvColRate.Width = 50;
            // 
            // dgvColVAT
            // 
            this.dgvColVAT.DataPropertyName = "VAT";
            this.dgvColVAT.HeaderText = "VAT";
            this.dgvColVAT.Name = "dgvColVAT";
            this.dgvColVAT.ReadOnly = true;
            this.dgvColVAT.Width = 50;
            // 
            // dgvColAmount
            // 
            this.dgvColAmount.DataPropertyName = "Amount";
            this.dgvColAmount.HeaderText = "Amount";
            this.dgvColAmount.Name = "dgvColAmount";
            this.dgvColAmount.ReadOnly = true;
            this.dgvColAmount.Width = 60;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(520, 529);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoSize = true;
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(899, 23);
            this.pnlHeader.TabIndex = 3;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(395, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(108, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "View Invoice";
            // 
            // dgvInvoices
            // 
            this.dgvInvoices.AllowUserToAddRows = false;
            this.dgvInvoices.AllowUserToDeleteRows = false;
            this.dgvInvoices.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvInvoices.BackgroundColor = System.Drawing.Color.White;
            this.dgvInvoices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgColInvoiceId,
            this.dgvColSelInvoices,
            this.dataGridViewTextBoxColumn2,
            this.dgColInvDate,
            this.dgColInvoicePartyTin,
            this.dgColInvType,
            this.dgColInvTotal});
            this.dgvInvoices.Location = new System.Drawing.Point(12, 168);
            this.dgvInvoices.Name = "dgvInvoices";
            this.dgvInvoices.RowHeadersVisible = false;
            this.dgvInvoices.Size = new System.Drawing.Size(423, 339);
            this.dgvInvoices.TabIndex = 4;
            this.dgvInvoices.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInvoices_CellEnter);
            // 
            // dgColInvoiceId
            // 
            this.dgColInvoiceId.DataPropertyName = "Id";
            this.dgColInvoiceId.HeaderText = "Id";
            this.dgColInvoiceId.Name = "dgColInvoiceId";
            this.dgColInvoiceId.ReadOnly = true;
            this.dgColInvoiceId.Visible = false;
            // 
            // dgvColSelInvoices
            // 
            this.dgvColSelInvoices.HeaderText = "Sel";
            this.dgvColSelInvoices.Name = "dgvColSelInvoices";
            this.dgvColSelInvoices.Width = 30;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ClientNameLine1";
            this.dataGridViewTextBoxColumn2.HeaderText = "ClientName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 170;
            // 
            // dgColInvDate
            // 
            this.dgColInvDate.DataPropertyName = "InvoiceDate";
            this.dgColInvDate.HeaderText = "Date";
            this.dgColInvDate.Name = "dgColInvDate";
            this.dgColInvDate.ReadOnly = true;
            this.dgColInvDate.Width = 75;
            // 
            // dgColInvoicePartyTin
            // 
            this.dgColInvoicePartyTin.DataPropertyName = "PartyTinNo";
            this.dgColInvoicePartyTin.HeaderText = "Party Tin No";
            this.dgColInvoicePartyTin.Name = "dgColInvoicePartyTin";
            this.dgColInvoicePartyTin.ReadOnly = true;
            this.dgColInvoicePartyTin.Visible = false;
            // 
            // dgColInvType
            // 
            this.dgColInvType.DataPropertyName = "InvoiceType";
            this.dgColInvType.HeaderText = "Type";
            this.dgColInvType.Name = "dgColInvType";
            this.dgColInvType.ReadOnly = true;
            this.dgColInvType.Width = 80;
            // 
            // dgColInvTotal
            // 
            this.dgColInvTotal.DataPropertyName = "Total";
            this.dgColInvTotal.HeaderText = "Total";
            this.dgColInvTotal.Name = "dgColInvTotal";
            this.dgColInvTotal.ReadOnly = true;
            this.dgColInvTotal.Width = 60;
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Location = new System.Drawing.Point(298, 529);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(88, 30);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblInvoiceDetailText
            // 
            this.lblInvoiceDetailText.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblInvoiceDetailText.AutoSize = true;
            this.lblInvoiceDetailText.BackColor = System.Drawing.Color.White;
            this.lblInvoiceDetailText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceDetailText.Location = new System.Drawing.Point(502, 142);
            this.lblInvoiceDetailText.Name = "lblInvoiceDetailText";
            this.lblInvoiceDetailText.Size = new System.Drawing.Size(111, 16);
            this.lblInvoiceDetailText.TabIndex = 7;
            this.lblInvoiceDetailText.Text = "Invoice Details";
            // 
            // lblInvoiceText
            // 
            this.lblInvoiceText.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblInvoiceText.AutoSize = true;
            this.lblInvoiceText.BackColor = System.Drawing.Color.White;
            this.lblInvoiceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceText.Location = new System.Drawing.Point(9, 142);
            this.lblInvoiceText.Name = "lblInvoiceText";
            this.lblInvoiceText.Size = new System.Drawing.Size(66, 16);
            this.lblInvoiceText.TabIndex = 8;
            this.lblInvoiceText.Text = "Invoices";
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(410, 529);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(88, 30);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblTotalSales
            // 
            this.lblTotalSales.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTotalSales.AutoSize = true;
            this.lblTotalSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSales.Location = new System.Drawing.Point(13, 529);
            this.lblTotalSales.Name = "lblTotalSales";
            this.lblTotalSales.Size = new System.Drawing.Size(86, 16);
            this.lblTotalSales.TabIndex = 10;
            this.lblTotalSales.Text = "Total Sales  :";
            // 
            // lblTotalSalesValue
            // 
            this.lblTotalSalesValue.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTotalSalesValue.AutoSize = true;
            this.lblTotalSalesValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSalesValue.Location = new System.Drawing.Point(96, 529);
            this.lblTotalSalesValue.Name = "lblTotalSalesValue";
            this.lblTotalSalesValue.Size = new System.Drawing.Size(28, 16);
            this.lblTotalSalesValue.TabIndex = 11;
            this.lblTotalSalesValue.Text = "0.0";
            // 
            // ViewInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(899, 606);
            this.ControlBox = false;
            this.Controls.Add(this.lblTotalSalesValue);
            this.Controls.Add(this.lblTotalSales);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblInvoiceText);
            this.Controls.Add(this.lblInvoiceDetailText);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.dgvInvoices);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.dgvInvoicesDetails);
            this.Controls.Add(this.grpBoxSelectDate);
            this.Name = "ViewInvoice";
            this.Text = "ViewInvoice";
            this.Shown += new System.EventHandler(this.ViewInvoice_Shown);
            this.grpBoxSelectDate.ResumeLayout(false);
            this.grpBoxSelectDate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoicesDetails)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxSelectDate;
        private System.Windows.Forms.Button btnFilterDate;
        private System.Windows.Forms.DateTimePicker dtPickerInvoiceStartDate;
        private System.Windows.Forms.DataGridView dgvInvoicesDetails;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.DateTimePicker dtPickerInvoiceEndDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.DataGridView dgvInvoices;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColInvoiceDetailId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColVAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColAmount;
        private System.Windows.Forms.Label lblInvoiceDetailText;
        private System.Windows.Forms.Label lblInvoiceText;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgColInvoiceId;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgvColSelInvoices;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgColInvDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgColInvoicePartyTin;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgColInvType;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgColInvTotal;
        private System.Windows.Forms.Label lblTotalSales;
        private System.Windows.Forms.Label lblTotalSalesValue;
    }
}