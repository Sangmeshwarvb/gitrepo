﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Bill.Utilities
{
    public class BillSettings
    {

        public static string CompanyName
        {
            get
            {
                return null;// ConfigurationManager.AppSettings["CompanyName"];
            }
        }

        public static string CompanyCell
        {
            get
            {
                return null;// ConfigurationManager.AppSettings["CompanyCell"];
            }
        }

        public static string CompanyTel
        {
            get
            {
                return null;// ConfigurationManager.AppSettings["CompanyTel"];
            }
        }

        public static string CompanyAddress
        {
            get
            {
                return null;// ConfigurationManager.AppSettings["CompanyAddress"];
            }
        }

        public static string EmailAddress
        {
            get
            {
                return null;// ConfigurationManager.AppSettings["EmailAddress"];
            }
        }
    }
}
