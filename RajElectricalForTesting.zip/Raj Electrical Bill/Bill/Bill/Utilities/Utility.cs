﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace Bill.Utilities
{
    class Utility
    {
        internal void WriteLog(String Message)
        {
            try
            {
                string APP_PATH = AppDomain.CurrentDomain.BaseDirectory;
                APP_PATH += "Alert_Log.txt";

                long length = 0;
                StreamWriter sw1;
                if (File.Exists(APP_PATH))
                {
                    FileInfo file = new FileInfo(APP_PATH);
                    length = file.Length;
                }
                if (length > 10000000)
                    sw1 = new StreamWriter(APP_PATH, false);
                else
                    sw1 = new StreamWriter(APP_PATH, true);
                sw1.WriteLine(Message);
                sw1.Close();
            }
            catch (Exception e)
            {
                
            }
        }

        internal bool checkFormIsOpened(string formName)
        {
            bool flag = false;
            foreach (Form objForm in Application.OpenForms)
            {
                if (objForm.Name == formName)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }

        internal void CloseAllChilds(Form objMDIForm)
        {
            objMDIForm.MdiChildren.OfType<Form>().ToList().ForEach(x => { x.WindowState = FormWindowState.Minimized; x.Close(); });
        }

        internal static void GetRsAndPs(double total, out int RsVal, out int PsVal)
        {
            //Calculate amount in Rs and Ps
            int rsValue = Convert.ToInt32(Math.Floor(total));
            double temp = total - rsValue;
            int psValue = Convert.ToInt32(temp * 100);
            RsVal = rsValue;
            PsVal = psValue;
        }

        internal static string NumberToWords(int number)
        {
            if (number == 0)
                return "zero";

            if (number < 0)
                return "minus " + NumberToWords(Math.Abs(number));

            string words = "";

            if ((number / 1000000) > 0)
            {
                words += NumberToWords(number / 1000000) + " million ";
                number %= 1000000;
            }

            if ((number / 1000) > 0)
            {
                words += NumberToWords(number / 1000) + " thousand ";
                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                words += NumberToWords(number / 100) + " hundred ";
                number %= 100;
            }

            if (number > 0)
            {
                //if (words != "")
                //    words += "and ";

                var unitsMap = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
                var tensMap = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += "-" + unitsMap[number % 10];
                }
            }

            return words;
        }
    }
}
