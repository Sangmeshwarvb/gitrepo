﻿namespace Bill
{
    partial class BillViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crBillPrint = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crBillPrint
            // 
            this.crBillPrint.ActiveViewIndex = -1;
            this.crBillPrint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crBillPrint.Cursor = System.Windows.Forms.Cursors.Default;
            this.crBillPrint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crBillPrint.Location = new System.Drawing.Point(0, 0);
            this.crBillPrint.Name = "crBillPrint";
            this.crBillPrint.Size = new System.Drawing.Size(949, 467);
            this.crBillPrint.TabIndex = 0;
            // 
            // BillViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 467);
            this.Controls.Add(this.crBillPrint);
            this.Name = "BillViewer";
            this.Text = "BillViewer";
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer crBillPrint;
    }
}