﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    class ManageDatabaseQueryHelper
    {
        internal static string SaveBackupDetails()
        {
          
            string query = @"INSERT INTO BackUpDetails (FileName,Location,CreatedDate)VALUES('{0}','{1}','{2}')";
            return query;
       
        }

        internal static string SaveRestoreDetails()
        {
            string query = @"INSERT INTO RestoreDetails (FileName,Location,CreatedDate)VALUES('{0}','{1}','{2}')";
            return query; 
        }

        internal static string GetBackUpDetails()
        {
            string query = @"SELECT ID,FileName,Location,CreatedDate FROM BackUpDetails";
            return query; 
        }

        internal static string GetRestoreDetails()
        {
            string query = @"SELECT ID,FileName,Location,CreatedDate FROM RestoreDetails";
            return query; 
        }
    }
}
