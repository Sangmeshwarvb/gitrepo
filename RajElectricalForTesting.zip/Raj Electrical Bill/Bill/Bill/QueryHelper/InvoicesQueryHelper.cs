﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    internal class InvoicesQueryHelper
    {
        internal static string SaveInvoice()
        {
            string query = @"INSERT INTO Invoices (CustomerID, ClientNameLine1, ClientNameLine2, PartyTinNo, InvoiceType, ComplaintNo, InvoiceDate, AmountWords, SubTotalRs, SubTotalPs, VAT12Rs, VAT12Ps, VAT5Rs, VAT5Ps, TotalRs, TotalPs)
     VALUES ({0}, '{1}', '{2}', '{3}', {4}, {5}, '{6}', '{7}', {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15})";
            return query;
        }

        internal static string GetLastInvoiceId()
        {
            string query = @"SELECT MAX(Id) From Invoices";
            return query;
        }

        internal static string GetInvoiceByDate(string startDate, string endDate)
        {
            string query = @"SELECT Invoices.Id, Invoices.ClientNameLine1, Invoices.PartyTinNo, InvoiceType.Name AS InvoiceType, format([Invoices.InvoiceDate], " +"\"dd-MMM-yy\"" + @") as InvoiceDate,
                        Invoices.TotalRs & '" + "." + @"'& Invoices.TotalPs as Total FROM (Invoices INNER JOIN InvoiceType ON Invoices.InvoiceType = InvoiceType.Id)
                        WHERE (Invoices.InvoiceDate >= #" + startDate + "# ) AND (Invoices.InvoiceDate < #" + endDate + "#) ORDER BY Invoices.InvoiceDate desc";
            return query;
        }

        internal static string GetInvoiceDetailsById(int id)
        {
            string query = @"SELECT InvoiceDetail.Id,Products.Name, InvoiceDetail.Qty, InvoiceDetail.Rate, InvoiceDetail.VAT, InvoiceDetail.AmountRs & '.'& InvoiceDetail.AmountPs As Amount FROM 
InvoiceDetail INNER JOIN Products ON InvoiceDetail.ProductId = Products.Id  WHERE  (InvoiceDetail.InvoiceId = " + id + ") ORDER BY InvoiceDetail.ItemNo";
            return query;
        }

        internal static string GetReportInvoiceData(int id)
        {
            string query = @"SELECT Invoices.Id, Invoices.ClientNameLine1, Invoices.ClientNameLine2, Invoices.PartyTinNo, InvoiceType.Name,
                        format([Invoices.InvoiceDate], " + "\"dd-MMM-yy\"" + @") as InvoiceDate, Invoices.AmountWords, Invoices.SubTotalRs,
                        Invoices.SubTotalPs , Invoices.VAT12Rs, Invoices.VAT12Ps, Invoices.VAT5Rs, Invoices.VAT5Ps,Invoices.TotalRs,
                        Invoices.TotalPs FROM Invoices INNER JOIN  InvoiceType ON Invoices.InvoiceType=InvoiceType.Id WHERE Invoices.Id=" + id;
            return query;
        }

        internal static string DeleteBillsEntries(string deleteIds)
        {
            string query = @"DELETE FROM InvoiceDetail WHERE InvoiceId IN (" + deleteIds+");";
            return query;
        }

        internal static string DeleteBills(string deleteIds)
        {
            string query = @"DELETE FROM Invoices WHERE Id IN (" + deleteIds + ");";
            return query;
        }
    }
}
