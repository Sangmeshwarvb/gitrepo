﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    internal class UsersQueryHelper
    {
        internal static string GetUsers(bool activeIndicator)
        {
            string query = @"SELECT Id, Username, Password, IsActive FROM Users WHERE IsActive=" + activeIndicator;
            return query;
        }

        internal static string SaveUser()
        {
            string query = "UPDATE Users SET Username='{0}', [Password]='{1}'  WHERE Id={2}";
            return query;
        }

        internal static string GetUserByName(string userName)
        {
            string query = @"SELECT Id, Username, Password, IsActive FROM Users WHERE IsActive=True AND Username='" + userName + "'";
            return query;
        }
    }
}
