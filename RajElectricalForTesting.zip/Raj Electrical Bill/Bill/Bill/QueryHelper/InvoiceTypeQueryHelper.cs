﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    internal class InvoiceTypeQueryHelper
    {
        internal static string GetInvoiceTypes(bool activeIndicator)
        {
            string query = @"SELECT Id, Name, IsActive FROM InvoiceType WHERE IsActive=" + activeIndicator;
            return query;
        }

        internal static string GetAllInvoiceTypes()
        {
            string query = @"SELECT Id, Name, IsActive FROM InvoiceType";
            return query;
        }

        internal static string SaveInvoiceType()
        {
            string query = @"INSERT INTO InvoiceType (Name,IsActive) VALUES(@Name,@IsActive)";
            return query;
        }

        internal static string UpdateInvoiceType()
        {
            string query = @"UPDATE InvoiceType SET Name=@Name, IsActive=@IsActive WHERE Id=@Id";
            return query;
        }

        internal static string GetInvoiceTypesByName(string invoiceTypeName)
        {
            string query = @"SELECT Id, Name, IsActive FROM InvoiceType WHERE Name= '"+ invoiceTypeName+"@'";
            return query;
        }

        internal static string DeleteInvoiceType()
        {
            string query = @"DELETE FROM InvoiceType WHERE ID=@ID" ;
            return query;
        }
    }
}
