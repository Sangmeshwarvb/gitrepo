﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    class CustomerQueryHelper
    {
        internal static string SaveCustomer()
        {
            string query = @"INSERT INTO Customer(Name, Address, PhoneNumber, MobileNumber, Email, PartyTinNo, IsActive, CreatedDate) VALUES ('{0}', '{1}',
                        '{2}', '{3}', '{4}', '{5}', {6}, '{7}')";
            return query;
        }

        internal static string UpdateCustomer()
        {
            string query = @"UPDATE Customer SET Name='{0}', Address='{1}', PhoneNumber='{2}', MobileNumber='{3}', Email='{4}', PartyTinNo='{5}', IsActive={6} WHERE Id={7}";
            return query;
        }

        internal static string GetAllCustomers()
        {
            string query = @"SELECT Id, Name, Address, PhoneNumber, MobileNumber, Email, PartyTinNo, IsActive, CreatedDate
FROM Customer";
            return query;
        }

        internal static string GetAllCustomers(bool activeIndicator)
        {
            string query = @"SELECT Id, Name, Address, PhoneNumber, MobileNumber, Email, PartyTinNo, IsActive, CreatedDate
FROM Customer WHERE IsActive=" +activeIndicator;
            return query;
        }

        internal static string GetCustomerReport()
        {
            string query = @"SELECT     InvoiceType.Name, format([Invoices.InvoiceDate], " + "\"dd-MMM-yy\"" + @") as InvoiceDate, Invoices.TotalRs, Invoices.TotalPs
FROM         (Invoices INNER JOIN
                      Customer ON Invoices.CustomerID = Customer.Id) INNER JOIN
                      InvoiceType ON Invoices.InvoiceType = InvoiceType.Id
                      WHERE Customer.Id={0} AND Invoices.InvoiceDate>=#{1}# AND Invoices.InvoiceDate<=#{2}# ORDER BY Invoices.InvoiceDate DESC";
            return query;
        }

        internal static string GetAllCustomersByName(string name)
        {
            string query = @"SELECT Id, Name, Address, PhoneNumber, MobileNumber, Email, PartyTinNo, IsActive, CreatedDate
            FROM Customer WHERE Name  LIKE '%" + name + "%'";
            return query;
        }
    }
}
