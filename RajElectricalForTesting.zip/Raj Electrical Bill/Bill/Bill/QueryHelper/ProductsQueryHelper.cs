﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    internal class ProductsQueryHelper
    {

        internal static string SaveProduct()
        {
            string query = @"INSERT INTO Products(InVoiceTypeID,Name, Price, Code, IsActive, CreatedDate) VALUES({0},'{1}', {2},{3}, {4}, '{5}')";
            return query;
        }

        internal static string UpdateProduct()
        {
            string query = @"UPDATE Products SET Name='{0}',InVoiceTypeID={1}, Price={2}, IsActive={3} WHERE Id={4}";
            return query;
        }

        internal static string GetAllProducts()
        {
            //string query = @"SELECT Products.ID, Products.Code,(Products.Name) as ProductName,(InvoiceType.Name) as InvoiceType,Products.Price from Products Inner Join InvoiceType ON Products.InvoiceTypeId=InvoiceType.ID ";
            string query = @"TRANSFORM MAX(Products.Price)
SELECT Products.Code,(Products.Name) as ProductName from Products Inner Join InvoiceType ON Products.InvoiceTypeId=InvoiceType.ID
GROUP BY Products.Name, Products.Code
PIVOT InvoiceType.Name";
            return query;
        }

        internal static string GetAllProducts(bool activeIndicator)
        {
            string query = @"SELECT Id, Name, Price,Code, IsActive FROM Products WHERE IsActive = " + activeIndicator;
            return query;
        }

        internal static string GetProductsByInvoicesType(bool activeIndicator, int invoicestype)
        {
            string query = @"SELECT Id, InvoiceTypeID,Name, Price,Code, IsActive FROM Products WHERE IsActive = " + activeIndicator+" AND InvoiceTypeID="+invoicestype;
            return query;
        }

        internal static string GetAllProductsByCode(string Code)
        {
            string query = @"SELECT Id, InvoiceTypeID, Name, Price,Code, IsActive FROM Products WHERE Code ='"+ Code+"@'" ;
            return query;
        }

        internal static string GetProductByName(string productname)
        {
            //string query = @"SELECT Products.Code,(Products.Name) as ProductName,(InvoiceType.Name) as InvoiceType,Products.Price from Products Inner Join InvoiceType ON Products.InvoiceTypeId=InvoiceType.ID WHERE Products.Name LIKE '%"+productname +"%'"; 
            string query = @"TRANSFORM MAX(Products.Price)
          SELECT Products.Code,(Products.Name) as ProductName from Products Inner Join InvoiceType ON Products.InvoiceTypeId=InvoiceType.ID  WHERE Products.Name LIKE '%" + productname + @"%' GROUP BY Products.Name, Products.Code PIVOT InvoiceType.Name";
            return query;
        }



        internal static string GetProductInfoByCodeAndInvoiceType(int code, string columnName)
        {
            string query = @"SELECT P.ID, P.InvoiceTypeID,(P.Name) as ProductName, P.Price, P.Code, P.IsActive, (I.Name) as InvoiceTypeName FROM Products AS P INNER JOIN InvoiceType AS I 
                            ON P.InvoiceTypeID=I.ID WHERE I.Name='"+columnName+"'AND P.Code='"+code+"'"; 
            return query;
        }



        internal static string UpdateProductNameByCode()
        {
           string query=@"UPDATE Products SET Name='{0}' WHERE Code='{1}'";
           return query;
        }
    }
}
