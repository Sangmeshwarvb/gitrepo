﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bill.QueryHelper
{
    public class InvoiceDetailQueryHelper
    {
        internal static string SaveInvoice()
        {
            string query = @"INSERT INTO InvoiceDetail (InvoiceId, ItemNo, ProductId, Qty, Rate, VAT, AmountRs, AmountPs) 
        VALUES ({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7})";
            return query;
        }

        internal static string GetReportInvoiceDetailData(int id)
        {
            string query = @"SELECT InvoiceDetail.ItemNo, Products.Name as ProductName, InvoiceDetail.Qty, InvoiceDetail.Rate, InvoiceDetail.VAT, InvoiceDetail.AmountRs, InvoiceDetail.AmountPs FROM 
InvoiceDetail INNER JOIN Products ON InvoiceDetail.ProductId = Products.Id  WHERE  (InvoiceDetail.InvoiceId = " + id + ") ORDER BY InvoiceDetail.ItemNo";
            return query;
        }
    }
}
