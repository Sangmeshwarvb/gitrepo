﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bill.QueryHelper;
using System.Data.OleDb;
using System.Data;

namespace Bill.Handler
{
    public class InvoiceDetailHandler
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public InvoiceDetailHandler(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveInvoice(Model.InvoiceDetailModel invoiceItem)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(InvoiceDetailQueryHelper.SaveInvoice(), invoiceItem.InvoiceId, invoiceItem.ItemNo, invoiceItem.ProductId,
                                invoiceItem.Qty, invoiceItem.Rate, invoiceItem.VAT, invoiceItem.AmountRs, invoiceItem.AmountPs);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal System.Data.DataTable GetReportInvoiceDetailData(int id)
        {

            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceDetailQueryHelper.GetReportInvoiceDetailData(id);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                DataTable dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
