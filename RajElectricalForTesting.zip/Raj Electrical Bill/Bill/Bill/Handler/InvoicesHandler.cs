﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using Bill.QueryHelper;
using System.Data;

namespace Bill.Handler
{
    public class InvoicesHandler
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public InvoicesHandler(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveBill(Model.InvoicesModel invoicesModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(InvoicesQueryHelper.SaveInvoice(), invoicesModel.CustomerID, invoicesModel.ClientNameLine1, invoicesModel.ClientNameLine2,
                            invoicesModel.PartyTinNo, invoicesModel.InvoiceType, invoicesModel.ComplaintNo, invoicesModel.InvoiceDate, invoicesModel.AmountWords,
                            invoicesModel.SubTotalRs, invoicesModel.SubTotalPs, invoicesModel.VAT12Rs, invoicesModel.VAT12Ps, invoicesModel.VAT5Rs, invoicesModel.VAT5Ps,
                            invoicesModel.TotalRs, invoicesModel.TotalPs);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal int GetLastInvoiceId()
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoicesQueryHelper.GetLastInvoiceId();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                int invoiceId = Convert.ToInt32(DatabaseHandler.ExecuteScalar(cmd));
                return invoiceId;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal System.Data.DataTable GetInvoiceByDate(string startDate, string endDate)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoicesQueryHelper.GetInvoiceByDate(startDate, endDate);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                DataTable dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetInvoiceDetailsById(int id)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoicesQueryHelper.GetInvoiceDetailsById(id);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                DataTable dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetReportInvoiceData(int id)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoicesQueryHelper.GetReportInvoiceData(id);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                DataTable dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool DeleteBills(string deleteIds)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoicesQueryHelper.DeleteBillsEntries(deleteIds);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                var result = DatabaseHandler.ExecuteNonQuery(cmd);
                if (result)
                {
                    cmd.CommandText = InvoicesQueryHelper.DeleteBills(deleteIds);
                    cmd.Connection = oledbConnection;
                    cmd.Transaction = oledbTransaction;
                    result = DatabaseHandler.ExecuteNonQuery(cmd);
                }
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
