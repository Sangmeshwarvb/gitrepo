﻿using Bill.QueryHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace Bill.Handler
{
    class ManageDatabaseHandler
    {
        
        private OleDbConnection oledbConnection;
        private OleDbTransaction oledbTransaction;

        public ManageDatabaseHandler(OleDbConnection oledbConnection, OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveBackupDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(ManageDatabaseQueryHelper.SaveBackupDetails(),  objManageDatabaseModel.FileName, objManageDatabaseModel.Location, objManageDatabaseModel.CreatedDate);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
       
        }

        internal bool SaveRestoreDetails(Model.ManageDatabaseModel objManageDatabaseModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(ManageDatabaseQueryHelper.SaveRestoreDetails(), objManageDatabaseModel.FileName, objManageDatabaseModel.Location, objManageDatabaseModel.CreatedDate);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetBackUpDetails()
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ManageDatabaseQueryHelper.GetBackUpDetails();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetRestoreDetails()
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ManageDatabaseQueryHelper.GetRestoreDetails();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
