﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace Bill.Handler
{
    class DatabaseHandler
    {
        internal static DataTable GetDataTable(OleDbCommand cmd)
        {
            DataTable objDataTable = new DataTable();
            OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd);
            objOleDbDataAdapter.Fill(objDataTable);
            objOleDbDataAdapter.Dispose();
            return objDataTable;
        }

        internal static object ExecuteScalar(OleDbCommand cmd)
        {
            object data = new object();
            try
            {
                data = cmd.ExecuteScalar();
                return data;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception generalException)
            {
                throw generalException;
            }
        }

        internal static bool ExecuteNonQuery(OleDbCommand cmd)
        {
            bool flag = false;
            try
            {
                int rowsAffected = cmd.ExecuteNonQuery();
                flag = true;
                return flag;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception generalException)
            {
                throw generalException;
            }
        }
    }
}
