﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using Bill.QueryHelper;

namespace Bill.Handler
{
    public class ProductsHandler
    {
        private OleDbConnection oledbConnection;
        private OleDbTransaction oledbTransaction;

        public ProductsHandler(OleDbConnection oledbConnection, OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }
        internal System.Data.DataTable GetAllProducts(bool activeIndicator)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetAllProducts(activeIndicator);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@IsActive",activeIndicator);
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool SaveProduct(Model.ProductsModel productsModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(ProductsQueryHelper.SaveProduct(),productsModel.InvoicesType, productsModel.Name, productsModel.Price, productsModel.Code, productsModel.IsActive, productsModel.CreatedDate);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool UpdateProduct(Model.ProductsModel productsModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(ProductsQueryHelper.UpdateProduct(), productsModel.Name, productsModel.InvoicesType, productsModel.Price, productsModel.IsActive, productsModel.ID);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetAllProducts()
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetAllProducts();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetProductsByInvoicesType(bool activeIndicator, int invoicestype)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetProductsByInvoicesType(activeIndicator, invoicestype);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@IsActive", activeIndicator);
                cmd.Parameters.AddWithValue("@InvoiceTypeID", invoicestype);
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetAllProductsByCode(string Code)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetAllProductsByCode(Code);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@Code", Code);
                
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetProductByName(string productName)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetProductByName(productName);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }





        internal DataTable GetProductInfoByCodeAndInvoiceType(int code, string columnName)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = ProductsQueryHelper.GetProductInfoByCodeAndInvoiceType(code, columnName);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool UpdateProductNameByCode(Model.ProductsModel productsModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(ProductsQueryHelper.UpdateProductNameByCode(), productsModel.Name, productsModel.Code);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
