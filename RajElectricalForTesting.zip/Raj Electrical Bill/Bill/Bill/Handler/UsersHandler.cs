﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using Bill.QueryHelper;

namespace Bill.Handler
{
    public class UsersHandler
    {
        private OleDbConnection oledbConnection;
        private OleDbTransaction oledbTransaction;

        public UsersHandler(OleDbConnection oledbConnection, OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal DataTable GetUsers(bool activeIndicator)
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = UsersQueryHelper.GetUsers(activeIndicator);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool SaveUser(Model.UsersModel usersModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(UsersQueryHelper.SaveUser(), usersModel.Username, usersModel.Password, usersModel.Id);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool flag = DatabaseHandler.ExecuteNonQuery(cmd);
                return flag;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetUserByName(string userName)
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = UsersQueryHelper.GetUserByName(userName);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
