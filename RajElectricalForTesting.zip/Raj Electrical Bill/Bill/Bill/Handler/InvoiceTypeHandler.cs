﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using Bill.QueryHelper;

namespace Bill.Handler
{
    public class InvoiceTypeHandler
    {
        private OleDbConnection oledbConnection;
        private OleDbTransaction oledbTransaction;

        public InvoiceTypeHandler(OleDbConnection oledbConnection, OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }
        internal System.Data.DataTable GetInvoiceTypes(bool activeIndicator)
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.GetInvoiceTypes(activeIndicator);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetAllInvoiceTypes()
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.GetAllInvoiceTypes();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool SaveInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.SaveInvoiceType();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@Name", invoiceTypeModel.Name);
                cmd.Parameters.AddWithValue("@IsActive", invoiceTypeModel.Active);
                bool flag = DatabaseHandler.ExecuteNonQuery(cmd);
                return flag;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool UpdateInvoiceType(Model.InvoiceTypeModel invoiceTypeModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.UpdateInvoiceType();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@Name", invoiceTypeModel.Name);
                cmd.Parameters.AddWithValue("@IsActive", invoiceTypeModel.Active);
                cmd.Parameters.AddWithValue("@Id", invoiceTypeModel.Id);
                bool flag = DatabaseHandler.ExecuteNonQuery(cmd);
                return flag;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetInvoiceTypesByName(string invoiceTypeName)
        {
            DataTable objDataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.GetInvoiceTypesByName(invoiceTypeName);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@Name", invoiceTypeName);
                objDataTable = DatabaseHandler.GetDataTable(cmd);
                return objDataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool DeleteInvoiceType(int invoiceId)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = InvoiceTypeQueryHelper.DeleteInvoiceType();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                cmd.Parameters.AddWithValue("@ID", invoiceId);
                bool flag = DatabaseHandler.ExecuteNonQuery(cmd);
                return flag;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
