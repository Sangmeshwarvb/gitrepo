﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using Bill.QueryHelper;
using System.Data;
using System.Globalization;
using Bill.Constants;

namespace Bill.Handler
{
    class CustomerHandler
    {
        private System.Data.OleDb.OleDbConnection oledbConnection;
        private System.Data.OleDb.OleDbTransaction oledbTransaction;

        public CustomerHandler(System.Data.OleDb.OleDbConnection oledbConnection, System.Data.OleDb.OleDbTransaction oledbTransaction)
        {
            // TODO: Complete member initialization
            this.oledbConnection = oledbConnection;
            this.oledbTransaction = oledbTransaction;
        }

        internal bool SaveCustomer(Model.CustomerModel customerModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();

                string query = String.Format(CustomerQueryHelper.SaveCustomer(), customerModel.Name, customerModel.Address, customerModel.PhoneNumber,
                                customerModel.MobileNumber, customerModel.Email, customerModel.PartyTinNo, customerModel.IsActive, customerModel.CreatedDate);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal bool UpdateCustomer(Model.CustomerModel customerModel)
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                string query = String.Format(CustomerQueryHelper.UpdateCustomer(), customerModel.Name, customerModel.Address, customerModel.PhoneNumber,
                                customerModel.MobileNumber, customerModel.Email, customerModel.PartyTinNo, customerModel.IsActive, customerModel.ID);
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                bool result = DatabaseHandler.ExecuteNonQuery(cmd);
                return result;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal System.Data.DataTable GetAllCustomers()
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = CustomerQueryHelper.GetAllCustomers();
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetAllCustomers(bool activeIndicator)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = CustomerQueryHelper.GetAllCustomers(activeIndicator);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetCustomerReport(int customerId, DateTime startDate, DateTime endDate)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                var sysDateFormat = ApplicationConstants.SysDateFormat;
                string query = String.Format(CustomerQueryHelper.GetCustomerReport(), customerId, startDate.ToString(sysDateFormat), endDate.ToString(sysDateFormat));
                cmd.CommandText = query;
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        internal DataTable GetAllCustomersByName(string name)
        {
            DataTable dataTable = new DataTable();
            try
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = CustomerQueryHelper.GetAllCustomersByName(name);
                cmd.Connection = oledbConnection;
                cmd.Transaction = oledbTransaction;
                dataTable = DatabaseHandler.GetDataTable(cmd);
                return dataTable;
            }
            catch (OleDbException sqlException)
            {
                throw sqlException;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
