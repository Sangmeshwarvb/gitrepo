﻿namespace Bill
{
    partial class BillEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbInvoiceType = new System.Windows.Forms.ComboBox();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.lblInvoiceDateText = new System.Windows.Forms.Label();
            this.lblInvoiceText = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtSearchBox = new System.Windows.Forms.TextBox();
            this.lblClientAddress = new System.Windows.Forms.Label();
            this.lblClientName = new System.Windows.Forms.Label();
            this.cmbCustomers = new System.Windows.Forms.ComboBox();
            this.txtClientTextLine2 = new System.Windows.Forms.TextBox();
            this.txtPartyTinNo = new System.Windows.Forms.TextBox();
            this.pnlSaveAndPrintMessage = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPartyTinNo = new System.Windows.Forms.Label();
            this.txtClientTextLine1 = new System.Windows.Forms.TextBox();
            this.lblPartyName = new System.Windows.Forms.Label();
            this.dgvInvoiceItems = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblRsInWordsValue = new System.Windows.Forms.Label();
            this.lblRsInWordsText = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblSubTotalText = new System.Windows.Forms.Label();
            this.lblVat12Text = new System.Windows.Forms.Label();
            this.lblVat5Text = new System.Windows.Forms.Label();
            this.lblTotalText = new System.Windows.Forms.Label();
            this.lblSubTotalRsValue = new System.Windows.Forms.Label();
            this.lblVat12RsValue = new System.Windows.Forms.Label();
            this.lblVat12PsValue = new System.Windows.Forms.Label();
            this.lblVat5RsValue = new System.Windows.Forms.Label();
            this.lblVat5PsValue = new System.Windows.Forms.Label();
            this.lblTotalRsValue = new System.Windows.Forms.Label();
            this.lblTotalPsValue = new System.Windows.Forms.Label();
            this.lblSubTotalPsValue = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSavePrint = new System.Windows.Forms.Button();
            this.grpBoxAddProduct = new System.Windows.Forms.GroupBox();
            this.cmbVatPercent = new System.Windows.Forms.ComboBox();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.cmbProducts = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.dgvColProductId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColSrNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColParticulars = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColVat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColRs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvColPs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtColDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlSaveAndPrintMessage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).BeginInit();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.grpBoxAddProduct.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cmbInvoiceType);
            this.panel1.Controls.Add(this.dtpInvoiceDate);
            this.panel1.Controls.Add(this.lblInvoiceDateText);
            this.panel1.Controls.Add(this.lblInvoiceText);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(34, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 99);
            this.panel1.TabIndex = 0;
            // 
            // cmbInvoiceType
            // 
            this.cmbInvoiceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInvoiceType.FormattingEnabled = true;
            this.cmbInvoiceType.Location = new System.Drawing.Point(78, 17);
            this.cmbInvoiceType.Name = "cmbInvoiceType";
            this.cmbInvoiceType.Size = new System.Drawing.Size(121, 21);
            this.cmbInvoiceType.TabIndex = 4;
            this.cmbInvoiceType.SelectedIndexChanged += new System.EventHandler(this.cmbInvoiceType_SelectedIndexChanged);
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.Enabled = false;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(78, 58);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(133, 20);
            this.dtpInvoiceDate.TabIndex = 1;
            // 
            // lblInvoiceDateText
            // 
            this.lblInvoiceDateText.AutoSize = true;
            this.lblInvoiceDateText.Location = new System.Drawing.Point(9, 64);
            this.lblInvoiceDateText.Name = "lblInvoiceDateText";
            this.lblInvoiceDateText.Size = new System.Drawing.Size(68, 13);
            this.lblInvoiceDateText.TabIndex = 0;
            this.lblInvoiceDateText.Text = "Invoice Date";
            // 
            // lblInvoiceText
            // 
            this.lblInvoiceText.AutoSize = true;
            this.lblInvoiceText.Location = new System.Drawing.Point(9, 20);
            this.lblInvoiceText.Name = "lblInvoiceText";
            this.lblInvoiceText.Size = new System.Drawing.Size(69, 13);
            this.lblInvoiceText.TabIndex = 0;
            this.lblInvoiceText.Text = "Invoice Type";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtSearchBox);
            this.panel2.Controls.Add(this.lblClientAddress);
            this.panel2.Controls.Add(this.lblClientName);
            this.panel2.Controls.Add(this.cmbCustomers);
            this.panel2.Controls.Add(this.txtClientTextLine2);
            this.panel2.Controls.Add(this.txtPartyTinNo);
            this.panel2.Controls.Add(this.pnlSaveAndPrintMessage);
            this.panel2.Controls.Add(this.lblPartyTinNo);
            this.panel2.Controls.Add(this.txtClientTextLine1);
            this.panel2.Controls.Add(this.lblPartyName);
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(71, 426);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(479, 146);
            this.panel2.TabIndex = 1;
            // 
            // txtSearchBox
            // 
            this.txtSearchBox.AccessibleDescription = "Search Name";
            this.txtSearchBox.AccessibleName = "";
            this.txtSearchBox.Location = new System.Drawing.Point(262, 12);
            this.txtSearchBox.Name = "txtSearchBox";
            this.txtSearchBox.Size = new System.Drawing.Size(150, 20);
            this.txtSearchBox.TabIndex = 13;
            this.txtSearchBox.Enter += new System.EventHandler(this.txtSearchBox_Enter);
            this.txtSearchBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSearchBox_KeyPress);
            // 
            // lblClientAddress
            // 
            this.lblClientAddress.AutoSize = true;
            this.lblClientAddress.Location = new System.Drawing.Point(23, 72);
            this.lblClientAddress.Name = "lblClientAddress";
            this.lblClientAddress.Size = new System.Drawing.Size(45, 13);
            this.lblClientAddress.TabIndex = 12;
            this.lblClientAddress.Text = "Address";
            // 
            // lblClientName
            // 
            this.lblClientName.AutoSize = true;
            this.lblClientName.Location = new System.Drawing.Point(33, 42);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(35, 13);
            this.lblClientName.TabIndex = 11;
            this.lblClientName.Text = "Name";
            // 
            // cmbCustomers
            // 
            this.cmbCustomers.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomers.FormattingEnabled = true;
            this.cmbCustomers.Location = new System.Drawing.Point(70, 11);
            this.cmbCustomers.Name = "cmbCustomers";
            this.cmbCustomers.Size = new System.Drawing.Size(161, 21);
            this.cmbCustomers.TabIndex = 10;
            this.cmbCustomers.SelectedIndexChanged += new System.EventHandler(this.cmbCustomers_SelectedIndexChanged);
            // 
            // txtClientTextLine2
            // 
            this.txtClientTextLine2.Location = new System.Drawing.Point(70, 65);
            this.txtClientTextLine2.Name = "txtClientTextLine2";
            this.txtClientTextLine2.Size = new System.Drawing.Size(288, 20);
            this.txtClientTextLine2.TabIndex = 6;
            this.txtClientTextLine2.Visible = false;
            // 
            // txtPartyTinNo
            // 
            this.txtPartyTinNo.Location = new System.Drawing.Point(70, 93);
            this.txtPartyTinNo.Name = "txtPartyTinNo";
            this.txtPartyTinNo.Size = new System.Drawing.Size(288, 20);
            this.txtPartyTinNo.TabIndex = 7;
            this.txtPartyTinNo.Visible = false;
            // 
            // pnlSaveAndPrintMessage
            // 
            this.pnlSaveAndPrintMessage.BackColor = System.Drawing.Color.Transparent;
            this.pnlSaveAndPrintMessage.Controls.Add(this.label4);
            this.pnlSaveAndPrintMessage.ForeColor = System.Drawing.Color.Black;
            this.pnlSaveAndPrintMessage.Location = new System.Drawing.Point(78, 151);
            this.pnlSaveAndPrintMessage.Name = "pnlSaveAndPrintMessage";
            this.pnlSaveAndPrintMessage.Size = new System.Drawing.Size(240, 19);
            this.pnlSaveAndPrintMessage.TabIndex = 10;
            this.pnlSaveAndPrintMessage.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(33, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Saving And Printing......";
            // 
            // lblPartyTinNo
            // 
            this.lblPartyTinNo.AutoSize = true;
            this.lblPartyTinNo.Location = new System.Drawing.Point(-1, 96);
            this.lblPartyTinNo.Name = "lblPartyTinNo";
            this.lblPartyTinNo.Size = new System.Drawing.Size(69, 13);
            this.lblPartyTinNo.TabIndex = 0;
            this.lblPartyTinNo.Text = "Party Tin No.";
            this.lblPartyTinNo.Visible = false;
            // 
            // txtClientTextLine1
            // 
            this.txtClientTextLine1.Location = new System.Drawing.Point(70, 39);
            this.txtClientTextLine1.Name = "txtClientTextLine1";
            this.txtClientTextLine1.Size = new System.Drawing.Size(288, 20);
            this.txtClientTextLine1.TabIndex = 5;
            this.txtClientTextLine1.Visible = false;
            // 
            // lblPartyName
            // 
            this.lblPartyName.AutoSize = true;
            this.lblPartyName.Location = new System.Drawing.Point(46, 14);
            this.lblPartyName.Name = "lblPartyName";
            this.lblPartyName.Size = new System.Drawing.Size(22, 13);
            this.lblPartyName.TabIndex = 0;
            this.lblPartyName.Text = "Mr.";
            // 
            // dgvInvoiceItems
            // 
            this.dgvInvoiceItems.AllowUserToAddRows = false;
            this.dgvInvoiceItems.AllowUserToDeleteRows = false;
            this.dgvInvoiceItems.BackgroundColor = System.Drawing.Color.White;
            this.dgvInvoiceItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoiceItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvColProductId,
            this.dgvColSrNo,
            this.dgvColParticulars,
            this.dgvColQty,
            this.dgvColRate,
            this.dgvColVat,
            this.dgvColRs,
            this.dgvColPs,
            this.dtColDelete});
            this.dgvInvoiceItems.Location = new System.Drawing.Point(34, 133);
            this.dgvInvoiceItems.MultiSelect = false;
            this.dgvInvoiceItems.Name = "dgvInvoiceItems";
            this.dgvInvoiceItems.RowHeadersVisible = false;
            this.dgvInvoiceItems.RowHeadersWidth = 40;
            this.dgvInvoiceItems.RowTemplate.Height = 25;
            this.dgvInvoiceItems.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvInvoiceItems.Size = new System.Drawing.Size(758, 227);
            this.dgvInvoiceItems.TabIndex = 0;
            this.dgvInvoiceItems.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInvoiceItems_CellEndEdit);
            this.dgvInvoiceItems.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvInvoiceItems_CellMouseClick);
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblRsInWordsValue);
            this.panel4.Controls.Add(this.lblRsInWordsText);
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(556, 517);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(339, 56);
            this.panel4.TabIndex = 5;
            // 
            // lblRsInWordsValue
            // 
            this.lblRsInWordsValue.Location = new System.Drawing.Point(87, 11);
            this.lblRsInWordsValue.Name = "lblRsInWordsValue";
            this.lblRsInWordsValue.Size = new System.Drawing.Size(247, 43);
            this.lblRsInWordsValue.TabIndex = 1;
            this.lblRsInWordsValue.Text = "Rupees IN WORDS";
            // 
            // lblRsInWordsText
            // 
            this.lblRsInWordsText.AutoSize = true;
            this.lblRsInWordsText.Location = new System.Drawing.Point(4, 13);
            this.lblRsInWordsText.Name = "lblRsInWordsText";
            this.lblRsInWordsText.Size = new System.Drawing.Size(77, 13);
            this.lblRsInWordsText.TabIndex = 0;
            this.lblRsInWordsText.Text = "Rs. in Words : ";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 158F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 91F));
            this.tableLayoutPanel3.Controls.Add(this.lblSubTotalText, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblVat12Text, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblVat5Text, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblTotalText, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblSubTotalRsValue, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblVat12RsValue, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblVat12PsValue, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblVat5RsValue, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblVat5PsValue, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblTotalRsValue, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblTotalPsValue, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblSubTotalPsValue, 2, 0);
            this.tableLayoutPanel3.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(557, 428);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(339, 84);
            this.tableLayoutPanel3.TabIndex = 6;
            // 
            // lblSubTotalText
            // 
            this.lblSubTotalText.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblSubTotalText.AutoSize = true;
            this.lblSubTotalText.Location = new System.Drawing.Point(106, 4);
            this.lblSubTotalText.Name = "lblSubTotalText";
            this.lblSubTotalText.Size = new System.Drawing.Size(50, 13);
            this.lblSubTotalText.TabIndex = 0;
            this.lblSubTotalText.Text = "SubTotal";
            // 
            // lblVat12Text
            // 
            this.lblVat12Text.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblVat12Text.AutoSize = true;
            this.lblVat12Text.Location = new System.Drawing.Point(88, 25);
            this.lblVat12Text.Name = "lblVat12Text";
            this.lblVat12Text.Size = new System.Drawing.Size(68, 13);
            this.lblVat12Text.TabIndex = 0;
            this.lblVat12Text.Text = "VAT@12.5%";
            // 
            // lblVat5Text
            // 
            this.lblVat5Text.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblVat5Text.AutoSize = true;
            this.lblVat5Text.Location = new System.Drawing.Point(103, 46);
            this.lblVat5Text.Name = "lblVat5Text";
            this.lblVat5Text.Size = new System.Drawing.Size(53, 13);
            this.lblVat5Text.TabIndex = 0;
            this.lblVat5Text.Text = "VAT@5%";
            // 
            // lblTotalText
            // 
            this.lblTotalText.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTotalText.AutoSize = true;
            this.lblTotalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalText.Location = new System.Drawing.Point(120, 67);
            this.lblTotalText.Name = "lblTotalText";
            this.lblTotalText.Size = new System.Drawing.Size(36, 13);
            this.lblTotalText.TabIndex = 0;
            this.lblTotalText.Text = "Total";
            // 
            // lblSubTotalRsValue
            // 
            this.lblSubTotalRsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSubTotalRsValue.AutoSize = true;
            this.lblSubTotalRsValue.Location = new System.Drawing.Point(206, 4);
            this.lblSubTotalRsValue.Name = "lblSubTotalRsValue";
            this.lblSubTotalRsValue.Size = new System.Drawing.Size(13, 13);
            this.lblSubTotalRsValue.TabIndex = 0;
            this.lblSubTotalRsValue.Text = "0";
            // 
            // lblVat12RsValue
            // 
            this.lblVat12RsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblVat12RsValue.AutoSize = true;
            this.lblVat12RsValue.Location = new System.Drawing.Point(206, 25);
            this.lblVat12RsValue.Name = "lblVat12RsValue";
            this.lblVat12RsValue.Size = new System.Drawing.Size(13, 13);
            this.lblVat12RsValue.TabIndex = 1;
            this.lblVat12RsValue.Text = "0";
            // 
            // lblVat12PsValue
            // 
            this.lblVat12PsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblVat12PsValue.AutoSize = true;
            this.lblVat12PsValue.Location = new System.Drawing.Point(305, 25);
            this.lblVat12PsValue.Name = "lblVat12PsValue";
            this.lblVat12PsValue.Size = new System.Drawing.Size(13, 13);
            this.lblVat12PsValue.TabIndex = 1;
            this.lblVat12PsValue.Text = "0";
            // 
            // lblVat5RsValue
            // 
            this.lblVat5RsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblVat5RsValue.AutoSize = true;
            this.lblVat5RsValue.Location = new System.Drawing.Point(206, 46);
            this.lblVat5RsValue.Name = "lblVat5RsValue";
            this.lblVat5RsValue.Size = new System.Drawing.Size(13, 13);
            this.lblVat5RsValue.TabIndex = 2;
            this.lblVat5RsValue.Text = "0";
            // 
            // lblVat5PsValue
            // 
            this.lblVat5PsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblVat5PsValue.AutoSize = true;
            this.lblVat5PsValue.Location = new System.Drawing.Point(305, 46);
            this.lblVat5PsValue.Name = "lblVat5PsValue";
            this.lblVat5PsValue.Size = new System.Drawing.Size(13, 13);
            this.lblVat5PsValue.TabIndex = 2;
            this.lblVat5PsValue.Text = "0";
            // 
            // lblTotalRsValue
            // 
            this.lblTotalRsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTotalRsValue.AutoSize = true;
            this.lblTotalRsValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRsValue.Location = new System.Drawing.Point(205, 67);
            this.lblTotalRsValue.Name = "lblTotalRsValue";
            this.lblTotalRsValue.Size = new System.Drawing.Size(14, 13);
            this.lblTotalRsValue.TabIndex = 3;
            this.lblTotalRsValue.Text = "0";
            // 
            // lblTotalPsValue
            // 
            this.lblTotalPsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTotalPsValue.AutoSize = true;
            this.lblTotalPsValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPsValue.Location = new System.Drawing.Point(304, 67);
            this.lblTotalPsValue.Name = "lblTotalPsValue";
            this.lblTotalPsValue.Size = new System.Drawing.Size(14, 13);
            this.lblTotalPsValue.TabIndex = 3;
            this.lblTotalPsValue.Text = "0";
            // 
            // lblSubTotalPsValue
            // 
            this.lblSubTotalPsValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSubTotalPsValue.AutoSize = true;
            this.lblSubTotalPsValue.Location = new System.Drawing.Point(305, 4);
            this.lblSubTotalPsValue.Name = "lblSubTotalPsValue";
            this.lblSubTotalPsValue.Size = new System.Drawing.Size(13, 13);
            this.lblSubTotalPsValue.TabIndex = 0;
            this.lblSubTotalPsValue.Text = "0";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnCancel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnCancel.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(545, 590);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSavePrint
            // 
            this.btnSavePrint.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSavePrint.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSavePrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(162)))), ((int)(((byte)(63)))));
            this.btnSavePrint.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSavePrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSavePrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSavePrint.ForeColor = System.Drawing.Color.White;
            this.btnSavePrint.Location = new System.Drawing.Point(406, 590);
            this.btnSavePrint.Name = "btnSavePrint";
            this.btnSavePrint.Size = new System.Drawing.Size(102, 30);
            this.btnSavePrint.TabIndex = 8;
            this.btnSavePrint.Text = "Save && Print";
            this.btnSavePrint.UseVisualStyleBackColor = false;
            this.btnSavePrint.Click += new System.EventHandler(this.btnSavePrint_Click);
            // 
            // grpBoxAddProduct
            // 
            this.grpBoxAddProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxAddProduct.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpBoxAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxAddProduct.Controls.Add(this.cmbVatPercent);
            this.grpBoxAddProduct.Controls.Add(this.btnAddProduct);
            this.grpBoxAddProduct.Controls.Add(this.txtQty);
            this.grpBoxAddProduct.Controls.Add(this.cmbProducts);
            this.grpBoxAddProduct.Controls.Add(this.label3);
            this.grpBoxAddProduct.Controls.Add(this.label2);
            this.grpBoxAddProduct.Controls.Add(this.label1);
            this.grpBoxAddProduct.ForeColor = System.Drawing.Color.Black;
            this.grpBoxAddProduct.Location = new System.Drawing.Point(272, 28);
            this.grpBoxAddProduct.Name = "grpBoxAddProduct";
            this.grpBoxAddProduct.Size = new System.Drawing.Size(520, 99);
            this.grpBoxAddProduct.TabIndex = 9;
            this.grpBoxAddProduct.TabStop = false;
            this.grpBoxAddProduct.Text = "Add Product";
            // 
            // cmbVatPercent
            // 
            this.cmbVatPercent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVatPercent.FormattingEnabled = true;
            this.cmbVatPercent.Location = new System.Drawing.Point(256, 48);
            this.cmbVatPercent.Name = "cmbVatPercent";
            this.cmbVatPercent.Size = new System.Drawing.Size(121, 21);
            this.cmbVatPercent.TabIndex = 2;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.ForeColor = System.Drawing.Color.White;
            this.btnAddProduct.Location = new System.Drawing.Point(405, 43);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(80, 30);
            this.btnAddProduct.TabIndex = 3;
            this.btnAddProduct.Text = "Add";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(165, 49);
            this.txtQty.MaxLength = 5;
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(62, 20);
            this.txtQty.TabIndex = 1;
            this.txtQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQty_KeyPress);
            // 
            // cmbProducts
            // 
            this.cmbProducts.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProducts.FormattingEnabled = true;
            this.cmbProducts.Location = new System.Drawing.Point(12, 49);
            this.cmbProducts.Name = "cmbProducts";
            this.cmbProducts.Size = new System.Drawing.Size(121, 21);
            this.cmbProducts.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "VAT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(162, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Qty";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product";
            // 
            // pnlContainer
            // 
            this.pnlContainer.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlContainer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlContainer.BackColor = System.Drawing.Color.Transparent;
            this.pnlContainer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlContainer.Controls.Add(this.dgvInvoiceItems);
            this.pnlContainer.Controls.Add(this.grpBoxAddProduct);
            this.pnlContainer.Controls.Add(this.panel1);
            this.pnlContainer.Location = new System.Drawing.Point(71, 34);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(827, 382);
            this.pnlContainer.TabIndex = 11;
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoSize = true;
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(968, 23);
            this.pnlHeader.TabIndex = 12;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(445, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(74, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "New Bill";
            // 
            // dgvColProductId
            // 
            this.dgvColProductId.DataPropertyName = "Id";
            this.dgvColProductId.HeaderText = "ProductId";
            this.dgvColProductId.Name = "dgvColProductId";
            this.dgvColProductId.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColProductId.Visible = false;
            // 
            // dgvColSrNo
            // 
            this.dgvColSrNo.DataPropertyName = "SrNo";
            this.dgvColSrNo.HeaderText = "SrNo";
            this.dgvColSrNo.Name = "dgvColSrNo";
            this.dgvColSrNo.ReadOnly = true;
            this.dgvColSrNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColSrNo.Width = 46;
            // 
            // dgvColParticulars
            // 
            this.dgvColParticulars.DataPropertyName = "Name";
            this.dgvColParticulars.HeaderText = "Particulars";
            this.dgvColParticulars.Name = "dgvColParticulars";
            this.dgvColParticulars.ReadOnly = true;
            this.dgvColParticulars.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColParticulars.Width = 300;
            // 
            // dgvColQty
            // 
            this.dgvColQty.DataPropertyName = "Qty";
            this.dgvColQty.HeaderText = "Qty";
            this.dgvColQty.Name = "dgvColQty";
            this.dgvColQty.ReadOnly = true;
            this.dgvColQty.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColQty.Width = 60;
            // 
            // dgvColRate
            // 
            this.dgvColRate.DataPropertyName = "Price";
            this.dgvColRate.HeaderText = "Rate";
            this.dgvColRate.Name = "dgvColRate";
            this.dgvColRate.ReadOnly = true;
            this.dgvColRate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColRate.Width = 90;
            // 
            // dgvColVat
            // 
            this.dgvColVat.DataPropertyName = "Vat";
            this.dgvColVat.HeaderText = "Vat ( % )";
            this.dgvColVat.Name = "dgvColVat";
            this.dgvColVat.Width = 70;
            // 
            // dgvColRs
            // 
            this.dgvColRs.DataPropertyName = "Rs";
            this.dgvColRs.HeaderText = "Rs";
            this.dgvColRs.Name = "dgvColRs";
            this.dgvColRs.ReadOnly = true;
            this.dgvColRs.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColRs.Width = 90;
            // 
            // dgvColPs
            // 
            this.dgvColPs.DataPropertyName = "Ps";
            this.dgvColPs.HeaderText = "Ps";
            this.dgvColPs.Name = "dgvColPs";
            this.dgvColPs.ReadOnly = true;
            this.dgvColPs.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvColPs.Width = 49;
            // 
            // dtColDelete
            // 
            this.dtColDelete.DataPropertyName = "Delete";
            this.dtColDelete.HeaderText = "Delete";
            this.dtColDelete.Name = "dtColDelete";
            this.dtColDelete.Width = 54;
            // 
            // BillEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(968, 659);
            this.ControlBox = false;
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.btnSavePrint);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.btnCancel);
            this.Name = "BillEntry";
            this.Text = "BillEntry";
            this.Load += new System.EventHandler(this.BillEntry_Load);
            this.Shown += new System.EventHandler(this.BillEntry_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlSaveAndPrintMessage.ResumeLayout(false);
            this.pnlSaveAndPrintMessage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.grpBoxAddProduct.ResumeLayout(false);
            this.grpBoxAddProduct.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.Label lblInvoiceDateText;
        private System.Windows.Forms.Label lblInvoiceText;
        private System.Windows.Forms.TextBox txtClientTextLine2;
        private System.Windows.Forms.TextBox txtPartyTinNo;
        private System.Windows.Forms.Label lblPartyTinNo;
        private System.Windows.Forms.TextBox txtClientTextLine1;
        private System.Windows.Forms.Label lblPartyName;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblRsInWordsValue;
        private System.Windows.Forms.Label lblRsInWordsText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblSubTotalText;
        private System.Windows.Forms.Label lblVat12Text;
        private System.Windows.Forms.Label lblVat5Text;
        private System.Windows.Forms.Label lblTotalText;
        private System.Windows.Forms.Label lblSubTotalPsValue;
        private System.Windows.Forms.Label lblSubTotalRsValue;
        private System.Windows.Forms.Label lblVat12RsValue;
        private System.Windows.Forms.Label lblVat12PsValue;
        private System.Windows.Forms.Label lblVat5RsValue;
        private System.Windows.Forms.Label lblVat5PsValue;
        private System.Windows.Forms.Label lblTotalRsValue;
        private System.Windows.Forms.Label lblTotalPsValue;
        private System.Windows.Forms.DataGridView dgvInvoiceItems;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSavePrint;
        private System.Windows.Forms.GroupBox grpBoxAddProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.ComboBox cmbProducts;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbInvoiceType;
        private System.Windows.Forms.ComboBox cmbVatPercent;
        private System.Windows.Forms.Panel pnlSaveAndPrintMessage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.ComboBox cmbCustomers;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblClientAddress;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.TextBox txtSearchBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColProductId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColSrNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColParticulars;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColVat;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColRs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvColPs;
        private System.Windows.Forms.DataGridViewButtonColumn dtColDelete;
    }
}