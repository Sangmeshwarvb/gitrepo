﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Constants;
using Bill.Delegate;
using Bill.Model;
using Bill.Utilities;
using System.Drawing.Printing;
using System.Configuration;

namespace Bill
{
    public partial class BillEntry : Form
    {
        public BillEntry()
        {
            InitializeComponent();
        }
        Utility objUtility = new Utility();

        DataTable dtProducts = new DataTable();
        DataTable dtAllProducts = new DataTable();
        DataTable dtCustomers = null;
        int _subTotalRs = 0;
        int _subTotalPs = 0;
        int _vat125Rs = 0;
        int _vat125Ps = 0;
        int _vat5Rs = 0;
        int _vat5Ps = 0;
        int _totalRs = 0;
        int _totalPs = 0;

        private void BillEntry_Load(object sender, EventArgs e)
        {
            try
            {
                txtSearchBox.Text = txtSearchBox.AccessibleDescription;
                txtSearchBox.ForeColor = SystemColors.ScrollBar;
                this.WindowState = FormWindowState.Minimized;
                PopulateProductsCombo();
                PopulateVATCombo();
                PopulateInvoiceTypeCombo();
                PopulateCustomersCombo();
                IntializeProductsDataTable();
                dtpInvoiceDate.MinDate = DateTime.Now;
                cmbProducts.Focus();
                //Set Rupee Text
                string rupeeText = Utility.NumberToWords(_totalRs);
                rupeeText = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(rupeeText.ToLower());
                string paiseText = Utility.NumberToWords(_totalPs);
                paiseText = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(paiseText.ToLower());
                lblRsInWordsValue.Text = rupeeText + " Rupees and " + paiseText + " Paise.";
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("BillEntry_Load " + exception + " " + DateTime.Now);
            }

        }

        private void PopulateCustomersCombo()
        {
            try
            {
                CustomerDelegate customerDelegate = new CustomerDelegate();
                DataTable dataTable = customerDelegate.GetAllCustomers(ApplicationConstants.ActiveIndicator);
                DataRow drRow1 = dataTable.NewRow();
                drRow1["ID"] = 0;
                drRow1["Name"] = "--Select Name--";
                dataTable.Rows.Add(drRow1);
                DataRow drRow = dataTable.NewRow();
                drRow["Id"] = 0;
                drRow["Name"] = "Others";
                dataTable.Rows.Add(drRow);
                cmbCustomers.ValueMember = "Id";
                cmbCustomers.DisplayMember = "Name";
                cmbCustomers.DataSource = dataTable;
                DataView dataview = dataTable.DefaultView;
                dataview.Sort = "ID";
                DataTable srtdatatable = dataview.ToTable();
                dtCustomers = srtdatatable;
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form Bill Entry Method PopulateCustomersCombo"+exception.Message+DateTime.Now);
            }
           
        }

        private void IntializeProductsDataTable()
        {
            try
            {
                dtProducts.Columns.Add("Id");
                dtProducts.Columns.Add("SrNo");
                dtProducts.Columns.Add("Name");
                dtProducts.Columns.Add("Qty");
                dtProducts.Columns.Add("Price");
                dtProducts.Columns.Add("Vat");
                dtProducts.Columns.Add("Rs");
                dtProducts.Columns.Add("Ps");
                dtProducts.Columns.Add("Delete");
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form Bill Entry method IntializeProductsDataTable"+exception.Message+DateTime.Now);    
  
            }
            
        }

        private void PopulateInvoiceTypeCombo()
        {
            try
            {
                InvoiceTypeDelegate invoiceTypeDelegate = new InvoiceTypeDelegate();
                DataTable dtInvoiceTypes = invoiceTypeDelegate.GetInvoiceTypes(ApplicationConstants.ActiveIndicator);
                cmbInvoiceType.DisplayMember = "Name";
                cmbInvoiceType.ValueMember = "Id";
                cmbInvoiceType.DataSource = dtInvoiceTypes;
            }
            catch (Exception exception)
            {
                 objUtility.WriteLog("form BillEntry method PopulateInvoiceTypeCombo"+exception.Message+DateTime.Now);
            }
            
        }

        private void PopulateVATCombo()
        {
            try
            {
                DataTable dtVatTypes = new DataTable();
                dtVatTypes.Columns.Add("VatText");
                dtVatTypes.Columns.Add("VatValue", typeof(double));
                dtVatTypes.Rows.Add("12.5%", 12.5);
                dtVatTypes.Rows.Add("5%", 5);
                dtVatTypes.Rows.Add("0%", 0);
                cmbVatPercent.DisplayMember = "VatText";
                cmbVatPercent.ValueMember = "VatValue";
                cmbVatPercent.DataSource = dtVatTypes;
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form Bill Entry Method PopulateVATCombo"+exception.Message+DateTime.Now);
            }
          
        }

        private void PopulateProductsCombo()
        {
            try
            {
                ProductsDelegate productsDelegate = new ProductsDelegate();
                dtAllProducts = productsDelegate.GetAllProducts(ApplicationConstants.ActiveIndicator);
                cmbProducts.AutoCompleteSource = AutoCompleteSource.ListItems;
                cmbProducts.DisplayMember = "Name";
                cmbProducts.ValueMember = "Id";
                cmbProducts.DataSource = dtAllProducts;
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form Bill Entry method PopulateProductsCombo" + exception.Message + DateTime.Now);
            }
            

        }

        private void PopulateProductsTable()
        {
            try
            {
                int invoiceTypeId = ApplicationConstants.CurrentInvoiceType;
                ProductsDelegate productsDelegate = new ProductsDelegate();
                dtProducts = productsDelegate.GetAllProducts();
                if (dtProducts.Rows.Count > 0)
                {

                    dtProducts.Columns.Remove("Type");
                    dtProducts.Columns.Remove("IsActive");
                    dtProducts.Columns.Remove("InvoiceTypeId");
                    dtProducts.Columns.Remove("InvoiceTypeName");
                    dtProducts.Columns.Add("SrNo");
                    dtProducts.Columns.Add("Qty");
                    dtProducts.Columns.Add("Vat");
                    dtProducts.Columns.Add("Rs");
                    dtProducts.Columns.Add("Ps");
                    for (int counter = 0; counter < dtProducts.Rows.Count; counter++)
                    {
                        dtProducts.Rows[counter]["SrNo"] = counter + 1;
                        dtProducts.Rows[counter]["Qty"] = 0;
                        dtProducts.Rows[counter]["Vat"] = 0;
                        dtProducts.Rows[counter]["Rs"] = 0;
                        dtProducts.Rows[counter]["Ps"] = 0;
                    }
                }
            }
            catch (Exception exception )
            {
                objUtility.WriteLog("form Bill Entry method PopulateProductsTable" + exception.Message + DateTime.Now);
              
            }
           
        }

        private void BillEntry_Shown(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                pnlSaveAndPrintMessage.Top = (this.Height / 2) - (pnlSaveAndPrintMessage.Height / 2);
                pnlSaveAndPrintMessage.Left = (this.Width / 2) - (pnlSaveAndPrintMessage.Width / 2);
                cmbProducts.Focus();
            }
            catch (Exception exceptiom)
            {
                objUtility.WriteLog("form BillEntry method BillEntry_Shown" + exceptiom.Message + DateTime.Now);
            }
           
        }

        private void dgvInvoiceItems_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string currentColumn = dgvInvoiceItems.Rows[e.RowIndex].Cells[e.ColumnIndex].OwningColumn.HeaderText;
                switch (currentColumn)
                {
                    case "Qty":
                        int value = 0;
                        string input = dgvInvoiceItems.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                        bool flag = int.TryParse(input, out value);
                        if (flag)
                        {
                            if (value > 0)
                            {
                                double price = Convert.ToDouble(dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColRate"].Value);
                                double total = value * price;
                                int rsValue = Convert.ToInt32(Math.Floor(total));
                                double temp = total - rsValue;
                                int psValue = Convert.ToInt32(temp * 100);
                                dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColRs"].Value = rsValue;
                                dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColPs"].Value = psValue;

                            }
                            else
                            {
                                dgvInvoiceItems.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = 0;
                                dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColRs"].Value = 0;
                                dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColPs"].Value = 0;
                            }
                        }
                        else
                        {
                            dgvInvoiceItems.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = 0;
                            dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColRs"].Value = 0;
                            dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColPs"].Value = 0;
                        }
                        CalculateTotal();
                        ViewTotal();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillEntry method dgvInvoiceItems_CellEndEdit" + exception.Message + DateTime.Now);
            }
            
        }

        private void CalculateTotal()
        {
            try
            {
                _subTotalRs = 0;
                _subTotalPs = 0;
                _vat125Rs = 0;
                _vat125Ps = 0;
                _vat5Rs = 0;
                _vat5Ps = 0;
                _totalRs = 0;
                _totalPs = 0;
                for (int counter = 0; counter < dgvInvoiceItems.Rows.Count; counter++)
                {
                    int qty = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColQty"].Value);
                    int rsVal = 0;
                    int psVal = 0;
                    double price = Convert.ToDouble(dgvInvoiceItems.Rows[counter].Cells["dgvColRate"].Value);
                    double total = price * qty; //Calcualte Subtotal
                    Utility.GetRsAndPs(total, out rsVal, out psVal);
                    _subTotalRs += rsVal;
                    _subTotalPs += psVal;
                    if (_subTotalPs >= 100)
                    {
                        _subTotalRs++;
                        _subTotalPs -= 100;
                    }
                    double vatValue = Convert.ToDouble(dgvInvoiceItems.Rows[counter].Cells["dgvColVat"].Value);
                    double vatTotal = CalculateVAT(total, vatValue); //Vat Amount
                    Utility.GetRsAndPs(vatTotal, out rsVal, out psVal);
                    if (vatValue == 12.5)
                    {
                        _vat125Rs += rsVal;
                        _vat125Ps += psVal;
                        if (_vat125Ps >= 100)
                        {
                            _vat125Rs++;
                            _vat125Ps -= 100;
                        }
                    }
                    else if (vatValue == 5)
                    {
                        _vat5Rs += rsVal;
                        _vat5Ps += psVal;
                        if (_vat5Ps >= 100)
                        {
                            _vat5Rs++;
                            _vat5Ps -= 100;
                        }
                    }
                    total += vatTotal;//Total Amount after vat addition
                    Utility.GetRsAndPs(total, out rsVal, out psVal);
                    _totalRs += rsVal;
                    _totalPs += psVal;
                    if (_totalPs >= 100)
                    {
                        _totalRs++;
                        _totalPs -= 100;
                    }
                }
            }
            catch (Exception exception)
            {
                
                objUtility.WriteLog("form Bill Entry Method  CalculateTotal "+ exception.Message+DateTime.Now);
            }
           
        }

        private double CalculateVAT(double total, double vat)
        {
           
                return (vat / 100) * total;
           
        }

        private void ViewTotal()
        {
            try
            {
                string rupeeText = Utility.NumberToWords(_totalRs);
                rupeeText = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(rupeeText.ToLower());
                string paiseText = Utility.NumberToWords(_totalPs);
                paiseText = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(paiseText.ToLower());
                lblRsInWordsValue.Text = rupeeText + " Rupees and " + paiseText + " Paise.";

                lblSubTotalRsValue.Text = _subTotalRs.ToString();
                lblSubTotalPsValue.Text = _subTotalPs.ToString();

                lblVat12RsValue.Text = _vat125Rs.ToString();
                lblVat12PsValue.Text = _vat125Ps.ToString();

                lblVat5RsValue.Text = _vat5Rs.ToString();
                lblVat5PsValue.Text = _vat5Ps.ToString();

                lblTotalRsValue.Text = _totalRs.ToString();
                lblTotalPsValue.Text = _totalPs.ToString();
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillEntry Method ViewTotal" + exception.Message + DateTime.Now);
            }
          

        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtQty.Text != "")
                {
                    int qty = Int32.Parse(txtQty.Text);
                    if (qty < 1)
                    {
                        MessageBox.Show("quantity must be greather than 0");
                        txtQty.Focus();
                    }
                    else
                    {
                        CheckAndAddNewEntry();
                        ViewTotal();
                        cmbProducts.Focus();
                    }

                }
                else
                {
                    MessageBox.Show("Please enter quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtQty.Focus();
                }
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form BillEntry method btnAddProduct_Click" + exception.Message + DateTime.Now);
            } 
           
        }

        private void CheckAndAddNewEntry()
        {
            try
            {
                int currentProductId = Convert.ToInt32(cmbProducts.SelectedValue);
                if (currentProductId > 0)
                {
                    DataRow[] drRows = dtProducts.Select("Id=" + currentProductId);
                    if (drRows.Length == 0)
                    {
                        AddNewEntry(dtProducts.Rows.Count + 1);
                        CalculateTotal();
                        txtQty.Text = "0";
                    }
                    else
                    {
                        MessageBox.Show("Product Already present in the bill.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                else
                {
                    MessageBox.Show("Please add valid product.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (Exception exception )
            {

                objUtility.WriteLog("form BillEntry mehtod CheckAndAddNewEntry" + exception.Message + DateTime.Now);
            }
            
        }

        private void AddNewEntry(int count)
        {
            try
            {
                DataRow drRow = dtProducts.NewRow();
                drRow["Id"] = cmbProducts.SelectedValue;
                drRow["SrNo"] = count;
                drRow["Name"] = cmbProducts.Text;
                drRow["Qty"] = txtQty.Text;
                double price = GetPrice(Convert.ToInt32(cmbProducts.SelectedValue));
                drRow["Price"] = price;
                int qty = Convert.ToInt32(txtQty.Text);
                double total = qty * price;

                //Calculate amount in Rs and Ps
                int rsValue = 0;
                int psValue = 0;
                Utility.GetRsAndPs(total, out rsValue, out psValue);
                drRow["Rs"] = rsValue;
                drRow["Ps"] = psValue;
                drRow["Delete"] = "Delete";
                drRow["Vat"] = cmbVatPercent.SelectedValue;

                dtProducts.Rows.Add(drRow);
                dgvInvoiceItems.DataSource = dtProducts;
                if (dtProducts.Rows.Count > 0)
                {
                    dgvInvoiceItems.DataSource = dtProducts;
                }
                ViewTotal();
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form Bill Entry Method AddNewEntry" + exception.Message + DateTime.Now);
            }
            
            
        }

        private double GetPrice(int productId)
        {
            try
            {
                DataRow[] drRow = dtAllProducts.Select("Id = " + productId);
                if (drRow.Length == 1)
                {
                    double price = Convert.ToDouble(drRow[0]["Price"]);
                    return price;
                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form Bill Entry method GetPrice " + exception.Message + DateTime.Now);
            }
           
            return 0.0;
        }

        private void btnSavePrint_Click(object sender, EventArgs e)
        {

            Utility utility = new Utility();
            pnlContainer.Enabled = false;
            try
            {
                if (MessageBox.Show("Are you sure, you want to save?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    pnlSaveAndPrintMessage.Visible = true;
                    if (Convert.ToInt32(lblTotalRsValue.Text) > 0)
                    {
                        List<InvoiceDetailModel> invoiceDetails = new List<InvoiceDetailModel>();

                        InvoicesModel invoicesModel = new InvoicesModel();
                        if (Convert.ToInt32(cmbCustomers.SelectedValue) == 0)
                        {
                            invoicesModel.ClientNameLine1 = txtClientTextLine1.Text.Trim();
                            invoicesModel.ClientNameLine2 = txtClientTextLine2.Text.Trim();
                            invoicesModel.PartyTinNo = txtPartyTinNo.Text.Trim();
                            invoicesModel.CustomerID = 0;
                        }
                        else
                        {
                            string filterExpression = "Id=" + Convert.ToInt32(cmbCustomers.SelectedValue);
                            DataRow[] drRow = dtCustomers.Select(filterExpression);
                            invoicesModel.CustomerID = Convert.ToInt32(cmbCustomers.SelectedValue);
                            invoicesModel.ClientNameLine1 = drRow[0].ItemArray[1].ToString();
                            invoicesModel.ClientNameLine2 = drRow[0].ItemArray[2].ToString();
                            invoicesModel.PartyTinNo = drRow[0].ItemArray[6].ToString();
                        }
                        invoicesModel.InvoiceType = Convert.ToInt32(cmbInvoiceType.SelectedValue);
                        invoicesModel.InvoiceDate = dtpInvoiceDate.Value.ToString();
                        invoicesModel.SubTotalRs = _subTotalRs;
                        invoicesModel.SubTotalPs = _subTotalPs;
                        invoicesModel.TotalRs = _totalRs;
                        invoicesModel.TotalPs = _totalPs;
                        invoicesModel.VAT12Rs = _vat125Rs;
                        invoicesModel.VAT12Ps = _vat125Ps;
                        invoicesModel.VAT5Rs = _vat5Rs;
                        invoicesModel.VAT5Ps = _vat5Ps;
                        invoicesModel.AmountWords = lblRsInWordsValue.Text;

                        for (int counter = 0; counter < dgvInvoiceItems.Rows.Count; counter++)
                        {
                            InvoiceDetailModel invoiceDetailModel = new InvoiceDetailModel();
                            invoiceDetailModel.ProductId = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColProductId"].Value);
                            invoiceDetailModel.ItemNo = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColSrNo"].Value);
                            invoiceDetailModel.Qty = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColQty"].Value);
                            invoiceDetailModel.Rate = Convert.ToDecimal(dgvInvoiceItems.Rows[counter].Cells["dgvColRate"].Value);
                            invoiceDetailModel.AmountRs = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColRs"].Value);
                            invoiceDetailModel.AmountPs = Convert.ToInt32(dgvInvoiceItems.Rows[counter].Cells["dgvColPs"].Value); ;
                            invoiceDetailModel.VAT = Convert.ToDecimal(dgvInvoiceItems.Rows[counter].Cells["dgvColVat"].Value);
                            invoiceDetails.Add(invoiceDetailModel);
                        }
                        invoicesModel.InvoiceItems = invoiceDetails;
                        InvoicesDelegate invoicesDelegate = new InvoicesDelegate();
                        bool flag = invoicesDelegate.SaveBill(invoicesModel);
                        if (flag)
                        {
                            int billno = invoicesDelegate.GetLastBillId();
                            #region PrintBill
                            BillViewer viewer = new BillViewer();
                            DataTable dtInvoicesData = invoicesDelegate.GetReportInvoiceData(billno);
                            dtInvoicesData.TableName = "InvoiceData";
                            InvoiceDetailDelegate invoiceDetailDelegate = new InvoiceDetailDelegate();
                            DataTable dtInvoicesDetailData = invoiceDetailDelegate.GetReportInvoiceDetailData(billno);
                            dtInvoicesDetailData.TableName = "InvoiceDetail";
                            DataSet dataSet = new DataSet();
                            dataSet.Tables.Add(dtInvoicesData);
                            dataSet.Tables.Add(dtInvoicesDetailData);

                            BillPrint crBillReport = new BillPrint();
                            crBillReport.SetDataSource(dataSet);

                            viewer.crBillPrint.ReportSource = crBillReport;
                            viewer.crBillPrint.Refresh();
                            viewer.crBillPrint.ShowLastPage();

                            int lastpgno = viewer.crBillPrint.GetCurrentPageNumber();
                            crBillReport.PrintToPrinter(1, false, 1, lastpgno);

                            #endregion
                            MessageBox.Show("Bill Saved", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearForm();
                        }
                        else
                        {
                            MessageBox.Show("Could not save the bill", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                utility.WriteLog("btnSave_Click error: " + exception.Message + " " + DateTime.Now);
            }
            finally
            {
                pnlSaveAndPrintMessage.Visible = false;
                pnlContainer.Enabled = true;
            }
        }

        private void ClearForm()
        {
            try
            {
                cmbProducts.SelectedIndex = 0;
                txtQty.Text = string.Empty;
                cmbVatPercent.SelectedIndex = 0;
                cmbInvoiceType.SelectedIndex = 0;
                dtProducts.Rows.Clear();
                dgvInvoiceItems.DataSource = dtProducts;
                txtClientTextLine1.Text = string.Empty;
                txtClientTextLine2.Text = string.Empty;
                txtPartyTinNo.Text = string.Empty;
                lblRsInWordsValue.Text = string.Empty;
                lblSubTotalPsValue.Text = "0";
                lblSubTotalRsValue.Text = "0";
                lblTotalPsValue.Text = "0";
                lblTotalRsValue.Text = "0";
                lblVat12PsValue.Text = "0";
                lblVat12RsValue.Text = "0";
                lblVat5PsValue.Text = "0";
                lblVat5RsValue.Text = "0";
                _subTotalPs = 0;
                _subTotalRs = 0;
                _totalRs = 0;
                _totalPs = 0;
                _vat125Ps = 0;
                _vat125Rs = 0;
                _vat5Ps = 0;
                _vat5Rs = 0;
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form Bill Entry mehtod ClearForm " + exception.Message + DateTime.Now);
            }          
        }

        private void SetGridViewHeight()
        {
            dgvInvoiceItems.Height = dtProducts.Rows.Count * (38) + 10;
        }

        private void dgvInvoiceItems_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                int deleteAt = 0;
                if (dgvInvoiceItems.Rows[e.RowIndex].Cells[e.ColumnIndex].Value == "Delete")
                {
                    int productId = Convert.ToInt32(dgvInvoiceItems.Rows[e.RowIndex].Cells["dgvColProductId"].Value);
                    for (int counter = 0; counter < dtProducts.Rows.Count; counter++)
                    {
                        if (Convert.ToInt32(dtProducts.Rows[counter]["Id"]) == productId)
                        {
                            deleteAt = counter;
                            dtProducts.Rows.RemoveAt(counter);
                            break;
                        }
                    }

                    for (int counter = deleteAt; counter < dtProducts.Rows.Count; counter++)
                    {
                        int srno = Convert.ToInt32(dtProducts.Rows[counter]["SrNo"]);
                        srno--;
                        dtProducts.Rows[counter]["SrNo"] = srno;
                    }
                    dgvInvoiceItems.DataSource = dtProducts;
                    CalculateTotal();
                    ViewTotal();
                }
            }
            catch (Exception ex)
            {
            }

        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8))
            {
                e.Handled = true;
            }
        }

        private void cmbCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(cmbCustomers.SelectedValue) == 0)
                {
                    txtClientTextLine1.Visible = true;
                    txtClientTextLine2.Visible = true;
                    lblClientName.Visible = true;
                    lblClientAddress.Visible = true;
                    txtPartyTinNo.Visible = true;
                    lblPartyTinNo.Visible = true;
                }
                else
                {
                    txtClientTextLine1.Visible = false;
                    txtClientTextLine2.Visible = false;
                    lblClientName.Visible = false;
                    lblClientAddress.Visible = false;
                    txtPartyTinNo.Visible = false;
                    lblPartyTinNo.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Utility obj = new Utility();
                obj.WriteLog("cmbCustomers_SelectedIndexChanged " + ex + " " + DateTime.Now);
            }
        }

        private void cmbInvoiceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateProductsComboByInvoicesType();
        }

        private void PopulateProductsComboByInvoicesType()
        {
            try
            {
                ProductsDelegate productsDelegate = new ProductsDelegate();
                int invoicestype = Convert.ToInt32(cmbInvoiceType.SelectedValue);
                dtAllProducts = productsDelegate.GetProductsByInvoicesType(ApplicationConstants.ActiveIndicator, invoicestype);
                cmbProducts.AutoCompleteSource = AutoCompleteSource.ListItems;
                cmbProducts.DisplayMember = "Name";
                cmbProducts.ValueMember = "Id";
                cmbProducts.DataSource = dtAllProducts;
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form Bill Entry method PopulateProductsComboByInvoicesType" + exception.Message + DateTime.Now);
                
              
            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSearchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            PopulateCustomersComboByName();//This method is written using LIKE
        }

        private void PopulateCustomersComboByName()
        {
            DataTable dataTable = new DataTable();
            string name = txtSearchBox.Text.Trim();
            CustomerDelegate customerDelegate = new CustomerDelegate();
            dataTable=customerDelegate.GetAllCustomersByName(name);
            DataRow drRow = dataTable.NewRow();
            drRow["Id"] = 0;
            drRow["Name"] = "Others";
            dataTable.Rows.Add(drRow);
            cmbCustomers.ValueMember = "Id";
            cmbCustomers.DisplayMember = "Name";
            cmbCustomers.DataSource = dataTable;


        }

        private void txtSearchBox_Enter(object sender, EventArgs e)
        {
            txtSearchBox.Text = txtSearchBox.AccessibleDescription = "";
            txtSearchBox.ForeColor = Color.Black;
        }

       
    }
}
