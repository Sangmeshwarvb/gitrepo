﻿IF NOT EXISTS (SELECT name FROM master.sys.databases WHERE name = N'RajBill')
CREATE DATABASE RajBill;
GO
use RajBill;
GO
CREATE TABLE Users (
	Id	INT NOT NULL IDENTITY(1,1),
	Username VARCHAR(32),
	Password VARCHAR(32),
	IsActive bit,
	CONSTRAINT PK_UsersId PRIMARY KEY(Id)
)

INSERT INTO Users(Username, Password, IsActive) VALUES ('admin','admin',1);
GO
CREATE TABLE InvoiceType(
	Id	INT NOT NULL IDENTITY(1,1),
	Name VARCHAR(32),
	IsActive bit,
	CONSTRAINT PK_InvoiceId PRIMARY KEY(Id)
);

INSERT INTO InvoiceType(Name, IsActive) VALUES('MINI / KDS',1);
INSERT INTO InvoiceType(Name, IsActive) VALUES('KS-4/6/KOS',1);
INSERT INTO InvoiceType(Name, IsActive) VALUES('KU-4',1);
INSERT INTO InvoiceType(Name, IsActive) VALUES('Self',1);
GO
CREATE TABLE Products(
	Id INT NOT NULL IDENTITY(1,1),
	Name VARCHAR(64) UNIQUE,
	Price decimal(7,2),
	IsActive bit,
	CONSTRAINT PK_ProductsId PRIMARY KEY(Id)
);
GO
/*Products Entry*/
INSERT INTO Products(Name,  Price, IsActive) VALUES('Rewinding',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Fitting',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Site Visit Charges',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Bearing',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Bushing',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Mac. Seal/Shaff Slive',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Packing Set',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Cooling Fab',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Oil Seal',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Thust Bearing Assembly',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Thust Bearing',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Cable',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Nut Bolts',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Oil',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Mac. Seal',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Connector Socket',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('O Ring Set',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Diform',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('External Connector',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Motor Hosing',100.21,1);
INSERT INTO Products(Name,  Price, IsActive) VALUES('Upper End Seal + SS Stoper Plate',100.21,1);



CREATE TABLE Customer(
	Id int IDENTITY(1,1) CONSTRAINT PK_CustomerId PRIMARY KEY(Id),
	Name varchar(128) NOT NULL,
	Address varchar(256),
	PhoneNumber varchar(16),
	MobileNumber varchar(16),
	Email varchar(64),
	PartyTinNo varchar(32),
	IsActive bit NOT NULL,
	CreatedDate datetime NOT NULL,
);

CREATE TABLE Invoices(
	Id INT NOT NULL IDENTITY(1,1),
	CustomerID int NULL,
	ClientNameLine1 VARCHAR(64),
	ClientNameLine2 VARCHAR(64),
	PartyTinNo VARCHAR(32),
	InvoiceType int,
	ComplaintNo int,
	InvoiceDate datetime,
	AmountWords VARCHAR(128),
	SubTotalRs int,
	SubTotalPs int,
	VAT12Rs int,
	VAT12Ps int,
	VAT5Rs int,
	VAT5Ps int,
	TotalRs int,
	TotalPs int
	CONSTRAINT PK_InvoicesId PRIMARY KEY(Id),
	CONSTRAINT FK_InvoiceType FOREIGN KEY(InvoiceType) REFERENCES InvoiceType(Id),
	CONSTRAINT FK_InvoiceCustomerID FOREIGN KEY(CustomerID) REFERENCES Customer(Id)
)

CREATE TABLE InvoiceDetail(
	Id INT NOT NULL IDENTITY(1,1),
	InvoiceId int,
	ItemNo int,
	ProductId int,
	Qty int,
	Rate decimal(7,2),
	VAT decimal(5,2),
	AmountRs int,
	AmountPs int,
	CONSTRAINT PK_InvoiceDetailId PRIMARY KEY(Id),
	CONSTRAINT FK_ID_InvoicesId FOREIGN KEY(InvoiceId) REFERENCES Invoices(Id),
	CONSTRAINT FK_ID_ProductId FOREIGN KEY(ProductId) REFERENCES Products(Id),
)

