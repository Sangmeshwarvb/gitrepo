﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Utilities;

namespace Bill
{
    public partial class BillMDI : Form
    {

        public BillMDI()
        {
            InitializeComponent();
            //menuStrip.Renderer = new MyRenderer();
            this.WindowState = FormWindowState.Minimized;
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BillMDI_Load(object sender, EventArgs e)
        {

            Utility objUtility = new Utility();
            MdiClient mdiClient;

            SetGroupBoxPositions();
            //Set Active Group Box
            hideOtherMenuGroupBoxes();
            setBackgroundColorMenuItem(billToolStripMenuItem);
            grpBoxBill.Visible = true;

            // Loop through all of the form's controls looking
            // for the control of type MdiClient.
            foreach (Control control in this.Controls)
            {
                try
                {
                    if (control is MdiClient)
                    {
                        // Attempt to cast the control to type MdiClient.
                        mdiClient = (MdiClient)control;

                        // Set the BackColor & BackgroundImage of the MdiClient control.
                        mdiClient.BackgroundImage = this.BackgroundImage;
                        mdiClient.BackColor = this.BackColor;
                    }
                }
                catch (InvalidCastException exception)
                {
                    objUtility.WriteLog("BillMDI_Load Form Change MDI Color: " + exception.Message + DateTime.Now);
                    // Catch and ignore the error if casting failed.
                }
            }
            menuStrip.BackColor = Color.White;
            menuStrip.ForeColor = Color.Black;
        }

        private void SetGroupBoxPositions()
        {

            //Group Box Bill
            pnlMenuIcons.Controls.Add(grpBoxBill);
            grpBoxBill.Location = new Point(5, 1);
        }

        private void exitMainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to close the application ?", "System Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.WindowState = FormWindowState.Minimized;
                Application.Exit();
            }
        }

        private class MyRenderer : ToolStripProfessionalRenderer
        {
            public MyRenderer() : base(new MyColors()) { }
        }

        private class MyColors : ProfessionalColorTable
        {
            public override Color MenuItemSelected
            {
                get { return Color.FromArgb(6, 189, 203); }
            }
            public override Color MenuItemPressedGradientBegin
            {
                get { return Color.FromArgb(6, 189, 203); }
            }
            public override Color MenuItemPressedGradientEnd
            {
                get { return Color.FromArgb(3, 76, 69); }
            }
            public override Color MenuItemSelectedGradientBegin
            {
                get { return Color.FromArgb(3, 76, 69); }
            }
            public override Color MenuItemSelectedGradientEnd
            {
                get { return Color.FromArgb(6, 189, 203); }
            }
        }

        private void BillMDI_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnNewBill_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            try
            {
                
                RemoveButtonBackroungColor();
                if (!objUtility.checkFormIsOpened("BillEntry"))
                {
                    objUtility.CloseAllChilds(this);
                    BillEntry billEntry = new BillEntry();
                    billEntry.MdiParent = this;
                    billEntry.WindowState = FormWindowState.Minimized;
                    billEntry.Show();
                    btnNewBill.BackColor = Color.FromArgb(194, 224, 255);
                }
            }
            catch (Exception exeption)
            {
                objUtility.WriteLog("form BillMDI method btnNewBill_Click" + exeption.Message + DateTime.Now);
              
            }
           
        }

        private void btnViewInvoices_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            try
            {
                RemoveButtonBackroungColor();
                if (!objUtility.checkFormIsOpened("ViewInvoice"))
                {
                    objUtility.CloseAllChilds(this);
                    ViewInvoice viewInvoice = new ViewInvoice();
                    viewInvoice.MdiParent = this;
                    viewInvoice.WindowState = FormWindowState.Minimized;
                    viewInvoice.Show();
                    btnViewInvoices.BackColor = Color.FromArgb(194, 224, 255);

                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnViewInvoices_Click" + exception.Message + DateTime.Now);
            }
           
        }

        private void btnInvoiceType_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            RemoveButtonBackroungColor();
            try
            {
                if (!objUtility.checkFormIsOpened("ManageInvoiceType"))
                {
                    objUtility.CloseAllChilds(this);
                    ManageInvoiceType manageInvoiceType = new ManageInvoiceType();
                    manageInvoiceType.MdiParent = this;
                    manageInvoiceType.WindowState = FormWindowState.Minimized;
                    manageInvoiceType.Show();
                    btnInvoiceType.BackColor = Color.FromArgb(194, 224, 255);

                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnInvoiceType_Click" + exception.Message + DateTime.Now);
            }
          
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            RemoveButtonBackroungColor();
            try
            {
                if (!objUtility.checkFormIsOpened("ManageProducts"))
                {
                    objUtility.CloseAllChilds(this);
                    ManageProducts manageProducts = new ManageProducts();
                    manageProducts.MdiParent = this;
                    manageProducts.WindowState = FormWindowState.Minimized;
                    btnProduct.BackColor = Color.FromArgb(194, 224, 255);
                    manageProducts.Show();
                }
            }
            catch (Exception exception)
            {
                objUtility.WriteLog("form BillMDI method btnProduct_Click" + exception.Message + DateTime.Now);
             
            }
            
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            RemoveButtonBackroungColor();
            try
            {
                if (!objUtility.checkFormIsOpened("ManageUser"))
                {
                    objUtility.CloseAllChilds(this);
                    ManageUser manageUsers = new ManageUser();
                    manageUsers.MdiParent = this;
                    manageUsers.WindowState = FormWindowState.Minimized;
                    manageUsers.Show();
                    btnUsers.BackColor = Color.FromArgb(194, 224, 255);
                }

            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnUsers_Click " + exception.Message + DateTime.Now);
            }
           
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            RemoveButtonBackroungColor();
            try
            {
                if (!objUtility.checkFormIsOpened("Customers"))
                {
                    objUtility.CloseAllChilds(this);
                    Customers customers = new Customers();
                    customers.MdiParent = this;
                    customers.WindowState = FormWindowState.Minimized;
                    customers.Show();
                    btnCustomer.BackColor = Color.FromArgb(194, 224, 255);
                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnCustomer_Click" + exception.Message + DateTime.Now);
            }
          
        }

        private void btnCustomerSales_Click(object sender, EventArgs e)
        {
            Utility objUtility = new Utility();
            try
            {
                if (!objUtility.checkFormIsOpened("CustomerReport"))
                {
                    objUtility.CloseAllChilds(this);
                    RemoveButtonBackroungColor();
                    CustomerReport customerReport = new CustomerReport();
                    customerReport.MdiParent = this;
                    customerReport.WindowState = FormWindowState.Minimized;
                    customerReport.Show();
                    btnCustomerSales.BackColor = Color.FromArgb(194, 224, 255);
                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnCustomerSales_Click" + exception.Message + DateTime.Now);
            }
            
        }

        /// <summary>
        /// This method set the Backcolor to RGB(194,224,255), to show that this
        /// menu is currently active.
        /// </summary>
        /// <param name="objToolStripMenuItem">
        /// Accepts the ToolStripMenuItem object for which the backcolor has to be set.
        /// </param>
        private void setBackgroundColorMenuItem(ToolStripMenuItem objToolStripMenuItem)
        {
            objToolStripMenuItem.BackColor = Color.FromArgb(194, 224, 255);
        }

        /// <summary>
        /// This method is used to remove the background set at the time when any item is clicked.
        /// </summary>
        private void removeBackColorMenuItem()
        {
            try
            {
                foreach (ToolStripItem item in menuStrip.Items)
                {
                    item.BackColor = Color.White;
                }
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                //If any error occurs, this will write the error in the Alert_Log.txt file.
                objUtility.WriteLog("removeBackColorMenuItem Method: " + exception + " " + DateTime.Now);
            }
        }

        /// <summary>
        /// Hides all the other group boxes of other menu items.
        /// </summary>
        private void hideOtherMenuGroupBoxes()
        {
            try
            {
                grpBoxAdmin.Visible = false;
                grpBoxBill.Visible = false;
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                //If any error occurs, this will write the error in the Alert_Log.txt file.
                objUtility.WriteLog("hideOtherMenuGroupBoxes Method: " + exception + " " + DateTime.Now);
            }

        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                hideOtherMenuGroupBoxes();
                removeBackColorMenuItem();
                grpBoxAdmin.Visible = true;
                setBackgroundColorMenuItem(adminToolStripMenuItem);
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                //If any error occurs, this will write the error in the Alert_Log.txt file.
                objUtility.WriteLog("adminToolStripMenuItem_Click Method: " + exception + " " + DateTime.Now);
            }
        }

        private void billToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                hideOtherMenuGroupBoxes();
                removeBackColorMenuItem();
                grpBoxBill.Visible = true;
                setBackgroundColorMenuItem(billToolStripMenuItem);
            }
            catch (Exception exception)
            {
                Utility objUtility = new Utility();
                //If any error occurs, this will write the error in the Alert_Log.txt file.
                objUtility.WriteLog("adminToolStripMenuItem_Click Method: " + exception + " " + DateTime.Now);
            }
        }

        private void RemoveButtonBackroungColor()
        {
            try
            {
                btnNewBill.BackColor = Color.White;
                btnViewInvoices.BackColor = Color.White;
                btnCustomerSales.BackColor = Color.White;
                btnInvoiceType.BackColor = Color.White;
                btnProduct.BackColor = Color.White;
                btnUsers.BackColor = Color.White;
                btnCustomer.BackColor = Color.White;
                btnManageDatabase.BackColor = Color.White;
            }
            catch (Exception exception)
            {

                Utility objUtility = new Utility();
                objUtility.WriteLog("form BillMDI  method RemoveButtonBackroungColor" + exception.Message + DateTime.Now);
            }
           
        }

        private void btnManageDatabase_Click(object sender, EventArgs e)
        {

            Utility objUtility = new Utility();
            RemoveButtonBackroungColor();
            try
            {
                if (!objUtility.checkFormIsOpened("ManageDatabase"))
                {
                    objUtility.CloseAllChilds(this);
                    ManageDatabase manageDatabase = new ManageDatabase();
                    manageDatabase.MdiParent = this;
                    manageDatabase.WindowState = FormWindowState.Maximized;
                    manageDatabase.Show();
                    btnManageDatabase.BackColor = Color.FromArgb(194, 224, 255);

                }
            }
            catch (Exception exception)
            {

                objUtility.WriteLog("form BillMDI method btnManageDatabase_Click" + exception.Message + DateTime.Now);
            }
           
        }
    }
}
