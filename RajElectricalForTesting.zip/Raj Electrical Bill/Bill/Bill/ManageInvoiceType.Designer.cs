﻿namespace Bill
{
    partial class ManageInvoiceType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxOperations = new System.Windows.Forms.GroupBox();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.grpBoxInvoiceEdit = new System.Windows.Forms.GroupBox();
            this.rdbtnInActive = new System.Windows.Forms.RadioButton();
            this.rdbtnActive = new System.Windows.Forms.RadioButton();
            this.lblActiveStatus = new System.Windows.Forms.Label();
            this.txtInvoiceName = new System.Windows.Forms.TextBox();
            this.lblInvoiceTypeName = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dgvInvoiceTypes = new System.Windows.Forms.DataGridView();
            this.InvoiceId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.grpBoxSave = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.grpBoxOperations.SuspendLayout();
            this.grpBoxInvoiceEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceTypes)).BeginInit();
            this.pnlHeader.SuspendLayout();
            this.grpBoxSave.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxOperations
            // 
            this.grpBoxOperations.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxOperations.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxOperations.Controls.Add(this.btnDelete);
            this.grpBoxOperations.Controls.Add(this.btnAddNew);
            this.grpBoxOperations.Controls.Add(this.btnExit);
            this.grpBoxOperations.Controls.Add(this.btnEdit);
            this.grpBoxOperations.Location = new System.Drawing.Point(161, 393);
            this.grpBoxOperations.Name = "grpBoxOperations";
            this.grpBoxOperations.Size = new System.Drawing.Size(355, 55);
            this.grpBoxOperations.TabIndex = 6;
            this.grpBoxOperations.TabStop = false;
            // 
            // btnAddNew
            // 
            this.btnAddNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(90)))));
            this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNew.ForeColor = System.Drawing.Color.White;
            this.btnAddNew.Location = new System.Drawing.Point(11, 16);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(80, 30);
            this.btnAddNew.TabIndex = 0;
            this.btnAddNew.Text = "&Add";
            this.btnAddNew.UseVisualStyleBackColor = false;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(268, 16);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 30);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Cancel";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Location = new System.Drawing.Point(182, 16);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(80, 30);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // grpBoxInvoiceEdit
            // 
            this.grpBoxInvoiceEdit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxInvoiceEdit.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxInvoiceEdit.Controls.Add(this.rdbtnInActive);
            this.grpBoxInvoiceEdit.Controls.Add(this.rdbtnActive);
            this.grpBoxInvoiceEdit.Controls.Add(this.lblActiveStatus);
            this.grpBoxInvoiceEdit.Controls.Add(this.txtInvoiceName);
            this.grpBoxInvoiceEdit.Controls.Add(this.lblInvoiceTypeName);
            this.grpBoxInvoiceEdit.Enabled = false;
            this.grpBoxInvoiceEdit.ForeColor = System.Drawing.Color.Black;
            this.grpBoxInvoiceEdit.Location = new System.Drawing.Point(161, 65);
            this.grpBoxInvoiceEdit.Name = "grpBoxInvoiceEdit";
            this.grpBoxInvoiceEdit.Size = new System.Drawing.Size(355, 110);
            this.grpBoxInvoiceEdit.TabIndex = 5;
            this.grpBoxInvoiceEdit.TabStop = false;
            this.grpBoxInvoiceEdit.Text = "Add/Edit Invoice";
            // 
            // rdbtnInActive
            // 
            this.rdbtnInActive.AutoSize = true;
            this.rdbtnInActive.Location = new System.Drawing.Point(249, 73);
            this.rdbtnInActive.Name = "rdbtnInActive";
            this.rdbtnInActive.Size = new System.Drawing.Size(64, 17);
            this.rdbtnInActive.TabIndex = 6;
            this.rdbtnInActive.Text = "InActive";
            this.rdbtnInActive.UseVisualStyleBackColor = true;
            // 
            // rdbtnActive
            // 
            this.rdbtnActive.AutoSize = true;
            this.rdbtnActive.Checked = true;
            this.rdbtnActive.Location = new System.Drawing.Point(160, 73);
            this.rdbtnActive.Name = "rdbtnActive";
            this.rdbtnActive.Size = new System.Drawing.Size(55, 17);
            this.rdbtnActive.TabIndex = 5;
            this.rdbtnActive.TabStop = true;
            this.rdbtnActive.Text = "Active";
            this.rdbtnActive.UseVisualStyleBackColor = true;
            // 
            // lblActiveStatus
            // 
            this.lblActiveStatus.AutoSize = true;
            this.lblActiveStatus.Location = new System.Drawing.Point(78, 75);
            this.lblActiveStatus.Name = "lblActiveStatus";
            this.lblActiveStatus.Size = new System.Drawing.Size(70, 13);
            this.lblActiveStatus.TabIndex = 5;
            this.lblActiveStatus.Text = "Active Status";
            // 
            // txtInvoiceName
            // 
            this.txtInvoiceName.Location = new System.Drawing.Point(160, 36);
            this.txtInvoiceName.Name = "txtInvoiceName";
            this.txtInvoiceName.Size = new System.Drawing.Size(153, 20);
            this.txtInvoiceName.TabIndex = 4;
            // 
            // lblInvoiceTypeName
            // 
            this.lblInvoiceTypeName.AutoSize = true;
            this.lblInvoiceTypeName.Location = new System.Drawing.Point(78, 39);
            this.lblInvoiceTypeName.Name = "lblInvoiceTypeName";
            this.lblInvoiceTypeName.Size = new System.Drawing.Size(69, 13);
            this.lblInvoiceTypeName.TabIndex = 2;
            this.lblInvoiceTypeName.Text = "Invoice Type";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(105)))), ((int)(((byte)(84)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(183, 17);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(91, 17);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dgvInvoiceTypes
            // 
            this.dgvInvoiceTypes.AllowUserToAddRows = false;
            this.dgvInvoiceTypes.AllowUserToDeleteRows = false;
            this.dgvInvoiceTypes.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dgvInvoiceTypes.BackgroundColor = System.Drawing.Color.White;
            this.dgvInvoiceTypes.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dgvInvoiceTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoiceTypes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InvoiceId,
            this.InvoiceType,
            this.IsActive});
            this.dgvInvoiceTypes.Location = new System.Drawing.Point(161, 181);
            this.dgvInvoiceTypes.Name = "dgvInvoiceTypes";
            this.dgvInvoiceTypes.ReadOnly = true;
            this.dgvInvoiceTypes.RowHeadersVisible = false;
            this.dgvInvoiceTypes.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvInvoiceTypes.Size = new System.Drawing.Size(355, 206);
            this.dgvInvoiceTypes.TabIndex = 4;
            this.dgvInvoiceTypes.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInvoiceTypes_RowEnter);
            // 
            // InvoiceId
            // 
            this.InvoiceId.DataPropertyName = "Id";
            this.InvoiceId.HeaderText = "Id";
            this.InvoiceId.Name = "InvoiceId";
            this.InvoiceId.ReadOnly = true;
            this.InvoiceId.Visible = false;
            // 
            // InvoiceType
            // 
            this.InvoiceType.DataPropertyName = "Name";
            this.InvoiceType.HeaderText = "InvoiceType";
            this.InvoiceType.Name = "InvoiceType";
            this.InvoiceType.ReadOnly = true;
            // 
            // IsActive
            // 
            this.IsActive.DataPropertyName = "IsActive";
            this.IsActive.HeaderText = "Active";
            this.IsActive.Name = "IsActive";
            this.IsActive.ReadOnly = true;
            this.IsActive.Visible = false;
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(676, 25);
            this.pnlHeader.TabIndex = 11;
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(252, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(173, 21);
            this.lblHeader.TabIndex = 2;
            this.lblHeader.Text = "Manage Invoice Type";
            // 
            // grpBoxSave
            // 
            this.grpBoxSave.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpBoxSave.BackColor = System.Drawing.Color.Transparent;
            this.grpBoxSave.Controls.Add(this.btnSave);
            this.grpBoxSave.Controls.Add(this.btnCancel);
            this.grpBoxSave.Location = new System.Drawing.Point(161, 454);
            this.grpBoxSave.Name = "grpBoxSave";
            this.grpBoxSave.Size = new System.Drawing.Size(355, 55);
            this.grpBoxSave.TabIndex = 7;
            this.grpBoxSave.TabStop = false;
            this.grpBoxSave.Visible = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(136)))), ((int)(((byte)(187)))));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(97, 16);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // ManageInvoiceType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(676, 515);
            this.ControlBox = false;
            this.Controls.Add(this.grpBoxSave);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.grpBoxOperations);
            this.Controls.Add(this.grpBoxInvoiceEdit);
            this.Controls.Add(this.dgvInvoiceTypes);
            this.Name = "ManageInvoiceType";
            this.Text = "ManageInvoiceType";
            this.Load += new System.EventHandler(this.ManageInvoiceType_Load);
            this.Shown += new System.EventHandler(this.ManageInvoiceType_Shown);
            this.grpBoxOperations.ResumeLayout(false);
            this.grpBoxInvoiceEdit.ResumeLayout(false);
            this.grpBoxInvoiceEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceTypes)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.grpBoxSave.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxOperations;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.GroupBox grpBoxInvoiceEdit;
        private System.Windows.Forms.TextBox txtInvoiceName;
        private System.Windows.Forms.Label lblInvoiceTypeName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dgvInvoiceTypes;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceId;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceType;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsActive;
        private System.Windows.Forms.Label lblActiveStatus;
        private System.Windows.Forms.RadioButton rdbtnInActive;
        private System.Windows.Forms.RadioButton rdbtnActive;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox grpBoxSave;
        private System.Windows.Forms.Button btnDelete;
    }
}