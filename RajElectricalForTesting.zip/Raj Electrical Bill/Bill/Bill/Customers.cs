﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bill.Utilities;
using Bill.Model;
using Bill.Delegate;
using Bill.Constants;

namespace Bill
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void Customers_Load(object sender, EventArgs e)
        {
            try
            {
                grpAddEdit.Top = grpSaveCancel.Top;
                grpSaveCancel.Visible = false;
                PopulateCustomers();
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("Customer Form Load: " + ex + " " + DateTime.Now);
            }
        }

        private void PopulateCustomers()
        {
            CustomerDelegate customerDelegate = new CustomerDelegate();
            DataTable dataTable = customerDelegate.GetAllCustomers();
            dgvCustomers.DataSource = dataTable;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                grpSaveCancel.Visible = false;
                grpAddEdit.Visible = true;
                grpAddEditCustomer.Enabled = false;
                PopulateCustomers();
                dgvCustomers.Enabled = true;
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("Cancel button click: " + ex + " " + DateTime.Now);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                dgvCustomers.Enabled = false;
                ClearTextBoxes();
                grpSaveCancel.Visible = true;
                grpAddEdit.Visible = false;
                btnSave.Tag = "Insert";
                grpAddEditCustomer.Enabled = true;
                txtName.Focus();

            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("Add button click: " + ex + " " + DateTime.Now);
            }
        }

        private void ClearTextBoxes()
        {
            txtName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPhoneNumber.Text = string.Empty;
            txtMobileNumber.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtTinNo.Text = string.Empty;
            rdbtnActive.Checked = true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCustomers.Rows.Count > 0)
                {
                    grpSaveCancel.Visible = true;
                    grpAddEdit.Visible = false;
                    btnSave.Tag = "Update";
                    dgvCustomers.Enabled = false;
                    grpAddEditCustomer.Enabled = true;
                    txtName.Focus();
                }
                else
                {
                    MessageBox.Show("Nothing To Edit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("Add button click: " + ex + " " + DateTime.Now);
            }
        }

        private void Customers_Shown(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (btnSave.Tag.ToString()== "Insert")
                {
                    CustomerModel customerModel = new CustomerModel();
                    customerModel.Name = txtName.Text.Trim();
                    customerModel.Email = txtEmail.Text.Trim();
                    customerModel.PhoneNumber = txtPhoneNumber.Text.Trim();
                    customerModel.MobileNumber = txtMobileNumber.Text.Trim();
                    customerModel.Address = txtAddress.Text.Trim();
                    customerModel.PartyTinNo = txtTinNo.Text.Trim();
                    if (rdbtnActive.Checked)
                    {
                        customerModel.IsActive = ApplicationConstants.ActiveIndicator;
                    }
                    else
                    {
                        customerModel.IsActive = ApplicationConstants.InActiveIndicator;
                    }
                    customerModel.CreatedDate = DateTime.Now;
                    CustomerDelegate customerDelegate = new CustomerDelegate();
                    bool flag = customerDelegate.SaveCustomer(customerModel);
                    if (flag)
                    {
                        MessageBox.Show("Customer Addition Successfull", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        grpSaveCancel.Hide();
                        grpAddEdit.Show();
                        grpAddEditCustomer.Enabled = false;
                        PopulateCustomers();
                        dgvCustomers.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Customer could not be saved.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (btnSave.Tag == "Update")
                {
                    CustomerModel customerModel = new CustomerModel();
                    customerModel.Name = txtName.Text.Trim();
                    customerModel.Email = txtEmail.Text.Trim();
                    customerModel.PhoneNumber = txtPhoneNumber.Text.Trim();
                    customerModel.MobileNumber = txtMobileNumber.Text.Trim();
                    customerModel.Address = txtAddress.Text.Trim();
                    customerModel.PartyTinNo = txtTinNo.Text.Trim();
                    customerModel.ID = Convert.ToInt32(dgvCustomers.CurrentRow.Cells["dtcolId"].Value);
                    if (rdbtnActive.Checked)
                    {
                        customerModel.IsActive = ApplicationConstants.ActiveIndicator;
                    }
                    else
                    {
                        customerModel.IsActive = ApplicationConstants.InActiveIndicator;
                    }
                    CustomerDelegate customerDelegate = new CustomerDelegate();
                    bool flag = customerDelegate.UpdateCustomer(customerModel);
                    if (flag)
                    {
                        MessageBox.Show("Customer Updation Successfull", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        grpSaveCancel.Hide();
                        grpAddEdit.Show();
                        grpAddEditCustomer.Enabled = false;
                        PopulateCustomers();
                        dgvCustomers.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Customer could not be update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("Save button click : " + ex + " " + DateTime.Now);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCustomers_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {

                    txtName.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolCustomerName"].Value.ToString();
                    txtEmail.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolEmail"].Value.ToString();
                    txtPhoneNumber.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolPhoneNumber"].Value.ToString();
                    txtMobileNumber.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolMobileNumber"].Value.ToString();
                    txtAddress.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolAddress"].Value.ToString();
                    txtTinNo.Text = dgvCustomers.Rows[e.RowIndex].Cells["dtcolTinNo"].Value.ToString();
                    bool isActive = Convert.ToBoolean(dgvCustomers.Rows[e.RowIndex].Cells["dtcolIsActive"].Value.ToString());
                    if (isActive)
                    {
                        rdbtnActive.Checked = true;
                    }
                    else
                    {
                        rdbtnInActive.Checked = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Utility objUtility = new Utility();
                objUtility.WriteLog("DGV Customer RowEnter: " + ex + " " + DateTime.Now);
            }
        }

     
        private void txtPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // if (e.KeyChar != (char)8 && !char.IsNumber(e.KeyChar))
            //{
            //    e.Handled = true;
            //}
               if (char.IsLetter(e.KeyChar) ||
               char.IsSymbol(e.KeyChar) ||
               char.IsWhiteSpace(e.KeyChar) ||
               char.IsPunctuation(e.KeyChar))
                e.Handled = true;

        }

        private void txtMobileNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
                 if (char.IsLetter(e.KeyChar) ||
                 char.IsSymbol(e.KeyChar) ||
                 char.IsWhiteSpace(e.KeyChar) ||
                 char.IsPunctuation(e.KeyChar))
                 e.Handled = true;
        }

      
       
    }
}
